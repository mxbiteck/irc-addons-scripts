;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Whatever
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

        ##  #  #  ##         _____________________________
        # \/ \/ \/ #         | ugliest ascii drawing ever |
        \_________/   ~~~~  / ����������������������������
         |       |    |**| /
         |  |�|  |     \/
         |  | |  |    /||\
         |   �   |   / || \
         |       |     /\
         |       |    /  \
 ������������������������������������������

  And yet another tower defense game
 

  by visionz (charlotmartine at hotmail.com)


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;  Copyright : 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

This game, and all its original content is free
to use for whatever you feel like. Rip it, modify
it, claim it yours, change the credits; the only
thing I ask is that you have fun doing it! If you
would like to make a donation to support me, then
you must be pretty stupid :)

Thank you and have fun!




;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Installation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Load tower.mrc into mIRC remote section, obviously

Type //tower to start, or use menu in menubar or status

Enjoy.


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Game
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Monsters are walking throught the path, if they reach your castle, you lose a life.
Build towers to kill them, you get cash reward for every creeps you kill.
Build more towers, upgrade towers, create combos, gain tower levels.

Watch out, some rounds are "air" levels, meaning that your canon towers can attack them!



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Controls
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Use your mouse, click to sell, click to build, click to everything! Oh, and right click to cancel building.

You can show the console by pressing ENTER on your keyboard. 

In the console - type 'help' to get help
               - type 'air' to show air level
               - type 'skip' to skip waiting time between levels
               - type 'setdiff <1-6>' to set the difficulty level (the hardest you play, the more cash bonus you get!)
                      - 1 = Very easy
                      - 2 = Easy
                      - 3 = Medium (Default)
                      - 4 = Hard
                      - 5 = Very hard
                      - 6 = Impossible
               - type 'show zone' to view zones debugging info
               - type 'show region' to view regions debugging info
               - type 'show tidzone' to view tower's attacking zone (debug!)

You can upgrade towers if you click of them, and then click UPGRADE button, if available

You can build certain combo towers if you select multiple towers (select by holding CTRL on your keyboard and selecting towers).

You gain interest (3%) after every levels

After killing a certain number of creeps, towers gain level that give them attack and speed bonuses. Maximum level for a tower is 6.

You can click on 'Pause' button to change some options, or to go take a crap or something

I guess that's all, have fun

