Notify List v.1.0 �2005 - Astro

UPDATE:
21/07/2005:
	changed the way the networks were resolved when trying to send a private message, whois or such to a user on the list in the networks view
	compressed all the icons in to two .icl files


INSTALLATION:

	This is simple, simply extract all files to your mirc folder then type:

	//load -rs notify\notify.mrc

To open the notify list window, either type at the channel/status window /nlist or navigate thru the channel, menubar and status menus to "Notify List".

To add a new nickname to the list, right click a blank area of the nlist window and select "Add Buddy".

A box will popup saying "New Profile". This is where you enter the nickname, *realname, *address, *phone, *mobile (cell), *msn, *website, *email and *additonal notes for your new user.

(* These are optional and not required, for personal reference only)

Once you've entered your details for the user, click "Done", if at any stage you change your mind, click "Cancel" and all changes are lost.

To edit a nick already on the list, select and right click the user name and select "View/Edit <nick>'s Profile". 

The profile box previously mentioned above will popup only this time its used to change the details of a stored profile. Again, once you have completed making your changes, click "Done", to cancel all changes and retain original information, click "Cancel".
	In the "View" menu you might notice on right clicking the nlist, you'll see "Networks Tree", "Online & Offline Buddies Tree", "Buddies Tree Only" and "Notify Popup Window".

NETWORKS TREE:
	This displays in the nlist window all the current networks you are connected to and the status of the nicknames on your notify list relevant to those networks. This is handy if you want to see if the user is online on one server but offline on another, etc.


ONLINE & OFFLINE BUDDIES TREE:
	This only displays a list of "buddies" on your notify list that are either offline or online, regardless of the network/server.

BUDDIES TREE ONLY:
	Just shows the offline (red) nicks and online (green) nicks only without the words "online" or "offline".

NOTIFY POPUP WINDOW:
	When a user on your notify list comes on line, this option displays a small blue window the the top right hand corner of your screen showing the nick name, address, the network the notify comes from plus the additional note (if set).

Thats about it for this, most of the operation of the notify list is pretty straight forward.

Any questions, suggestions, comments or critisicisms, please feel free to email me on

	astro321@iprimus.com.au

and I will get back to you as soon as possible, enjoy!

Astro.