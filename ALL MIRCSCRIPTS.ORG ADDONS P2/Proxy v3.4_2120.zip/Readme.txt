##############################################
#  Proxy server for mirc Made by Tontito     #
#  Version 3.4                               #
#  Email Tontitoscript@gmail.com           #
#  Addon released to www.mircscripts.org     #
##############################################


This allows you to connect to internet using another pc
***The pc that is connected to the internet (Via USB modem, UMTS, ...) must run this script***
***The pc client must have is browser with proxy settings ip (of the pc connected to the internet or
   localhost ip 127.0.0.1 if running in same pc) in port 8080 and 1080***

If you have a firewall this may not work. In case you have a program like zonalarm in your pc you must allow mirc
   to run has a server or open the port in the firewall.

This server only allows connections from your lan. For that you must config on the load process your ip
   the server will allow any connections for ips that have the same 3 first digits like 196.10.34.* 
   or localhost ip 127.0.0.1 (for tests or to get http messages and html code from pages)

This server can also be used for you to understand the http protocol or some web servers requests and responses.

HOW to load it:
  example: unzip the files to a folder named proxy and put it next to mirc.exe, then type /load -rs proxy/proxy.mrc


HOW to setup my lan configs?

  Open your local area connection and in support section get the Ip address.

  On same section you can see your subnet mask, you can copy and paste that value or you can setup your own.


HOW can i find the best mask value for my proxy server?  
  
  First you must learn what does the mask in a lan. The mask divides a network in several peaces depending on the value.
  
  There are several values you can use in a lan mask from 0 to 255 (byte value). A mask is made with 4 bytes so you will 
    have something like 255.255.255.0

  All possible ip addresses can be found from 0 to 4.228.250.625 = (255 * 255 * 255 * 255).

  Case you have a lan ip like 10.1.2.3 and your mask is 255.255.128.0, this means your possible usable lan addresses are 
    10.1.0.0 to 10.1.127.255. 

  So you ask me, how does this works? Well the mask values work like dividers, so if you see a 255 value you know that
    the ip byte in same place isn't divided (like the 10 in ip and the 255 in mask)

  If you get a 128 value, you will know the lan will be splited in 2 from that byte (in the 10.1.2.* the 255.255.128.*) is 
    slitting the 10.1.2.* in 2 lans (10.1.0.0 to 10.1.127.* and another from 10.1.128.* to 10.1.254.*)

  You can now imagine that the 0 byte doesn't split the lan in that byte meaning you can use all 255 ips from that point.
    So case you have a ip 10.2.129.2 with mask 255.255.255.0 you know that you lan goes from 10.2.129.0 to 10.2.129.254


ROUTING:
  No need to explain this, right? :P
  Based on port forward/virtual servers in routers.


Case you have any problem understanding this contact me on may email.