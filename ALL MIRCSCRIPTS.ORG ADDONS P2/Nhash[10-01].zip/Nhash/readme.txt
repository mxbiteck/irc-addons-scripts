----------------------------------------------------------------
Hash Table Manager
This Add-On use to manage your hash table (for mIRC >= 6.03)
-----------------------------------------------------------------

-due to some problems when process with Hash Table so that I decided 
to make this Add-on, may be It's  a good choice  for everyone using Hash Table 

-To Install :
1)unzip all files  to a Folder ( default Nhash ) It will contains :
      +Nhash.ini: file configuration
      +hash.mrc: main script files
      +hash.icl: Icon Library 
      +DLL Files (CTL_GEN.MDX,BARS.MDX,dialog.mdx,MDX.DLL,POPUPS.DLL,VIEWS.MDX)
      +and this readme file

2) Open your mIRC and type: /load -rs <The path of file hash.mrc> 
  example  /load -rs Nhash\hash.mrc 
 (if you install it on mIRC Dir otherwise please specify  full hash.mrc's path )

3) After that you could see mIRC ask to run  Load event (initialization commands )
, push yes , for finish , now you are ready,hope you like it

-To uninstall :simply chose unload in menubar (temporary unload ) , or you can delete 
folder that you install Add on (:( )


-----Contact and Support----------

-if you have  any questions/bugs/comments please send it to
               dvd21us@yahoo.com
(or pmsg me at www.mircscripts.org + www.mircscript.org + www.scriptsdb.org
Nick Niceboy)
-My web site : http://risedvd.tripod.com 


-------Credits---------------------------
 - Dragonzap : for his DLLs 
 - ProXieS : for some code and ideas : I intend to modify his addon a little for my own purpose
  but  couldn't,  It has many disadvantages so I had to rewrite completely ,cost me  a lot of time  :)
 - Tidy_trax  for  some bugs (not actually bugs , I still don't know why It had but had rewritten it a little)
- Thanks for all who encourage me  and contribute idea (wolfie, klops) so that script's become better
Thanks who support this Add-on : me , you and ? (Big thanks to Mircscripts and Mirc.net website)

------What's new------------------------

July 30 2004
- some minor updated (speed's purpose only)

Version 1.2 (RC?)
- Fixed Find&Replace and added @A Tag for it

Version 1.2  (16/5/2004)
-Added Resize capability for dialogs (main dialog and edit dialogs)
-Added Some Sort Options (Click in List headers)
-Removed context help (because of  sizing), This is a bit disavantage for new user , But It's just a small problem becoz I have Added a new help document in dialog menu (also It's quite easy to use)
-Added a new option : Reduce Refresh Time (degree refresh times as much as possible, use this option your Nth Item number is not accurate but It's much better for large Hash Table)
-Bug fixed and other small Updates

Version 1.1 (8/5/2004)
- Reorder ids 
- Added Option for disable updated inside Treeview
- Optimized code for using with large Table 
- Updated Preview Item
- Added some  functions to process with Search (Add ,Del,  and mass modify)
- some small updates and fixed
( Notes: for large Table , you can disable refresh Tree or listview, choose on menubar

version 1.0 : First Realeased (30/4/2004)

30/7/2004
Niceboy-DvD