

#######################

Screenshot Script v1.2

#######################


Scripted by:
#################################################################################

Flobse    ## UIN 152759920 ## Mail: Scripter@Flobse.de ## IRC: #Flobse @ Quakenet
Gummibaer ## IRC: #scripting @ central-irc
Cinet     ## IRC: #MSL @ IrCQnet - #scripting @ central-irc - #Flobse @ Quakenet

#################################################################################

## Installation ##
Extract the folder "Screenshot" in your mIRC directory or any subfolder.
Press "Alt+R" in your mIRC, click in the menu on "File - Load" and select the Screenshot.mrc and exit the editor with "OK"
To start type /screenshot or use right-click in Channel/Query/Status window.


## Description ##
This addon is to create screenshots and upload them to ImageShack.us


"Screenshot"
There are seceral choices to create a screenshot:
# Window
That takes up only the active window that is active at the time of triggering.
# Selection
There you can drawn a square with your mouse to select which area you want to use for the screenshot.
# Fullscreen
Uses the whole screen(s). If you got 2 monitors you can select then on the monitor icons below which monitor(s) you want to record.
You can hide the dialog automatical by enable the option "Menu - Options - Hide Dialog on Fullscreen-Screenshots"
With the combo "Delay" you can setup the delay time between clicking "Shoot" and the record time.
Is there a delay set, you can click again on "Shoot" to stop the countdown.
You can enable/disable the sound or hide/show the mouse while screenshot in the options menu.


"Options"
In the Options box you can setup whether the image you want to upload will be resized.
You can choose "public" so it can be found from other users through the ImageShack.us image search.
The "Infobar" means the size information bar which is visible on thumbnails.
In the "Outputs" combo control you can setup what should happen after a successfull upload.
The entries "Nothing" and "Linklist Popup" are fixed, all other can be changed under "Menu - Options - Edit Output formats"


"Edit Image"
You can also edit the current loaded image.
The standard programm is mspaint.exe but you can change it in "Menu - Options - Edition Program"


"Upload"
If the button is clicked, it appears the percentage of the upload process.
You can click again on the button while uploading to abort the upload.
If there is an valid login used under "Menu - Options - ImageShack Account - Edit Login", the image will be upload directly into your account.
Then you can also delete the uploaded images later.


"Upload History"
If its enabled in "Menu - Options - Upload History - Use", are all successfull uploaded images saved in the folder Scriptdir\History with a .url file.



Have Fun!


