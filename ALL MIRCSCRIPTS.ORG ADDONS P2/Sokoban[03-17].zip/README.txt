;-------------------------------- -------------- - ------------------------               ---------- - -           ----------
; Sokoban 1.2 by praetorian 
; praetorian@mircscripts.org
; http://praetorian.mircscripts.org
;---------------- --- -   - - 

Sokoban is a simple puzzle game created in Japan in 1980 and copyrighted by Thinking Rabbit, INC. in 1982.

The objective of the game is to move all of the squares (cardboard boxes) into the "slots" (shaded/grayed boxes)
until all of the boxes have been placed on a square.

I originally coded this addon in November of 2001 but never got around to putting the finishing touches on the 
release package.  If you find a bug, please contact me at the email address above to report it.

;--------------------------  ----------- -          --------
; INSTALLATION
;------------ -    -

1. Unzip the entire contents of the Sokoban.zip file to a folder on your hard drive.
2. From any command line in mIRC, type "/load -rs x:\path\to\Sokoban\Sokoban.mrc" where "x" is the 
   drive letter of the drive you extracted Sokoban to and "\path\to\" is the path to the Sokoban
   directory.
3. Select "Play Sokoban" from the menubar or Status window popups or type "/sokoban" to begin.

;--------------------------  - -
; CHANGES 1.1 -> 1.2
;------------------ - 

- Fixed a problem with the level and series not being displayed correctly when loading a saved game
- Fixed a problem with portions of a previous level appearing when loading a saved game
- The .sav extension is now added to saved games if it is not specified
- Removed debug code from the level updating routine (HTTP header information in the status window)
- The "About" dialog now displays the correct version

;--------------------------- - ------------------------------ -  
; Menu commands and keyboard shortcuts
;-------------------------------------------- -  -

Below is a list of menu commands, their keyboard shortcut equivalent and their functions.

Command			Shortcut	Function
------------------------------------------------------------------------------ - 
Undo			Backspace	Reverses the last move. You may hold down the backspace key
					or select the menu command several times to back up several moves.

Restart level		Home		Restarts the current level.

Next level		Page Up		Moves to the next level, discarding any moves made on the current
					level.

Previous level		Page Down	Moves to the previous level, discarding any moves made on the current
					level.

Go to level		End		Displays a dialog which allows you to select a numbered level.

Load level		Ctrl		Displays an open file dialog which allows you to manually select
					a level to load.

Next series		Insert		Moves to the next series of levels.

Previous series		Delete		Moves to the previous series of levels.

Download more levels	N/A		Displays the download dialog.  All current series of levels are 
					included with this release, so updating is not necessary.

Save game		Enter		Displays a save file dialog and saves your current game to a file.

Load game		Shift		Displays an open file dialog and allows you to select a saved game
					to load.

Switch to edit mode	N/A		Switches Sokoban into edit mode (see below for more information).

About			N/A		Displays information about Sokoban and the series of levels that
					have been included.

;----------------------- -  -------- ---------        -
; Saving/Loading a game
;-------------- - ------------- ---------- - -  -- 

To save a game, right click over the Sokoban window and choose "Save game (Enter)".  Alternatively,
you may press the enter key to bring up the save dialog.

Enter the name you wish to save your game as, including the extension ".sav".  For example, if you wanted
to save your game as "mygame", you would enter "mygame.sav".

To load a game, right click over the Sokoban window and choose "Load game (Shift)".  Alternatively,
you may press the shift key.

Select the savegame file you wish to load and click "Open".

;------------------------------ -    -
; CREATING/EDITING LEVELS
;-------------------------  -

The built in level editor contains everything you need to create new levels or edit existing ones.  To 
begin creating or editing levels, you first need to know some basic information about the editor interface.

;----  -
; Switching to edit mode
;--------- - 

To switch to edit mode, right click over the Sokoban window and choose "Switch to edit mode". Doing so should
open a small toolbar with several icons on it.

To exit edit mode simply close the toolbar (click the "x") or right click over the Sokoban window and choose 
"Exit edit mode"

While you are in edit mode you will not be able to move the pusher -- this mode is strictly for editing levels.

;--------- -  
; Toolbar
;------------ - -

The toolbar consists of nine (9) icons.  Below is a short description of their appearance, their position on the
toolbar, and their function.

Appearance			Function
-----------------------------------------------------------------------------------  - --

White rectangle			Discards current level and creates a "blank slate"

Brown folder			Discards current level and loads the specified level for editing

Purple cube			Saves the current level to the specified filename

Vertial line			[no function]

Blue "pusher"			Selects the "pusher" as the current tool

Brown box			Selects the "box" as the current tool

Greyed box			Selects the "grid" (the area where the boxes go) as the current tool

Plain grey box			Selects the interior flooring as the current tool

Dark grey box			Selects the perimeter wall as the current tool

Medium grey box			Selects blank space/eraser as the current tool

;------------------ - -
; Design "rules"
;-----------   -

There are a few basic design rules that you need to follow when creating or editing a level.

First, the entire area in which the "pusher" may move MUST be completely enclosed with perimeter (dark grey) tiles.
If this is not done, the pusher will be allowed to move outside of the playing area, which will cause unexpected behavior.

Second, the entire area in which the "pusher" may move MUST be completely covered in either "grid" (greyed box) or plain 
grey (interior flooring) tiles.

Third, the number of "grid" tiles MUST match the number of boxes.  If the number of boxes exceeds the number of grids, the 
level will terminate too early or at an unexpected time (or not at all).  If the number of "grid" tiles exceeds the number 
of boxes, it will be impossible to complete the level.

When saving a level, the number of "grid" tiles is compared with the number of boxes.  If these numbers do not match, you
will not be allowed to save the level.

In some cases, boxes start out positioned over "grid" tiles, meaning they are already in place.  If you wish to place a box
over a "grid" initially, you must first place the "grid" tile, then position a box over it.  This is true with both edited
levels and user-created levels.

If grid/box mismatches persist, be sure to overwrite any boxes that sit atop a "grid" with a "grid" tile, and replace the box.

Lastly, you MUST place one (1) pusher tile on each level.

;---------- - 
; Basic tasks
;----------   ---- -

- Create a new level

  To create a new level, switch to edit mode and click the white rectangle (leftmost) icon. 

- Edit an existing level

  You can edit an existing level using two different methods; you can use the series/level next/previous controls
  to "navigate" to the level you wish to edit, then change to edit mode, or you may change to edit mode at any time
  and load the level directly using the brown folder (load) icon on the edit toolbar.

- Save a level

  You can save a level by clicking on the purple cube icon on the edit toolbar.  You will be prompted for a filename.
  This filename MUST end in ".sok".

- NOTE: levels created and saved as "mylevel.sok" (or similar) must be loaded with the "Load level" function.  See below
        for instructions on how to extend or create series of levels.

;----------- - -  -
; Creating/Extending level series
;--------------------------------------- -     -

Because of the way the next/previous series and next/previous level functions are designed, it is possible for you to
extend an existing series with your own custom levels, or to create your own series altogether.

Levels are named in the format: [series_index]-[level_index].sok

Where [series_index] may be 1-5 (for the first five series, see above) or the current number of series +1.  For example,
if you wish to create a new series and have series 1-5 installed, your series index will be "6".  This is necessary if you
wish to be able to navigate to and from your series using the next/previous functions.

[level_index] may be any number, but must begin with 1 and increment by +1 for each additional level.  For example, if
you created a new series with an index of "7", and three levels, your files would look like:

7-1.sok
7-2.sok
7-3.sok

And so on.  This is not an absolute requirement but must be used if you wish to use the next/previous level functions.

Lastly, when you create a new series, you must create the file [series_index].info.  The format of this file is as follows:

[series_name]
[author_name]

e.g.

Thinking Rabbit series I
Thinking Rabbit, INC.

This will allow Sokoban to add the name of your series and your name to the "About" dialog.

For example, if you had created a series with an index of "6", the correct structure for your series would be:

6-1.sok
6-2.sok
...
6-15.sok
6.info

  [contents of 6.info:]

  J.Q. Public's series
  J.Q. Public

;-------- - -
; Credits
;------------------ - 

The levels included (475+) were not created by me.  Below is a list of the series and their respective authors 
(where applicable).  The levels were all converted to my proprietary format using the built-in level editor.

Thinking Rabbit Series I		Thinking Rabbit, INC.
Thinking Rabbit Series II		Thinking Rabbit, INC.
Extra series				Joseph L. Traub
Microban				[unknown]
Sokogen-990602				[unknown]

;-------------------- -     -                                                           -- -                --------- -    -;
; EOF                                                                                                              3/1/2005 ;
;----------------- -   ---------------------- -                                                             ------- -  -----;
