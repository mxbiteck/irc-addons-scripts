quickpic v1.0 by sniggle

 - what?
 
quickpic is an image resizer/publisher. it allows you to choose either
one jpeg or an entire directory and copy the images or resize them to
a specified directory (preferably a webroot directory).

 - why?
 
with the boom of cheap digital cameras and broadband internet, i figured
there are a lot of people out there that would love an easy way to share
their pictures. with this script combined with a local web server
(Web Server by tontito or MotionWS web server by oracel & m0rpheus are
both easy mirc scripts that can host files), you can easily process an
entire directory of images into nice small files located and indexed in
the web server and have a link ready to paste in a few seconds. considering
most people take pictures at high resolutions which would be too large
to host on a consumer broadband connection, the quick resizing options
of this script can come in very handy.

even if you don't run a web server, this script is still handy for mass-
converting/renaming images that you would normally upload to a web server.

 - how?

1) unzip the files to your mirc dir
2) /load -rs quickpic.mrc
3) select your webroot folder in the setup dialog (if you don't run a
   web server, just select any arbitrary directory).
   select your domain (ex. http://www.mysite.com or http://66.66.66.66)
   (again, if you don't have one, just put in something arbitrary).
   this information will only be used to copy image links to the clipboard
   automatically, so if you set random weird values, you will get random
   weird things in your clipboard.
4) /quickpic

the buttons in the tiny window that opens allow you to either process
one or more pictures (PIC) or an entire directory (DIR). the script will
resize all the images to the dimensions you specify, while maintaining
aspect ratio.

the script will prompt you with the approximate resolution you want to
use (640x480, 800x600, 1024x768, 1290x960, or unchanged)
you can also set the jpeg quality level.
you can also choose to mass-rename the files (so images don't have
nondescript names such as IMG_x or DCP_x).
other options will allow the script to automatically overwrite existing
files, and also create a very basic index.html file containing links to
the images (in case your web server does not allow directory browsing).
finally, there is an option to recurse subdirectories in DIR mode, if you
want to process a lot of images.

if you process a single image, the script will copy a link to it to your
clipboard (assuming all settings are set correctly).

if you process an entire directory or multiple images, the script will
copy a link to the web directory to your clipboard.

if you do directory mode and choose to rename files, it will show you
a preview image of each picture while you type in the filename, for
convenience. should you discover that there are way too many pictures
to rename, you can click "Cancel all" and it will preserve the original
filenames from then on.

the LINKS button will show a dialog of images that have been processed,
in their entire linkable form. by double-clicking on any line, it will
copy the url to the clipboard. you can also select any line and click
"Launch", which will open a web browser with that link. click "Clear"
to clear all the links.

note that the image resizing works like this:

	if the image is wider than it is taller, then it will set the width
	of the image to the width of the resolution you specified, and height
	will be automatically set according to whatever the aspect ratio is.
	
	if the image is taller than it is wider, then it will set the height
	of the image to the WIDTH of the resolution you specified. this keeps
	the image approximately whichever resolution you specified, although
	it will not be exact.

if you right-click on the tiny buttons, you can choose to either move
the window, enter the setup dialog, or close the window.
if you click "move", just move your mouse to position the window and
left-click when it's positioned where you want it.

misc commands:

	/unpic - close the window
	/quickpic.uninstall - uninstall the addon
	
misc notes:

	this addon is a little quirky if you run multiple monitors and have
	mirc in your secondary monitor. the dialogs and @windows seem to
	show up randomly on either monitor. for instance, when renaming images
	the preview window appears in my primary monitor, but the rename
	dialog appears on the secondary monitor, even though they use the
	same coordinates. shrug. you will also have trouble moving the little
	button gui with multiple monitors.
	
that's about it. i hope you find this addon useful. it's my first public
one in a looooooong time (nmp3 anyone? (i was nipkick)).

sniggleface@gmail.com