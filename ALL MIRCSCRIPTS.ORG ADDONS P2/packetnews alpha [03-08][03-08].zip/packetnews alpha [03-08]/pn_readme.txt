Name: Packetnews.com Browser
Version: Alpha
Author: quickman
Created: March 6, 2004
Finished: March 8, 2004

After being frustrated with the slow and tiresome browsing of the packetnews.com website, I decided to make this. It speeds up the process by connecting, joining, and requesting the packet for you, instead of having to type in the request manually(which got confusing when therewere names like "ILLEG4L-WAREZ-[4323432423]ab"). 

The addon connects to the packetnews.com website, which incase you didn't know, is a database of known XDCC servers which you can search the servers for a file you want. It will return the bots name, packet number, description, and in most cases, the slots open, queues, speed, uptime, and more. 

This addon is a joy to use and is a perfect complement to my full script, earthbound alpha, especially the queue manager in that script. And no, its not in the "alpha" stage, I name my versions like that because in my favorite video game EarthBound, which I named my script after, it will upgrade your attacks periodically, with each attack being named the next letter of the alphabet. Example, Ness's attack PSI Rockin, it starts with PSI Rockin Alpha, later he learns PSI Rockin Beta, then PSI Rockin Gamma, and so on.

This addon was tested on a Pentium II, 400mhz 64mb RAM machine with cable internet connection.

=======
Loading
=======

Type /load -rs path\to\packetnews.mrc to load

=======
Access
=======

Access is easy. Just type /pn!

=======
Options
=======

There are three options in the options dialog.
Use server -m(default: unchecked): 
-If its checked: Will open a new server window
-If its unchecked: Will disconnect in your active window then connect to that server in your active window.
Use Auto-Request(default: checked):
-If its checked: Will do the pack requesting for you when it joins the channel
-If its unchecked: You have to manually request the packet by typing /ctcp <name> xdcc send....
Disconnect if bot is inactive(default: checked):
-If its checked: Will disconnect from that server if the bot is unavaliable
-If its unchecked: Will remain on that server even if the bot is unavaliable 

=======
Usage
=======

Not difficult. Just type in what you are looking for, and click search. It will connect, then when its done display the results. It can have several pages, which you navigate through the pages combo box. It will display all the networks/channels it found during the search in the combo boxes. Browse the networks and channels to view all the results on that page. Click on a packet you want in the box and click request and it will do the process. If the bot is unavaliable, a message box will pop up informing you that it is unavaliable. If the your request is queued, a message box will also come up informing that your request was queued. 

===========
Dud Stats
===========

Not all stats(like queues, slots open, kps) are displayed on packetnews.com, and this script is no exception. It is normal for some stats not to be displayed, and will be replaced with - on stats that don't show up.

=======
Future
=======

It's pretty complete. I may add options to sort by speed or open slots, who knows.

========
Contact
========

I rarely hang out on IRC anymore, but if you want to find me I may be at irc.gamesurge.net #d2f, nicknamed plus or swordsdance, and on irc.criten.net in #tmd-moviez.

======
Final
======

Have fun with this addon... any bugs report to me.

;EOF