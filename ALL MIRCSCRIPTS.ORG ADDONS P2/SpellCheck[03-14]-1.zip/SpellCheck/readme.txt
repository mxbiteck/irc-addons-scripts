To load this script type '/load -rs <directory>\SpellCheck.mrc' in any Mirc window

SpellChecker is a simple spell checking utility for mirc. 
If you want, it checks all text you send to a channel. 
And, yes you can turn it off via the popup menus. 
It also has a custom dictionary which you can add your own words to.
you may also *add a your own word list via the popup menu as well 
(I have included an IRC Jargon word list that you can load if you wish) 
btw I've done my best to keep it from recognizing nicks as misspellings 
but most nick completers well cause it not check text since it would send 
your text twice to a chan :( not much I can do about this for now.
To check text in an editbox press Ctrl+F3

*dont worry about adding the same word twice it checks for that ;)

