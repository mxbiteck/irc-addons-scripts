Version 3.0 Sphinx

==================================

28 Aug 2007 10:00PM

Thank you for trying out Zion. Please read the help file to find out more.

- sprion@zincplay.com

-------------------------------
1. What is this?
-------------------------------
This is an mIRC addon designed for network gaming.


-------------------------------
2. Note to previous users:
-------------------------------
Version changes at the bottom.

If you're not sure where you had previously installed Zion, do this:

	Type "/zion.whereami" in mIRC

	*** Unload ZION before installing - "/zion.unload" ***

	ON PROBLEM during install: 'x-gui.dll' or 'WindowFX.dll' in use.
		Close IRC before installing ...


-------------------------------
3. How to install? (previous users read above first!)
-------------------------------

[Visual Guide]
* For step-by-step screenshot help, visit http://www.zincplay.com > Support > Tutorials > How do I install Zion?

[Text Guide]
1. 	just extract all these files to where you want to install ZION.
		(i.e. C:\Program Files\mIRC\zion) - recommended to have a "zion" folder

	Overwrite all the files when asked.

2. 	Load the NEW Zion. 
		Type '/load -rs zion\zion.mrc' in mIRC
		in any EDIT box (where you type what you want to say)

3. 	Fill in the necessary information in the install dialogs.


-------------------------------
4. Supported games:
-------------------------------
Warcraft III
Warcraft III: Frozen Throne (default)
All Blizzard games*
Tanks by ^Andy^


-------------------------------
5. System Requirements:
-------------------------------
Decent Internet connection
mIRC v6.17 and above seems to have no problem.

Zion is best used with mIRC 6.21


-------------------------------
6. For help and assistance:
-------------------------------
Join #ZincHelp on irc.GameSurge.net and ask the users or admins around.
http://www.zincplay.com
http://zinc.sg
http://zion-irc.sourceforge.net
http://zinc.quikihosting.com


-------------------------------
7. Author's disclaimer
-------------------------------
We do not support piracy. Please support originals & freeware & open source programs! (like this one)

Visit http://rules.zincplay.com for the Rules & Regulations.

- sprion@zincplay.com