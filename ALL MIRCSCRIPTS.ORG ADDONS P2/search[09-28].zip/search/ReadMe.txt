;Win Explorer v1.1 - by da^hype (da-hype@hirc.org)
;website: http://www.hirc.org
;Malaysian Made
;Date: 28/09/2004

Installing
 ----------
 To install the script you must unzip the search.zip file (which you have already 
 done), then you must load the search.mrc file in mIRC. 

 To load the file you can either use the /load command by typing the following in
 mIRC. You must change 'directory' to the directory that it has been saved to.
  
   /load -rs directory\search.mrc

 For example if you saved it to your desktop you would type:

   /load -rs c:\windows\desktop\search\search.mrc

 make sure your directory does not have spaces in it.

 The second way to load the script is by opening the remote script editor by either
 selecting Tools and Remote... from the menu or by pressing alt+r, then you must
 select File, Load then Script. You will be able to find and load the addon from there
 (note you must by looking for file type *.mrc and not *.ini).

 Once you have completed the install you should have a message in your status window
 confirming that you have loaded the script. If you have, then you have installed the
 addon.


About
 ------------
  A simple addon that allows you to view folders/files in any choosen directory.



Versions
  ------------
1.1 (28/09/2004) 
- Cleaned up code.
- Local aliases.
- Used $scriptdir
- Updated nhtmln.dll
- Updated url


1.0 (28/03/2003) - First public release.



Further help
  ------------
  
  Join #hirc.help on WebChat. Also visit http://www.hirc.org


Important
  ------------

  If you decide to use this addon in your script's feel free, but please don't change anything, and PLEASE give me credit. Would be nice if you emailed me at da-hype@hirc.org to tell me about it too. Thanks


