---------------------------------------
- Wolfenstein serverbrowser by impulZ -
-   The most useless script ever :P   -
---------------------------------------

To install just extract the files to any directory you want and type:

e.g. /load -rs C:\path_to_script\wolf.mrc

or if you put the script in your mirc directory:

e.g. /load -rs wolf\wolf.mrc

After you've loaded the script you should type /serv to open the Browser window.

---------------------------------------

The browser supports the following games:
Quake1 / QuakeGL
Quake2
Quake3
Doom3
Half-life
Half-life2
RTCW / ET
Unreal-Tournament
Ut2003
Ut2004
Farcry
Bf1942

---------------------------------------

N O T E:
If the script doesn't run correctly (the servers doesn't refresh)
place the files in an folder without any spaces in it:

WRONG: C:\wolfenstein server\wolf.mrc

RIGHT: C:\wolfserver\wolf.mrc
   or: wolf\wolf.mrc

---------------------------------------

Credits:
The maker of the qstat.exe to retrieve game infos :)
The creater of the cmd to @window code
and me :P