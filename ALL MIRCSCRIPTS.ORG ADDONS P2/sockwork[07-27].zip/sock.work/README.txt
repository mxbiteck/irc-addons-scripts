SOCKET WORKSHOP

Instructions:
1. Put folder wherever you want
2. Open mIRC (if not already open)
3. Type /load -rs1 path/to/sockwork.mrc
4. Check menus or type /sockwork

____________________

Addon has been tested with mIRC versions 6.16 and 6.03.
____________________

Socklist ONLY contains sockets created by socket
workshop and clients that have connected to a listen
socket that was made with socket workshop.


Enjoy :P~
____________________

Thanks to sam0r, jarryd  for some quick opinions and bug
testing :)
____________________

- |BacK|DoOR|
