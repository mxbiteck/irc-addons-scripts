======================================================================02/11/2010===
                   Talons Affine Texture Mapper
                   irc.webchat.org:6667 in #mIRC
===================================================================================
Welcome to my Affine Texture Mapper example! mIRC isn't capable of handling this
so expect massive lag to rasterize a triangle!

Unzip this package to anywhere you wish, I reccomend making a folder in your
$mircdir, name it affine or something. extract the files to that folder and
in mIRC, load the file "triangle.mrc" into your remotes.


-----------------------------------------------------------------------------------

There are four general examples.

Example #1: /triexample1
 This draws a square, perfectly facing us with the texture. It's slightly larger
 than the texture to illustrate how it can scale an image.

Example #2: /triexample2
  This draws the same square rotated in 3D space 45 degrees on the x,y axis.

Example #3: /triexample3
  This draws the same square rotated in 3D space -45 degrees on the x,y axis.

Example #4: /triexample4
  This draws the same square rotated in 3D space 45 degrees z axis.

-----------------------------------------------------------------------------------

A More advanced example

/tricube <x rotation> <y rotation> <z rotation>

You can start this by just typing "/tricube" or you can pass your own 0-359 values
to rotate the cube in any angle you wish.

if you hold your left mouse button and drag, the cube rotates based on where your
mouse is. A wireframe is shown since texture mapping takes a long time. Each triangle
is labelled so you can see which face you are actually looking at. It uses a timer that
waits a half second before rasterizing the triangles, so once your mouse sits still or
you let go of the mouse button, 1/2 second later it starts filling the triangles. I
purposefully didn't use -n so you can see it stepping thru as it fills each triangle.


==================================================================================
The theory
==================================================================================

In general, there are only three types of triangles. Theres a flat bottom, flat
top, or neither, which is a special case where it takes one of each.

 Type 1: Flat Bottom Triangle
 |\
 | \
 |  \ 
 |___\


 Type 2: Flat Top Triangle
  ____
 |   /
 |  /
 | /
 |/


 Type 3: Neither
 |\
 | \
 |  \   Flat Bottom triangle
 |___\
 |   /
 |  /    Flat Top triangle
 | /
 |/
      
==================================================================================
Generalized Explanation on how it works
==================================================================================

from any given one point on the triangle, there are two lines that connect to the
other points. Knowing this, if you simotaneously followed the slope along each line
the Y values between each point on the lines are equal. Since the Y's are equal, the
x's inbetween can be simply stepped across and filled.

Example: the dashes represent the x values being stepped across from x,y of line one
         to x,y of line two
 |\
 |-\
 |--\
 |---\ 
 |----\
 |-----\

if we don't have identical ending Y values, our point in which we draw from has to
change.

Example: The right line ends before the left line, so we have to switch slopes. The
         dashes show step across x1,y1 to x2,y2 and the +'s show when we switch slopes.
 |\
 |-\
 |--\
 |---\ 
 |----\
 |-----\
 |+++++/
 |++++/
 |+++/
 |++/
 |+/
 |/

==================================================================================
Mathmatical Concepts
==================================================================================

Most people should be familliar with slopes. If you remember some basic math you
probably did in high school, a slope by definition is rise over run, which is
calculated by:

y2 - y1
------- = y change for every x
x2 - x1

which tells us for every change in X, y changes respectively, hence the Rise/Run.
Since our y's are given, we want the opposite, we want to know the Run/Rise, which
is quite simple, its just the reverse.

x2 - x1
------- = x change for every y
y2 - y1

Now the beauty of knowing this. Since we know we're using the difference in the Y's
to find our slope, the difference in Y's is a constant, and can be used to find the
increment for x, u, and v.

u2 - u1
------- = u change for every y
y2 - y1

v2 - v1
------- = v change for every y
y2 - y1

So now, for every Y change, x is inc'd by the xslope, u is inc'd by the uslope, and
v is inc'd by the vslope.

----------------------------------------------------------------------------------
Breakdown of the X,U,V slopes for both lines protruding from a point
----------------------------------------------------------------------------------
x1,y1 u1,v1 is our starting point. x2,y2 u2,v2 is the left side final point, and 
x3,y3 u3,v3 is the right side final point.

so, we're going to call difference in X divided by difference in y for the left
"dxdyL" and similar for u and v. and for the right side we will use "dxdyR"

dxdyL = (x2 - x1) / (y2 - y1)
dudyL = (u2 - u1) / (y2 - y1)
dvdyL = (v2 - v1) / (y2 - y1)

dxdyR = (x3 - x1) / (y3 - y1)
dudyR = (u3 - u1) / (y3 - y1)
dvdyR = (v3 - v1) / (y3 - y1)

----------------------------------------------------------------------------------
Defining the x value of the left and right side, and our y
----------------------------------------------------------------------------------

Since both the left and the right side originate from the same point, we can
define these as equals for our place to start. y is the same for both, so we do not
need a yL and a yR.

xL = xR = x1
uL = uR = u1
vL = vR = v1
y = y1

----------------------------------------------------------------------------------
Pseudo code for our step thru the y's
----------------------------------------------------------------------------------

--------------=!Important!= =!Important!= =!Important!= =!Important!=-------------

This Pseudo code is generalized as if everything is in a positive direction!

--------------=!Important!= =!Important!= =!Important!= =!Important!=-------------

if y2 is greater than y3, y1 thru y2 is all of our y's if not, then
y1 thru y3 is all our y's.

yend = y2 or y3 (depending on which is larger)

while (y <= yend) {

  Draw X's between xL and xR (see the next section for how this is done)

  if (y = the lesser y of y2 or y3) {
   change our slopes for the side that changes
  }

  increase xL by xLslope (dxdyL)
  increase uL by uLslope (dudyL)
  increase vL by vLslope (dvdyL)

  increase xR by xRslope (dxdyR)
  increase uR by uRslope (dudyR)
  increase vR by vRslope (dvdyR)

  increase y by 1
}

----------------------------------------------------------------------------------
Pseudo code for our step thru the x's at a given y
----------------------------------------------------------------------------------

--------------=!Important!= =!Important!= =!Important!= =!Important!=-------------

This Pseudo code is generalized as if everything is in a positive direction!

--------------=!Important!= =!Important!= =!Important!= =!Important!=-------------

Here we need to know what x to start at, and what x to end at, we already know that.
its our xL and xR, but we don't want to modify these so we need a new variable.
We also need our u,v coordinates to know the x,y on the texture. since we are going
left to right, the u,v is going to start at uL, and vL. 

xstart = xL
xend = xR
ui = uL
vi = vL

we need another slope calculation to know the changes in u,v per x. so lets define
these. we're going to use "du" for the difference in u's slope, and "dv" for the
difference in v's slope.

du = (uR - uL) / (xend - xstart)
dv = (vR - vL) / (xend - xstart)

whew! now that we have our slopes for the U,V coordinates, lets define a variable to
increase for each x, and draw our texture to the triangle.

x = xstart
while (x <= xend) {
  draw dot at x,y with color from texture at ui,vi

  increase ui by uslope (du)
  increase vi by vslope (dv)

  increase x by 1
}

==================================================================================
End Notes
==================================================================================

Whew! Finally! That's a lot of calculations! Anyways, I hope you have a much better
understanding on how to affine texture map a triangle.

On a further note, affine texture maping is NOT and I must emphasize on NOT a 3D
system. This only texture maps perfectly from 2D to 2D. Allthough you can use this
system for mapping 2D triangles specified from transformed 3d coordinates to 2d space
this is going to cause a bad skew on the triangle if all the points do not share the
same Z value. hence why Affine texture mapping is NOT perspectively correct. It'd
take some work but you could account for each point of the triangles Z to have a 
Z slope and modify the u,v coordinate based on each pixels Z value.

I may make a perspectively correct method and share that as well.