This little addon has been created to easily find the username with X from users of a specific channel.
I create this addon for my own use, I offer it to you in case it could interess someone.
I know that a couple of features could be added, but as I tell you before, I do mIRC script only for
my personal use.

You can access the addon by a right-click on a channel or with the command: /userx

You will be able to join me on the Undernet network, my nickname is Slash_2* and I'm on #scripteur.
You can also leave me private message on both site www.mircscripts.org or www.scriptsdb.org

Thanks to J_To (#scripteur @ Undernet) for doing some test and give me some suggestions.


Enjoy! ... and have a nice fucking day!!



--------------------------------------------------------------------------------------------------------
Simple addon pour trouver facilement les utilisateurs enregistr�s � X sur le r�seau Undernet.
J'ai cr�� ce module, je vous le pr�sente au cas ou il pourrait vous �tre utile.
Le concept se base sur les adresses des usagers.

Je sais que plusieurs trucs auraient pu �tre ajout�s en options, mais comme je script pour mon usage personnel, je m'en fou!
Module accessible avec le Menu Channel (right click dans un channel) ou avec la commande /userx

Vous pouvez me rejoindre sur http://www.scriptsdb.org (Username = Slash) (Utilisez les messages priv�s!)
Je suis sur le r�seau Undernet sous le nick de Slash_2* sur le #scripteur.

Merci � J_To (#scripteur @ Undernet) pour le test et les suggestions.


Enjoy! ... and have a nice fucking day!!