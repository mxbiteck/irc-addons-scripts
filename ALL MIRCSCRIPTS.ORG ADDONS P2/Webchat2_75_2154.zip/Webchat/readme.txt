Proxy Web Chat v2.75 (c) Averell 2003-2006

=====================================

INSTALLATION (Francophones)

D�zipper le fichier dans un dossier contenant une version r�cente de mirc (au moins 6.01). Taper /load -rs webchat/webchat.mrc .

Attention: la SEULE question que vous pose cet addon est la langue d'utilisation. Repondez-y correctement, ou retapez /load -rs webchat.mrc en cas d'erreur.

Voil�, c'en est fini pour l'installation!

=====================================

INSTALLATION (Anglophones)

Unzip the file in a folder with a recent release of mirc (mirc 6.01 at least). Type /load -rs webchat/webchat.mrc .

Caution: the *only* question that will be immediately asked for is your preferred language (french or english). If you pressed the bad button, please re-type /load -rs webchat.mrc .

That's fine :)

Technical support: Averell ( webmaster@mircscriptsfrfm.com )
