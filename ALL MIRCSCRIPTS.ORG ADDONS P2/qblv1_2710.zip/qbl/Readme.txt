Queryblocker v1.0
by cleus

1. Introduction
2. How to install
3. Notes
4. Contact
5. Credits

1. INTRODUCTION

    Queryblocker v1.0 is an addon that blocks your incoming queries.
    What all it do is, closing incoming query windows and informing you.


2. HOW TO INSTALL

    2.1. Extracting
	  Extract downloaded .zip file into your mIRC directory.
	  The important thing here is, extracting directory.
	  Let's say your mIRC dir is 'C:\mIRC', therefore your
	  extracting dir should be 'C:\mIRC\qbl'.

	  As you may understand, all the files should be located at
	  'C:\mIRC\qbl\' such as, 'C:\mIRC\qbl\queryblocker.mrc',
	  'C:\mIRC\qbl\lang' etc. I hope that would be helpful for
	  newbies

    2.2. Loading
	  After completing step 2.1, you have to 'load' this addon.
	  In order to load this addon, you should type:
	  '/load -rs qbl\queryblocker.mrc' and then hit the enter key.

	  If mIRC ask a question, simply click YES. If you do all the
	  things correct, Queryblocker should run with any problems.


3. NOTES

    According to the older versions' users, due to Queryblocker's
    multi-language system, sometimes they can't see any texts on
    the boxes on dialogs etc. This is because, there was something
    gone wrong the language files. Even if I coded this addon
    in a way that it would keep working if mIRC's directory has
    spaces in it, that might fail. To solve this bug(?), do the followings

    * Reset the variable of default language pack's name
	(I assume  that all the files are in 'qbl' dir)
	/set %qblst.lang qbl\lang\English.qbl

    * Move mIRC into a new directory
	Try to move mIRC's directory into a directory that have no spaces.
	(Ex: Use C:\mIRC instead of C:\Program Files\mIRC)

    * Contact me
	Feel free to add me to your MSN list. eldorben@hotmail.com

    If you want to send your language's language pack to me, simply contact me.


4. CONTACT

    e-mail: eldorben@hotmail.com
    url   : www.tchat.gen.tr


5. CREDITS

    DragonZap for the file mdx.dll
    -
    Crinul for the Romana language pack
    Hologram for the Deutsch language pack
    Jim for the Lietuviu language pack
    Xenon for the Dansk language pack
    .. and all the testers