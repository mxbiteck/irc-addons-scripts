FQS v5.0

Author:	Frog
Find me:	RazorvilleIRC: irc.razorville.co.uk



Basically..this is a Quoter, and that's about it. It uses two main dialogs, which a few other ones here and there. They should all look ok..but if for some reason, one of them doesn't, let me know.

It comes with mdx.dll because, if you want to, you can have colors on the main dialog. There's plenty of options..filtering bad words (which you define), stripping color codes, playing options, etc.

Quick aliases:

/qplay [-a/l[n]/s] a for channel, s for echoing them to you. (see below for -l[n])
/findq [-a/s] [word] Searches your file for word(s) specified and displays the Quote(s) containing it, and results.
/badq [word] adds a word to the "badword" list.
/delq [n] Deletes Nth Quote.

Have fun?

Lemme know if there's bugs of any kind. Just memo me with what happened, how to recreate it, etc.

--------------------------------

v5.0

Let me see..since 4.7, I've scanned through and tried my best to improve all code, and remove anything unnecessary, and I think I did ok as far as the internal stuff goes..haha.

I filled in the empty space in the main dialog with some useless crap..IF I decide to do anything else to this, I'll probably add something of slight use there..but until then..

Reverse found me on IRC and inquired about a !trigger option, which I've added. Use !FQuote [word] to have a random quote with that word in it sent to the active channel.

-Note on that:	The method I had to end up using for that is a bit..rough, and will cause a slight pause when being used, 		due to the while loop involved. I may end up using the DLL on saw on ms.org that doesn't freeze mIRC 		when while loops are used with this..I'm not sure yet.

Due to the lack of popularity in these types of Scripts, especially mine, I think v5.0 is the last of this. I only released this update because Reverse (Lex-) inquired about the trigger events. So, unless someone else randomly PMs me on IRC asking about a feature to add/improve, I think I'm done with this.

v4.7

Eh..fixed a few bugs. A lack of mdx.dll caused a bug due to the seperate dialogs, so I went ahead and fixed that, then found one regarding the saving method I scripted in using a timer. Sigh_ helped me fix that, but I later just removed it, so now there's one less option that wasn't really needed.

So as far as I know, any and all bugs are gone.

Just fixed another slight quirk, nothing too important.

There's a small little space on the main dialog that I can't seem to find anything to put in. Maybe an edit allowing you to modify the colors of the output if you wish..I was thinking about doing something like that, so, maybe I will next time.

Any suggestions as to what I could put there (or any bugs, because there still might be a couple), just let me know (even if you aren't going to keep using it), I'm not that hard to get ahold of.

v4.5

Alright..let me see..

-New switch, -l[n] to /qplay.
 -Syntax: /qplay -l[n], where n is a line of FQuotes.txt. (or your Quote file)
-With the help of a friend of mine, I replaced the internal alias /qcheck, with a FAR more efficient one, which also fixed a bug involving filtered "bad words" that had color codes next to them.

v4.2

Mmmk. Since the dialogs were a bit..ugly as hell, I redesigned most, if not all, of them. There's now..

-Two main dialogs, one for Quotes, one for options.
-The dialog for color settings was cleaned up a bit.
-A few internal code changes were made.

Note: I'm still not done with this thing..I, obviously, add more as I go on and see fit. Next update will most likely be soon. I may add options for color in the output..and have it so users can define their own color(s)/output.

v4.0

Alright. I've completely re-done most of the internal stuff. There are no longer options for filtering the color in the output, because now there is NO color in any of the output. There is, however, still the same option to have bad words or color codes stripped from the Quotes; just none of the output (like the pre/suffix on the quotes) will have color.

Someone on Razorville started using this one day, and after talking to him I got to working on a few slight bugs regarding a "No color in output" option I had added to the version I was using. After it bugged me enough, I just completely stripped out all sloppy code and color codes from the thing.

It's gone from..1100+ lines, to about 900, then to around 1050, and now: 800 or so. There may be a few things I need to work on still..maybe make a better dialog for it..but things like this aren't really too popular, so I may just leave it at this.

Anyway, once again, any bugs or odd occurances with it, just come to Razorville and let me know.

Frog