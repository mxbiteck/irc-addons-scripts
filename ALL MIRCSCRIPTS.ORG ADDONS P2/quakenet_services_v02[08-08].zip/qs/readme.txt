QuakeNet services v0.2
----------------------

The MDX.DLL and tux.ico don't need to be placed in the same directory
as the script anymore, using the $findfile and $shortfn. mIRC will
automatically search for the files on startup. You can remove or move
them, the script will work fine without them.

To open the dialog, just type /qs and wait.

MDX is created by DragonZap (MDX.DLL)
tux.ico is created by darkproject.com

--

This script is distributed under the terms of the
General Public Licens version 2, June 1991.

QuakeNet services v0.2
Copyright (C) 2004 Erik Nystr�m (mafix)

#techsweden, QuakeNet

