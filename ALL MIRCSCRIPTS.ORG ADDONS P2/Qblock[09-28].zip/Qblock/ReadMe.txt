;Query Spam Blocker v1.4 - by da^hype (da-hype@hirc.org)
;website: http://www.hirc.org
;date: September 28th, 2004


Description:
 ----------
	This addon enables you to add key words you want to block. If Sombody types 
any of the keywords in the list, it will be blocked. So you won't see in the channel
or private msg.
 	



Version Updates
 ----------

September 28th, 2004 : - v1.4

  - Cleaned up code.
  - More local aliases/
  - Used $scriptdir
  - Updated urls

February 9th, 2003 : - v1.3

 - Made dialog a bit bigger
 - Changed the about dialog
 - added "Echo spam to status" and "save spam to @window" options. Basically if 
   somebody spams you, your can view it in @window or status. Or neither.
 - Made edit boxes disable when options are not checked.
 - Fixed "list of words" list, so you can't enter the same keyword more than once.
   Added a "error" dialog for this. :D
 - Let out some unset's in version 1.2, fixed that too.
 - Fixed enable and disable so u won't see in status when either one is checked.
 - Removed the notice to private msg spammers.
 


January 14th, 2003 : - v1.2
 
 - released v1.2
 - Re-arranged the dialog some more
 - Added query and channel punishments
 - Added An icon for this addon.
 - re-arranged the menu
 - Added an unload option. ( will unload all variables too )
 - Added a "Reset Counter" and "Reset Date" option


December 31th, 2002 : - v1.1
 
 - released v1.1
 - Re-arranged the dialog a bit
 - removed the web advertisment on the amsg counter
 - fixed the alias for the .dll's



December 28th, 2002 : - v1.0

 - 1st release
 - Only Blocks Text Spam on channel\Query.




Installing
 ----------
 To install the script you must unzip the QBlock.zip file (which you have already 
 done), then you must load the QBlock.mrc file in mIRC. 

 To load the file you can either use the /load command by typing the following in
 mIRC. You must change 'directory' to the directory that it has been saved to.
  
   /load -rs directory\QBlock.mrc

 For example if you saved it to your desktop you would type:

   /load -rs c:\mirc\QBlock\QBlock.mrc

 make sure your directory does not have spaces in it.

 The second way to load the script is by opening the remote script editor by either
 selecting Tools and Remote... from the menu or by pressing alt+r, then you must
 select File, Load then Script. You will be able to find and load the addon from there
 (note you must by looking for file type *.mrc and not *.ini).

 Once you have completed the install you should have a message in your status window
 confirmin gthat you have loaded the script. If you have, then you have installed the
 addon.


 Further help
  ------------
  
  Join #AntiSpamBot-Help on DALnet or #hirc.help on WebChat or go to the antispam bot and #hirc.help site @ http://antispambothelp.cjb.net and http://www.hirc.org to ask questions regarding the script and check for updates.














