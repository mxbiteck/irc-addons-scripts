 ______________________
|                      |
| Quake AMP by impulZ  |
|          Version 1.2 |
|______________________|

  I. Installation
 II. Usage
III. About & Credits

Note: The script will work for Quake 3, RTCW, Enemy-Territory, Half-Life and Half-Life� and more :)

I. Installation:
----------------

Just place the folder "ingamemp3" anywhere on your HDD (i recommend you
to use the folder of the script). Then go in your mIRC and type:
/load -rs qamp/qamp.mrc
if you placed the folder in your mIRC main directory. Or type:
/load -rs C:\Programme\qamp\qamp.mrc
and replace the path with your own path.

II. Usage:
----------

If you have loaded the Script a menu will appear with the Settings you need
to set up before starting your game.
Note: The "?" buttons will help you :)

If you enable the \WinAmp command you can type "\WinAmp <command>" in the Quake 3 console.
Note: <command> can be replaced with STOP, PLAY, NEXT, PREV, etc.

III. About & Credits:
---------------------

Thanks go out to hanso, anti & hel1x for supporting my idea :)
hel1x need to be thanked in two ways he coded the WinAmp.dll wich works with all WinAmp
versions and the wa_link.dll creators need to be thanked, too.
However, i'm proud of the qIRC coder because he "made" the technology for the Quake sending
things...
Thank you all.

impulZ, 16.01.2005