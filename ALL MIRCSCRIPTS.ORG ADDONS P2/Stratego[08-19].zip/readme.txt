 __________________________________
|
| Stratego
|__________________________________


To load this addon open your mIRC and type:

  //load -rs $+(",<dir>\stratego.mrc,")


For example, if you have extracted stratego.zip file in c:\my_documents, open your mIRC and type:

  //load -rs $+(",c:\my_documents\stratego.mrc,")


A dialog with a warning that this script contains initialization commands will pop up. Click on the "Yes" button and you are ready to go!