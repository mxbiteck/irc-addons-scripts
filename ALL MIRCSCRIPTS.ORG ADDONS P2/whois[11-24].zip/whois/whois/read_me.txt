;^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~;
; Whois/UWhoi Output to a GUI Dialog Table By Sparkle        ;
; Credits: KathY                                             ;
; Contect:                                                   ;
; DALnet #cairo, #Helpdesk (sparkle)                         ;
; E-mail: Coldbreeze@Arcor.de                                ;
;                                                            ;
'^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~'


* Information about Installation

1: Unzip the file into your mIRC directory 
2: To Load this into your remotes, there are TWO way
     a) press ALT + R then click File > choose Load, find the path to the file Whois.MRC then click Ok
     b) put the unzipped folder in your mIRC Dirctory and Type: //load -rs " $+ $findfile($mircdirwhois,*Whois.mrc,1) $+ "

[NOW] You have the add-on loaded


* What does this Addon do ?
 .This addon takes the Whoi/UWho both or any of them and put it in a friendly Dialog table
 with a list view and some extra options Send CTCP/Message/Notice/Notify(UNotify)/Query
 and it can be enabled/disabled too via the control dialog

* How to use this Addon ?
 .Once you Enable the option the addon works automaticly
 if you enable the Whois output, whenever you whois a Nickname .. the whois will be displayed
 inside the dialog, automaticly no matter how did you call the Whois, /whois Nick, /w Nick
 or from the nicklist popups even
 .same goes to the UWho thing, if you type /uwho Nick or choose it from the popups

PS(s):
  1: you can disable the Whois dialog when it is Opened via the small checkbox []Enable
  2: you can whois yourself simpley by typing /W .. Just /W
 
  
* How To UNLOAD this add-on
  simpley type //unload -rs Whois.MRC
  Or.. Via the Popup Menu (Menubar/Status/Channel)



* Credits
  I should thank KathY for the idea, she suggested me to make my whois output in a dialog
  and she also suggested the UWho thing :) she tested this addon for possible bugs and here it is
  Thanks :)



Enjoy

 Sparkle/Divine
 
 Coldbreeze@Arcor.de