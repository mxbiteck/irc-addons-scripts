RemIRC v1.0 by [K]LiNeD
--------------------------------------------
This addon allows your to use the remote control that came with your Pinnacle PCTV Tv card
to control your mIRC Client.
--------------------------------------------

Install notes.
  . In order to install the addon you'll have to extract the .zip file to any location in your 
    hard drive. Then run mIRC and write /load -rs <the-path-to-the-extracted-files>
    (Eg. /load -rs C:\RemIRC\remirc.mrc)
    If you don't know the path you can type //load -rs $sfile($mircdir) and then search for
    the RemIRC.mrc file.
  . If installation is sucessfull you should see information about the addon on your status
    window.

---------------------------------------------

User Tips

  . In order for you to make a good use of the addon you should know mIRC keyboard shortcuts
    since the addon only supports Key Sequence emulation and run commands.
  . When editing Key Sequences note that key presses are represented by the name of the key
    and key releases are the same but with a ^ behind.
    Eg.
      . ALT   - Represents pressing ALT
      . ^ALT  - Represents releasing ALT
  . Remote keys edition will only work when PCTV software is detected. So make sure you
    specify the right path in the general config. (Eg. C:\Programs\Pinnacle\Pinnacle)
  . The "PCTV Installation detection" icon on the bottom of the main dialog represents
    wether the installation has been detected or not. 
      . Red   - Check the PCTV path in the General Config
      . Green - Installation detected. All functioning properly.

-----------------------------------------------

Requirements
  . A PCTV Remote Control and the respective software.
    (You don't actually need the TV card nor the tv card software, just the remote and it's
     software)
  . The remote control software must be running when you want to use the remote in mIRC

------------------------------------------------

Future Implementations
  . mIRC commands
  . Config remote to control all the PC (not only mIRC)
  
  . And maybe, with a little bit of luck, PCTV software independence.
    (because I still don't have a dll that listens on COM ports)

-------------------------------------------------

[K]LiNeD (SCT @ PTnet) 2004 - ruption@netvisao.pt (mail/msn)
