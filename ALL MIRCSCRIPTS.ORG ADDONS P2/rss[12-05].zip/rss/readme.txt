Rss Reader v2.0 for mIRC
------------------------

Installation:
-------------
 * Unzip the file (Rss.zip) to your mIRC dir.
   The files should be extracted to a new folder (example: C:\mIRC\rss)
 * Run mIRC and type in the command line '/load -rs rss\rss.mrc'


Using the addon:
----------------
Simple to use, just type /rssreader.
 
   * First you have to config the rss reader by left clicking on treeview control. 
      --> ADD button to add a unique ID and the corresponding URL, so it will be easy after to refer to
         this ID, and not the complete URL. 
      
      --> REMOVE will remove the couple (ID, URL) from the list view. 
      
      --> UPDATE button let you save the change you made in the config dialog. YOU MUST CLICK on UPDATE,
          or all your added url will be not be taking into account.
       
   * Then, you get to choose a ID from the tree, a left click on that ID, a click on Refresh, to retrieve the rss from 
   the internet. hover the mouse over the tree nodes, to see the coressponding adress.

   * Then, you get to click the item display in the menu, to show the news in the list view.

   * To Send a specific Title with a link a channel, double-click in the listview control.


HISTORY
-------
v 2.0
   added a listview control to show the content of the rss feeds. 
   another new design.

v 1.0alpha
   a new design, with a dockable switchbar.
   added a treeview control.
   no need to type in ugly command...

v 0.4
   Added Documentation.

v 0.3 
   Resolved the the same ID for two differet URL.
   Add some missing function for the hash table.
   Replace my httpget routine with Tomalak's one.

v 0.2 added a config dialog

v 0.1 First realese



Author:
 Nicknames: BlackHorus
 Channels:  #mirc, #winapi, #win32, #winprog
 Contact:   rss_reader@yahoo.fr

Thanks:
 * DragonZap (dragonzap1@aol.com) for the MDX.dll
 * Janno's XML.dll 
 * sais,argv[0],Pingu` from mirc channel
 * l3z4rD for the /ldid snippet.
 * tomalak for his httpget script and help
 * Yochai Timmer for his did-tree snippet.
 * Synthet|c 
 * dunkelzahn, qui a �crit la super bible


