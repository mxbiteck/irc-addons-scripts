Copyright (C) 2002-2005 HazliCyber Corp. Ltd. - Software Foundation.
All right reserved by MarHazK.
UNREALIRCD.DLL STATIC LIBRARY.
For UnrealIRCD 3.2.x Server Software
Created on May 2006, 13st at 7:15PM (South-East time +8:00GMT) by MarHazK.

--------------------------------------------------------------------

UNREALIRCD.DLL is for a mIRC program used to control an UnrealIRCD
service. UNREALIRCD.DLL is very useful to control an UnrealIRCD
service via mIRC software. Its only works on UnrealIRCD3.2 for any
version starting from version 3.2.1 and above including 3.2.4.

Supported Operation System:-
OS: Windows NT, 2000, XP, .NET (All version, including Servers,etc.)
Server Software: UnrealIRCD3.2
Server Software VErsion: 3.2.1 and above including 3.2.4.
Software: mIRC
RAM: 16MB of RAM or above.
Free SPACE: 500Kbs
UnrealIRCD version: ANY 3.2.x version.

UNREALIRCD.DLL has 5 functions.

start Function
- Allow you to start an UnrealIRCD Server service.
Syntax: //ECHO -a $dll(unrealircd.dll,start,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,start,0)
DLL RETURN: START_SUCCESS, START_FAILED

stop Function
- Allow you to stop an UnrealIRCD Server service
Syntax: //ECHO -a $dll(unrealircd.dll,stop,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,stop,0)
DLL RETURN: STOP_SUCCESS, STOP_FAILED

restart Function
- Allow you to restart an UnrealIRCD Server service.
Syntax: //ECHO -a $dll(unrealircd.dll,restart,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,restart,0)
DLL RETURN: RESTART_SUCCESS, RESTART_FAILED

install Function
- Allow you to install an UnrealIRCD Server service.
- NOTES: Please make sure you put UnrealIRCD.dll into
         an UnrealIRCD Directory.
Syntax: //ECHO -a $dll(unrealircd.dll,install,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,install,0)
DLL RETURN: INSTALL_SUCCESS, INSTALL_FAILED

uninstall Function
- Allow you to uninstall an UnrealIRCD Server service.
Syntax: //ECHO -a $dll(unrealircd.dll,uninstall,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,uninstall,0)
DLL RETURN: UNINSTALL_SUCCESS, UNINSTALL_FAILED

version Function
- Allow you to get an UnrealIRCD.DLL information and programmer.
Syntax: //ECHO -a $dll(unrealircd.dll,version,<data>)
EXAMPLE: //ECHO -a $dll(unrealircd.dll,version,0)
DLL RETURN: "Details of UnrealIRCD.dll"

--------------------------------------------------------------------
Notes:
Check this out. An UnrealIRCD 3.2.x version that was fixed and upgraded. And now, its works nicely and overall its all fixed.

You can START, STOP, RESTART, and REHASH your UnrealIRCD 3.2.x server via IRC client. Nothing to worry about because it has been fixed. By the way, its only works on UnrealIRCD version 3.2.1 and above, including version 3.2.4.

Enjoy with UnrealIRCD 3.2.x service controller and your servers/networks.

---------->>
For more information, visit www.geocities.com/marhazk
This software is legally registered under HazliCyber Corp. Ltd -
Software Foundation. All right reserved by MarhazK.

P/S: If you want to create or delete existed service, download
at www.geocities.com/marhazk. Its FREE.
IRC: #hazlicyber at hazlicyber.no-ip.info
     #kolej-abdillah at irc.dal.net
FREE: You get free IRCSC.DLL SOURCES for Visual C++. More, download
      at www.geocities.com/marhazk