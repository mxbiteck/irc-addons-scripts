//
// This SC software has been created by MarHazK
// UnrealIRCD 3.2.x version.
// All right reserved by MarHazK.
// Created on December 2004, 21st at 6:04PM (South-East time +8:00GMT) by MarHazK.
// Last updated on Dec 2005, 12nd at 1:27PM (South-East time +8:00GMT) by MarHazK.
//

#include "stdafx.h"
#include <windows.h>
#include <conio.h>  //Function used: outport(port,value),getch()
#include <stdio.h>  //Function used: printf,scanf
#include <ctype.h>  //Function used: toupper
#include <tlhelp32.h>
#include <winsvc.h> //Function for Services

static 	OSVERSIONINFO VerInfo;
typedef BOOL (*UCHANGESERVICECONFIG2)(SC_HANDLE, DWORD, LPVOID);
HMODULE hAdvapi;
UCHANGESERVICECONFIG2 uChangeServiceConfig2;

#define IRCD_SERVICE_CONTROL_REHASH 128

#include "UnrealIRCD.h"

extern "C" {
	void __stdcall LoadDll (LOADINFO *loadInfo) {
		return;
	}

	int __stdcall UnloadDll (int mTimeout) {
		if (mTimeout == 1) {
			return(0);
		}
		return(1);
	}

	// Just send an ECHO commands for mIRC.
	int __stdcall stop (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		SERVICE_STATUS status;
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCD", SERVICE_STOP); 
		ControlService(hService, SERVICE_CONTROL_STOP, &status);
		strcpy(data, "STOP_SUCCESS");
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return(3);
	}
	int __stdcall start (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCD", SERVICE_START); 
		if (StartService(hService, 0, NULL)) 
		{
			strcpy(data, "START_SUCCESS");
		}
		else {
			strcpy(data, "START_FAILED");
		}
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return(3);
	}
	int __stdcall restart (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		SERVICE_STATUS status;
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCD", SERVICE_STOP|SERVICE_START); 
		ControlService(hService, SERVICE_CONTROL_STOP, &status);
		if (StartService(hService, 0, NULL)) 
		{
			strcpy(data, "RESTART_SUCCESS");
		}
		else {
			strcpy(data, "RESTART_FAILED");
		}
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return(3);
	}
	int __stdcall rehash (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
	{
		SERVICE_STATUS status;
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCd", SERVICE_USER_DEFINED_CONTROL); 
		ControlService(hService, IRCD_SERVICE_CONTROL_REHASH, &status);
		strcpy(data, "REHASHED");
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return(3);
	}
	// Proccessed under MarHazK via COMMAND SEND...
	// Others Details (ADDITIONAL) by MarHazK
	int __stdcall install (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		SC_HANDLE hService, hSCManager;
		char path[MAX_PATH+1];
		char binpath[MAX_PATH+1];
		hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);

		GetModuleFileName(NULL,path,MAX_PATH);
		strcpy(binpath,path);
		strcat(binpath, "\\wircd.exe");
		hService = CreateService(hSCManager, "UnrealIRCd", "UnrealIRCd",
				 SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
				 SERVICE_AUTO_START, SERVICE_ERROR_NORMAL, binpath,
				 NULL, NULL, NULL, NULL, NULL); 
		if (hService) {
			strcpy(data, "INSTALL_SUCCESS");
		}
		else {
			strcpy(data, "INSTALL_FAILED");
		}
		SERVICE_DESCRIPTION info;
		info.lpDescription = "Internet Relay Chat Server. Allows users to chat with eachother via an IRC client.";
		ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &info);
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return (3);
	}
	int __stdcall uninstall (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
	{
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCd", DELETE); 
		if (DeleteService(hService)) {
			strcpy(data, "UNINSTALL_SUCCESS");
		}
		else {
			strcpy(data, "UNINSTALL_FAILED");
		}
		CloseServiceHandle(hService);
		CloseServiceHandle(hSCManager);
		return (3);
	}
	int __stdcall startup (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		SC_HANDLE hService = OpenService(hSCManager, "UnrealIRCd",
						 SERVICE_CHANGE_CONFIG|SERVICE_START); 

		if (ChangeServiceConfig(hService, SERVICE_NO_CHANGE,
			!stricmp(data, "auto") ? SERVICE_AUTO_START
			: SERVICE_DEMAND_START, SERVICE_NO_CHANGE,
			NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
			strcpy(data, "STARTUP_SUCCESS");
		}
		else {
			strcpy(data, "STARTUP_FAILED");
		}
		return (3);
	}
	int __stdcall version (HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
		strcpy(data, "UnrealIRCD 3.2 for DLL 1.0 - Copyright (C) 2002-2005 HazliCyber Corp. Ltd. by MarHazK. Download at www.hazlicyber.cjb.net");
		return(3);
	}
}

// NICK:  MarHazK
// IRC:   irc.webmas.net 6667
// IRC:   #WebMas
// EMAIL: marhazk@yahoo.com marhazk@webmas.net
// WWW:   www.webmas.net