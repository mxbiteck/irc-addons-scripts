************************************************************
*** Al-Qur'an addons v2.0 for mIRC and AnswerBook
*** Ported by mrptkln@gmail.com
*** Source Al-Qur'an from http://van.9f.com/
*** Any comments and bug please send to my email
************************************************************

Assalamualaikum Wr. Wb.

Description:
It's an Al-Qur'an addon for mIRC script. And also can be 
an addon for Answerbook's bot (www.answerbook.com). Tested
on mIRC v6.16, will work well for any 6.XX version.

Features:
- Support multi server and multi channel.
- Support many private messages.
- Configurable duration-time for playing multiple lines.
  To avoid many trigger at same time, this addon have duration
  time that you can change so you can avoid getting 'Excess 
  Flood'-ed.
- Configurable teks length. Some verses have a very long teks 
  that probably will get cut off because some irc-servers gave 
  limitation to the text length that are allowed within a line.
- Auto Random/Continuously verse. You can set the script to play 
  random verse or continuously, but for your channel's convenient
  chat, this Random script will only displayed if the chanel 
  is idling for any duration time.

Installation:
A. mIRC Addons
   1. Copy quran.mrc and quran.def on your mIRC directory/folder
   2. Open mIRC and from menubar: Tools - Scripts Editor (alt-R)
   3. On 'mIRC Scripts Editor's window menubar: File - Load
   4. Point to the quran.mrc and let the scripts run!
   5. You will be asked to find the quran.def
   6. Trigger command we use: !quran surah:verse 
      ex: !quran 1:1 -> This will play surah Al-Fatehah, ayat 1.
          !quran 1:0 -> This will show the surah name for surah 1.
          !quran on|off -> Turned ON or OFF Quran addon. OP/HOp only.
          !quran random -> This will play random verse.
          !quran play <from_surah:verse>-<to_surah:verse>
             * Playing range of surah, carefull for a long range
               of surah. This feature can be turned on/off.
          !quran autoPlay [on|off|random|continue|1-30|surah:verse]
             This command only can be accessed by Op or HOp
             * For auto play when channel is idling.
             * on|off       : turn the autoPlay on or off
             * random       : set the autoPlay playing only random verse
             * continue     : set the autoPlay playing continuously verse
                              you must set the surah:verse
             * 1-30         : duration, to make autoPlay run when the
                              channel idling for 1 (max 30) minutes.
             * surah:verse  : starting surah:verse for contiguous mode.
   7. To unload, follow step 1-2, on menubar File - Unload.
B. AnswerBook addons
   1. You can get the AnswerBook software from www.answerbook.com
   2. Copy quran.ad and quran.def to C:\Program Files\AnswerBook\addons 
      (unles you set it different)
   2. Type '?? abaddonload quran' without quote on your channel.
   3. Wait for a few minutes until the load information displayed.
   4. Use ?? quran:surah:ayat:
      exp: ?? quran:1:2: -> This will play surah Al-Fatehah, verse 2
           ?? quran:1:0: -> This will show the surah name for surah 1
   5. To unload, type '?? abaddonunload quran'

Known bugs/limitation:
- One thing that bug me that if there is an error in the 'quran.def'
  after I ported it to txt. Because the source is an HTML file, and 
  I use mIRC script to port it to txt file, I don't want to make 
  ruins any verse. If you find any wrong verse, please tell me about it.
- AutoPlay/Random verse timer NOT run automatically on every channel
  until someone saying something on channel.
- AutoPlay Continuous mode has a small disadvanted. It'll play perfectly
  continuous if you only have 1 channel, or it'll play verse 1 on channel A
  verse 2 on channel B and so on..
- As an addon this script don't have good flood protection. And if you get 
  laggin, still the duration-time can make you looks like flooding. 
- For AnswerBook users there is a limitation for displaying a long text.
  It'll be cut and added '(cut off to long)' on it.

Sorry for the English ^^ I'm from Indonesia, and if you have Quran/Hadist 
for Indonesia Version (or any language like to be ported) especially in 
.txt/.html format, I will glad to have a copy of it. :)

Credits:
- http://van.9f.com/, the Quran in HTML version.
- thanks to seed77 at www.mircscripts.org
- all email and all your suggestion. thx

Wassalamualaikum wr. wb.

10:45:06 06 Nopember 2004