README for Hash Sandwhich
version: 3.04
package date: October 5 2004

This program is absolutely self-explanatory
If people prove themselves to be dumber than I
thought possible, I may go into detail in
future releases...


TERMS OF USE

You are allowed to use and distribute this script as long
as you like and to as many people as you like, provided
that you do NOT modify it in any way shape or form, and
that when distributing it, you distribute ONLY the ORIGINAL
packaged ZIP file *including* the README file, and all
original ARTWORK.

By proceeding with installation, or upon the circumstance
that you have already installed this script, by using this
script, you hereby acknowledge that you have read and
fully understand the agreement above, and you agree to be
bound by its terms.

Author: mr_foot
dbaker@telus.net

*NOTE* *NOTE* *NOTE* *NOTE* *NOTE*

BINARY HASH TABLE FUNCTIONS HAVE BEEN DISABLED IN THIS VERSION
DUE TO THE FACT THAT I SIMPLY DO NOT UNDERSTAND WHAT THEY ARE
SO I DON'T FEEL CONFIDENT THAT I CAN FULLY SUPPORT THEM

If anyone want to explain them to me in a short email, then send
it over and I'll update the script!