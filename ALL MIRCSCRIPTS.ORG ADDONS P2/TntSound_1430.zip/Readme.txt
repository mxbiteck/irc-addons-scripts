;****** Tontito's Sound System for mirc ******
;********** Version 6.3 by Tontito ***********
;********* tontitoscript@hotmail.com *********


This Addon requires mIRC 6.03 or newer to run.
Can Play Mp3 and Wma Files.

to load this script type /load -rs dir_path/Tntsound.mrc

Use the Addon next to the folder images!!

All new versions in http://student.dei.uc.pt/~ricsal/Addons/


New VERSION 6.3
 
  Added protection case sounds are off giving the notice to turn them on in mirc options

  Fixed issue with files with more that one space together in name (reorganized engine)

  Fixed issue with sort by name in list (there is still a limitation related to mirc sort in list window)

  Due to all the changes mentioned before now this player is able to read all mp3 (if you have the right codecs)




New VERSION 6.2.1

  Fixed window issue under 6.21 mirc (now using the correct switch)




Version 6.2

  Since finaly Mirc 6.2 solves some problems with drawtext function, here goes the update so you can still see it well with your newest mirc (6.2)

  Now you can also listen songs from remote dirs (without the need to Map a network drive) thanks to new splay features from mirc

  For what i have seen the search in HD of songs is also faster with Mirc 6.2

  TNTSound is now able to import .m3u and .pls files (winamp playlist)
  Enjoy!! :)


Version 6.1 Extra

  Improved loading speed of mp3 files (several times faster depending of the system where it is running)

  Faster file listing in playlist (now it is instantaneous)

  Faster file sort

  File sort informs when files have some problems in names (2 or more spaces together or a space before .mp3) and removes then from list

  



Version 6.0 Final

  Improved shoutcast option (now seems to work with all shoutcast servers)

  Bug fix when starting the addon and playlist window was set to open

  Added, when showing in chans and privates what you are listening, file size in seconds
 


Version 5.9.1
  
  Just window fixs (thanks for StaticEdge notice)



Version 5.9

  Faster sort routines

  Bug fixed in playlist display

  Faster load of mp3s

  Fixed bug with online timers



Version 5.85

   Fixed reported bugs

   Added option to buffer more file when you are listening music using internet shoutcast

   Improved proxy configuration dialog for shoutcast music 
     (Now you can turn it on or off with out removing the proxy name or port)

   Fixed bug with shoutcast in some rare situations




version 5.83

   some bug fixes

   Now you can remove all the item in playlist that you select



version from 5.7 to 5.8

   Improved perfomance when listing files in playlist, removing items from list and in timer funtions (saved lots of cpu)

   Bug fix in timer when loading files to playlist

   Fixed bug when elapsed time stays at 00:00 (the problem presists in version 6.03) so the alias made by
     acidxwarp is going to continue.

   Several bug fixes(sort by name option when using links)

   Improved interface(more shortcut key, (j to search file in playlist ,p to open playlist
      and shift to move between playlist window and Tntsound window)

   Improved search file in playlist option(now you don't nead to press enter to start search)

   Now mp3 artist name - song name (not only mp3 name) can me displayed in channel and pvts

   Now the display area shows mp3 artist name - song name moving so you can read all the names

   Wen you select Tntsound in taskbar, if you have playlist window open , now the active 
     window is Tntsound.

   Small bug fix wen the player finds an invalid mp3 file

   Now A key adds single mp3 file to playlist and L loads mp3 directory (L key was adding single mp3)

   Some display fixs when using Windows Me




version 5.7

   Bug fix wen the mp3 that you are trying to play is not valid, now it outputs a message in display area.

   More improved shoutcast sound.

   Another bug fix in mp3 position bar


This is probably the last update that i put in this site. People were getting very anoid with me because
of all the updates, so from now on you can get the latest version in

      http://student.dei.uc.pt/~ricsal/Addons/




Has a good interface based in winamp.

Works like winamp in the basic commands like load mp3, play, stop, pause, ...
and uses keys z, x, c, v, b, l, up, down, -> and <- to do it just like winamp

Very light(tested in Celeron 333Mhz) and efficient.

Has menu Preferences to config for extra options (default options are off), please
use some of them wisely.

There is a line that you can edit for you to run this addon with a key
 it is the 1� line "alias f3 Tntsound". Like this you can put it runing by pressing
 f3, if you can�t use this key change the f3 to another *F*  examp. sf5 (shift F5)

Files are sorted in playlist by name.

Option to chose color in playlist lines (Preferences Menu)

Option to save and load playlists (.ric files)

Protection for files with char not recognized by $findfile 

Drag and drop option. (This function changes mirc.ini file so mirc must restart)
  ->> (BEFORE you use this option backup your mirc.ini file in case anything goes wrong and you have
         some information on it) 
    You can drag and drop mp3, wma and ric (playlist) files with no bugs
    Drag and Drop options are configed by preferences menu.
    Drag and Drop options don't overwrite other dradgrop options in mirc.ini




NOTE: some Mp3 files may not run with this script. The problem is in the Mp3 files.
      In this cases the addon displays an error message in Display mp3 name area . Thanks

If you find any annoying bug or you have a sugestion please email me it.
                     tontitoscript@hotmail.com

p.s sorry about my english :)