System Info by MTec89
http://mtec89net.com

to load:
//load -rs si\si.mrc

to unload:
/unload -rs si.mrc

for additional help look at the file 'index.html'