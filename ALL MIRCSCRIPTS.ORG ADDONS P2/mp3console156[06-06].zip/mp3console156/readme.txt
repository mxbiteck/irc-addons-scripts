MP3 Console v1.56 written by Snake (liquidsnake@sapo.pt)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:;;;
;;;                                                                                                             ;;;
;;; After unzipped, type /load -rs <path to mp3 console .mrc file> on mirc to load this addon into it, and type ;;;
;;; /mp3c to display the main dialog box. You can also type /mp3help to learn more about this addon             ;;;
;;;                                                                                                             ;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:;;;;

:::::::::::::::: DISCLAIMER :::;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
:::                                                                                                           :::
::: You don't have to ask my permission to use this addon on your mIRC script or even modify it. You are free :::
::: to do whatever you want to it. You don't even have to give me credits for it, despite the fact that I do  :::
::: like to get credits for what I do. You are also welcome to report bugs and give sugestions. However, I    :::
::: don't have to reply to any questions or give any help concerning this addon, or even mIRC scripting at    :::
::: all. If I do reply to any email, chat or whatever means you use to contact me, you are just lucky.        :::
:::                                                                                                           :::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

::: Whats new (v1.56) :::

 - Fixed script's path bug when loading it outside of mIRC folder
 - Fixed Scrool markee glitch

::: Version 1.55 :::

 - Smaller dialog box
 - Added volume control on main dialog
 - Added option to play only selected song
 - Fixed glitch that would send normal text instead of an action when advertising to the active window
 - Add listfiles.dll by Misanthrop, in order to make the action of adding an entire folder into the playlist a quicker task

::: Version 1.53 :::

 - Fixed time counter bug that didn't displayed hours
 - Fixed bug that would advertise the current song at an active query window even if set not to advertise at all
 - Fixed bug that would advertise the current music only to channels even if set to advertise it also at queries
 - Fixed bug that made the timer counter to stop when disconnecting from all connections
 - Added <pos> tag to the mp3 advertisement message, to retrieve the current elapsed time of the current music
 - When an advertisement occurs, it will now also be sent to all connections

::: Version 1.52 :::

 - Added option to advertise the current song only in the active window
 - Updated to mIRC 6.16

::: Version 1.51 :::

 - Status window issue fixed
 - Moved repeat and loop to "Method" branch in main dialog
 - Removed statusbar dislog stuff that wasn't suposed to be in thid addon

::: Version 1.5 :::

- Removed edialogs.dll because of its obsolete and too big
- Add use of file handling commands to increase eficiency
- Changed playlist display
- Added <size> tag
- If the MP3 title is to long to the text box, it will rotate in classic winamp style
- Added command /mp3show to send message to a specific channel/query 
- Many bugs fixed, I won't bother to list then because I just can't remember all of them
- Updated to mIRC 6.12