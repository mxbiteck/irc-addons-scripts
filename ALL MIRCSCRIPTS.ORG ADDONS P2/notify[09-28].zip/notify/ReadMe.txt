;MSN Notify v1.5 - by da^hype (da-hype@hirc.org)
;website: http://www.hirc.org
;malaysian made



Contents:
 ----------

  1. Description
  2. Version Updates
  3. Installing
  4. Help
  5. Further help
  6  Thanks



Description:
 ----------
	A dialoged notify list, with a MSN Messenger look.
 	


Version Updates
 ----------

Sept 28th, 2004 : - v1.5

  - Used $scriptdir
  - Updated urls
  - Added more local aliases.
  - Cleaned codes



July 22th, 2003 : - v1.4

  - Fixed popups
  - Fixed dialog
  - Cleaned codes

May 6th, 2003 : - v1.3

  - Released 4th version
  - Fixed some more bugs.
  - Fixed dialog popup. and added icons to it.
  - Fixed aliases
  - Cleaned codes.
  


March 9th, 2003 : - v1.2

  - Released 3rd version
  - fixed some more bugs.
  - option to enable/disable sound.
  - menu check marks. saves settings to ini file.
  - re-sizeable dialog.


February 4th, 2003 : - v1.1

  - Released 2nd version.
  - fixed some bugs.
  - Added more options in Menu.
  - Used Popup.dll
  - Fixed weblink on "About"
  - Added Nicklist and Query Popups.
  - Updated ReadMe.txt


February 3rd, 2003 : - v1.0

 - 1st release

  


Installing
 ----------
 To install the script you must unzip the MSNnotify.zip file (which you have already 
 done), then you must load the notify.mrc file in mIRC. 

 To load the file you can either use the /load command by typing the following in
 mIRC. You must change 'directory' to the directory that it has been saved to.
  
   /load -rs directory\notify.mrc

 For example if you saved it to your desktop you would type:
 
   /load -rs c:\mirc\notify\notify.mrc <- OR -> /load -rs notify\notify.mrc


>>> MAKE SURE YOUR DIRECTORY DOES NOT HAVE SPACES IN IT! USE C:\MIRC FOR EXAMPLE.
    ALSO MAKE SURE YOU ARE USING MIRC 6.0 AND ABOVE!

 The second way to load the script is by opening the remote script editor by either
 selecting Tools and Remote... from the menu or by pressing alt+r, then you must
 select File, Load then Script. You will be able to find and load the addon from there
 (note you must by looking for file type *.mrc and not *.ini).

 Once you have completed the install you should have a message in your status window
 confirming that you have loaded the script. If you have, then you have installed the
 addon.


 Help
  ---

    SImply type /nlist to open the dialog. then right click on the listbox 
  to add or remove a person to notify list. Or you used the menu by going to 
  "tools >> Add ad Contact.." . You can also just type /notify darth^maul on mirc. :P
  
  When a user logs on, you will hear a sound play just like the REAL MSN. :D



 Further help
  ------------
  
  Join #hirc.help on WebChat or go to http://www.hirc.org to ask questions 
  regarding the script and check for updates. You could also email me.


Thanks
  ------------
 A special thanks to #hirc.help idealers , Fury_G3, Double[0]seveN and tyso for helping me 
test and giving me ideas to improve it. 
Also thanks to YOU for using this addon. 
Thanks Again.

