###############################################
#  Winamp Controlicon                         #
#  By CRash&bleED                             #
#  Email: crash@hotpop.com                    #
#  http://crashb.kicks-ass.net/mirc.html      #
#                                             #
#  Using swamp.dll                            #
#  BY: LightStrike                            #
#  Email: LightStrike@mail.pt                 #
#                                             #
#  The Winamp icons were created by Nullsoft  #
#  http://www.winamp.com                      #
#  Winamp: it really whips the llama's ass!   #
###############################################


ABOUT:
Winamp Controlicon is a floating icon used to control Winamp.
It currently works with Winamp 2.x and 5.x at the moment, and no
plans to integrate Winamp 3.x support.  This is because I
personally do not like Winamp 3.x as it is a memory-hogging
waste of hard drive space.

Winamp Controlicon is fully customizable and easy to use.  And
while I think it is in great shape as of right now, feel free to
harrass me with your comments and suggestions.  If not, it won't
get any better!


INSTALLATION:
Unzip the contents of the zip file to your root mirc directory.
Then type:

/load -rs waci\waci.mrc


After it is loaded, to run it, type

/waci

or just right click in any channel or status window
and select "Winamp Controlicon".