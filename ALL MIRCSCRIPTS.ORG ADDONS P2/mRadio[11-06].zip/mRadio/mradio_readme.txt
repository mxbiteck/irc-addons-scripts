Name: mRadio!
Version: 4.3
Author: quickman
Created: July 21, 2002
Finished: November 5, 2004

I started this project long long ago back in the summer of 2002. It started as just a retriever of the top 20 streams that would pick up and play in winamp. Boy has it come a long way. Finally, I have decided to release it after 2+ years. I think this is my best creation ever and is really fun and useful. It is definatley my favorite.

This addon is a shoutcast client, which picks up the top 20 streams in several different genres/catergories and puts them in an easy to use dialog. Then you can select the mirror to play off of and it streams the music live and you can listen to it. It comes packed with an equalizer as well.

This addon is really easy to use. The GUI is top notch and after many GUI's I used with mRadio! I found this one the best.

This addon was tested with Winamp v 2.91 on a Pentium II, 400mhz 64mb RAM machine.

=======
Loading
=======

Type /load -rs path\to\mradio.mrc to load. It will bring up a box, choose YES. You must choose yes or else it won't work properly. Then, choose your folder where winamp is located(this is a must, get it right or it won't work) and choose your output mp3(for more info on output mp3, look below).

=======
Access
=======

Access is easy. Popup menubar, popup channel, or just type /mradio

=======
Usage
=======

Navigate the streams, and single/double click on a stream in the top listbox that you like. Then, at the bottom listbox(click the up/down arrow on the right to show/hide it) double click to choose a mirror.

===========
Dud Mirrors
===========

Not all mirrors will work with mRadio!. I would say 90% of them work. If one doesn't work, just choose another mirror. That is why I added a mirror listbox, incase one isn't working/compatible.

How to know if its a dud mirror? The music on my machine usually starts playing after a second or two. So if it takes more than 5 seconds, its a dud. Also, the info box will usually update if it is working, if its not, you will see a lot of unknowns.

=========
Info Box
=========

This box gives information about what you are listening to. If it can't retrieve certain information, it will return unknown. The text scrolls. Dud mirrors return a lot of unknowns.

========
Buttons
========

You have your basic stop/play buttons, plus the button on the right(the up/down arrow) hides the mirror list. Mixer, refresh, and output will list as follows.

======
Mixer
======

My favorite part of the mRadio!. It is an equalizer, 10 band parametric custom with presets. There are over 10 presets to choose, and you can turn the EQ off if you want. Also this is where you control the volume and panning(balance).

=======
Refresh
=======

Refreshes the current stream list.

==========
Output mp3
==========

Changes the output mp3 to where mRadio! writes its data to play. This is useful incase you want to record a stream to listen to later.

=========
Genre Box
=========

This listbox on the right has over 50 genres to choose from, making mRadio! very versitale.

=======
Future
=======

I may add a search function, an information box, and custom stream input. 
Yes, I did make a picwin version of mRadio! but it was too time consuming. Check back later for that.

========
Contact
========

I rarely hang out on IRC anymore, but if you want to find me I may be at irc.gamesurge.net #d2f, nicknamed plus or swordsdance. 

======
Final
======

Have fun with this addon... any bugs report to me.

;EOF