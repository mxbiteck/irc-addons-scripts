Telnet Relay v1.1

How to load and install:

Extract the .zip file and move the relay.mrc to your mIRC directory.
Type /load -rs relay.mrc

Setup:

After you type the load command (/load -rs relay.mrc) you should get a popup box asking for you to set your password.
This password will be used to log into your mIRC.

After you have set your password, mIRC will ask you to set your port.
This will be the port mIRC listens on for connections.

Usage:

Commands before relay is started:

/relay - Will start the relay and listens for connection.

Commands used when connected:

/commands - Lists commands
/list - Lists channels and private messages and their id number.
/msg - Will send your msg to a specified channel/private message.
/active - Will set the active channel/private messages that messages will be sent to.
/addchan - Will add the channel to the relay list (channels are on by default)
/delchan - Will remove channel relaying

Support:
I am always available at ccnncc99 <at> adminop.net
or on irc at #ns-1337 on irc.gamesurge.net