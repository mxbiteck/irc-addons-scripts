
Install:
	Put the xsearch.ini file into your mirc folder.
	Then load it by pasting this line in mirc: /load -rs xsearch.ini