This is my popup addon I`ve created. The idea was token from the Miranda IM popups but my aim was to make this addon without any dlls.
I will not write anything especial here, this addon is very interesting, so enjoy it.
This addon is a part of YAmIRC Script, which is being written by me.

---
Installation:
Just put the directory with the script\dll\readme in your mirc folder, open mIRC, open Scripts editor (ALT+R)
and select "Remote" Tab and select "Load" from "File" menu, chose popups.mrc and click "YES" at initialization warning if promted.

Or just type "/load -rs popups/popups.mrc" in the console.

Then just type "/popups" in the console or select "Popups" from MenuBar

This addon lets your mIRC work a bit more like Instant Mesenger. so if you work with another programs and somebody (for example)
msg`s you... you will see a special popups notifying you about this event.. so you don`t have to open mirc and see, who wrote to you...
or if you was disconnected, you will be informed about it immediately without having to stop your work and opening mirc.
That is alse very useful because sometimes you open your mirc and see that mirc is disconnected for a long time...

Don`t forget to unload old popups.mrc if you load a newer version.

---
BTW:
AMIP Checkbox work only in YAmIRC :)
And you are free to edit this script in any way you want and use it in your mirc scrips.
Just leave somewhere credits like "Original version by Virus-Z aka vrsz". Plz :)

Sorry for my English, correct me if something is written incorrectly.

---
Thanks to:
Khaled Mardam-Bey - for mIRC
DragonZap - for mdx-beta-0.92
Virus-Z aka vrsz (me) - for creating this addon ;)
You - for using this addon

If you think that you should be in this list, and I forgot to add you? Pmsg me ;)

---
Contacts:
kaborisov@zelnet.ru
You can write me in English and Russian.

---
Version history:
No history, this addon is a part of YAmIRC Script so... just a list of updates.

July 3nd, 2004:
First public release...

August 1st, 2004:
Fixed popup timer behavior, popups no longer remain when you disconnect from a server
Fixed asctime representation, "HH:mm" is now "hh:nn" and "HH:nn" if no AM/PM format is used
Changed a popups dialog, now we have tabs
Fixed word notifier regular expressions
You will no longer see popups if you receive messages or notices from server services i.e. Chanserv Nickserv Memoserv
Supressing popups method implemented
Improved script code
Whois popup added

August 8th, 2004:
Raw events fixed
Word notifier bug fixed
Popups no longer activate mirc window if mirc is minimized
Popups no longer remain when you disconnect by closing server window

August 17th, 2004:
If mirc is inactive and popup is shown, your current active window does not become inactive
Fixed a bug when you don`t receive a DCC request if DCCs are enabled in Popups
Popups now can be shown in the one of the four corners of desktop
Added simple logging feature

---
Author: Virus-Z aka vrsz
