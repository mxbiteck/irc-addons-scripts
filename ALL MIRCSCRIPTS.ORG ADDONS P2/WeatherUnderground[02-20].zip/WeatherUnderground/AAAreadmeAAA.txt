Weather Underground!
______________________________________________
Installation: Extract to mIRC directory and type: /load -rs WeatherUnderground/wunderground.mrc
(If you do NOT extract to mIRC directory type: /load -rs path/to/WeatherUnderground/wunderground.mrc)
______________________________________________
Instruction: Right click on the background in a channel and select "Weather Underground"

When the dialog is open, you may enter another zipcode or city in the edit box and hit 
"Get Forecast!"

You may also double click on the pictures in the forecast fore a detailed view
______________________________________________
February 13, 2005 (Third release v1.15):
Added "Personal Weather Stations" located in the menu
Fixed a few bugs

February 11, 2005 (Second release v1.1):
Added metric / english units conversion
Added more space for forecast and current conditions (Some things got cut off)

January 30, 2005 (First release v1.0): 
5 day forecast
Current conditions
Some other current information
Title shows location and updated time
(I will add a way to convert the forecast to �C instead of �F)
______________________________________________
Credits:
Thanks b00hp (bewp,bewpy) for the dialog!
www.wunderground.com for the weather!
______________________________________________
DO NOT NOT NOT NOT NOT NOT Edit and released as your own!!!!!!