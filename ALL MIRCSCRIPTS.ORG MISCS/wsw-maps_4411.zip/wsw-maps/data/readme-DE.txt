Dieses mIRC Addon ist ein Map-Downloader f�r die Warsow-Race.net - Server.

Man kann den Vergleichsordner (compare) getrennt vom Download Ordner einstellen.
Es wird lediglich gepr�ft ob in dem Vergleichsordner die Maps enthalten sind, die auf dem Server liegen. 
Runtergeladen werden sie dann in den Download-Ordner.
Compare und Download sollten also im Normalfall der gleiche Ordner sein.

Es wird beim ersten Start versucht den aktiven Basewsw Ordner zu ermitteln.
Im Regelfall liegt dieser nicht in dem Installationsordner, sondern unter 
Anwendungsdaten. Sollte der falsche Ordner gew�hlt sein, kann man diesen unter Settings auch manuell �ndern.

Compare und Download Ordner m�ssen beide angegeben werden und existieren, damit das Script funktionieren kann.

Die Angabe der Warsow.exe ist optional. Wenn man diese ebenfalls einstellt,
kann man durch einen doppelklick auf einen Mapnamen in der Liste gleich
Warsow mit der entsprechender Map starten. (Lokal)
Es k�nnen in der Zeile auch weitere Angaben gemacht werden.
Der Mapname wird am ende des Strings mit "map mapname" angeh�ngt.

Mit der �ber der Liste angezeigten Sortierungsfunktionen (Ordering), 
l�sst sich die Mapliste nach einem bestimmten Kriterium sortieren.
Leider ist in dem Fall mIRC / DCX nicht wirklich schnell, aber es funktioniert.

Sollten Fragen/W�nsche/Anregungen/Fehler entstehen, 
bitte bescheid sagen. (siehe About)