This mIRC addon is a map-downloader for the Warsow-Race.net Server.

You can set a different download folder and a comparative folder.
The maps from the server will verified with the maps in your comparing folder.
If you download them, they will be saved in the download folder.
Normally, those directorys should be the same folder.

At the first start of this script it will try to find your working basewsw folder.
Usually is this not in your install-directory, but in your appdata folder.
If it detect the wrong folder, you can set up manually a different one.

The compare- and download-folder must be set and must exist, otherwise the script wont work.

You can also select your Warsow.exe optional. If you do it, can u start Warsow (local) and load the specified map by doubleclicking in the maplist on a mapname.
In this command line you can also write a few parameters. The mapname will be added at the end off that string with "map mapname".

With the "Ordering" links about the maplist you can sort this list.
Unfortunately is in that case mIRC / DCX not very fast, but it works.

If you have questions/wishes or if some errors occur, give a feedback please. (see About)