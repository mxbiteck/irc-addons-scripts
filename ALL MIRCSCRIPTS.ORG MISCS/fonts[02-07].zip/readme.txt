electrik
revolution@programmer.net
#mircscripts.org on Undernet

Just extract the fonts to your X:\Windows\Fonts directory where 'X' is the drive where Microsoft Windows is installed.  These fonts are excellent for all you theme builders out there.

Have fun!