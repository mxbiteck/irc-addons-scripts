-----------------------------------
 mIRC SSL DLL pack
 version 0.9.8e

 http://ohok.nl/mirc/ssl
------------------------------------


 ===============
  LEGAL NOTICES
 ===============

  +++ The product licenses of the supplied files are included at the bottom of
      this file.  Please take notice to them as they apply to this pack.


  # This product includes software developed by the OpenSSL
    Project for use in the OpenSSL Toolkit. (http://www.openssl.org/)

  # This product includes cryptographic software written by Eric Young
    (eay@cryptsoft.com)

  # This product includes software written by Tim Hudson (tjh@cryptsoft.com)


  By downloading, installing, and using any portion of the software contained
  within this mIRC SSL DLL pack, you agree to the following terms and conditions
  except in states where any specific term or condition does not apply.  If you
  do not agree with the terms and conditions of this license agreement, then do
  not download, install, or use this mIRC SSL DLL pack.  In order to install and
  use this mIRC SSL DLL pack, you must also agree to the OpenSSL License
  Agreement ("OLA").  If you do not agree with the terms and conditions of the
  OLA, then you also do not agree with the terms and conditions of this license
  agreement.

  LICENSE

  - You agree that the default OpenSSL compile-time options meet your local
    and state cryptography laws, rules, and regulations.

  - You agree that the default OpenSSL compile-time options meet your local
    and state cryptography patent laws, rules, and regulations.

  NO WARRANTY

  This mIRC SSL DLL pack is provided "as is" without warranty of any kind,
  either expressed or implied, including, but not limited to, the imlied
  warranties of merchantability and fitness for a particular purpose.

  In no event are any of its authors to be held liable for damages as the result
  of downloading, modifying, installing, using, copying, or distributing this
  mIRC SSL DLL pack.



 ==============
  INTRODUCTION
 ==============

  First of all: sorry about all that, but apparently there are a lot of rules
  and legislations involved with this kind of thing, so I am required by law
  to include all the legal stuff.

  Let me also be quick to add that I did not create any part of the software
  included in this package; I am merely (re)destributing it in a manner that
  I think is more convenient if you only intend to use the software in
  combination with mIRC.

  To see who DID create the software, scroll up.  The DLLs included in this pack
  were extracted from a Win32 OpenSSL Installation, provided by the Win32 OpenSSL
  Installation Group (http://www.slproweb.com/products/Win32OpenSSL.html).

  mIRC (as of version 6.14) supports secure connections over SSL capable IRC
  servers, but it requires the libeay32.dll and ssleay32.dll OpenSSL DLLs, which
  according to Khaled, cannot be bundled with mIRC.  And that is all this pack
  is: a zip archive containing those two files.

  In short, if you want to make use of mIRC's SSL capabilties, you will need
  the DLLs included in this pack.  (Though whether you use the ones included in
  this pack, or obtain them from another source is not important and entirely up
  to you.)



 ================
  HOW TO INSTALL
 ================

  It doesn't get much easier than this.  Just extract the two DLLs, libeay32.dll
  and ssleay32.dll, to your main mIRC directory (C:\mIRC\ for example).  Or, if
  you want to make the DLLs available system-wide (for example, if you have
  multiple copies of mIRC and you do not want to place the files in each seperate
  installation directory), extract the DLLs to your 'system' directory (usually
  C:\WINDOWS\system32\ under Windows XP).

  In either case you will need to restart mIRC for the changes to take effect.


  *** UPGRADING ***

   To upgrade these DLLs, you will have to close all applications that have them
   loaded in memory (e.g. mIRC).  If you have them installed in your mIRC
   directory, you will only need to close that copy of mIRC.  If you have placed
   the DLLs in your 'system' directory, you may need to close other applications
   as well.  This is necessary because you will not be able to overwrite the old
   DLLs with the new ones otherwise.

   Finally, just extract the DLLs to where you had them, replacing the old ones,
   and you're ready to launch mIRC again.



 ============
  HOW TO USE
 ============

  You can see if SSL is available by typing

     //echo -a $sslready

  from within mIRC.  '$true' indicates SSL is readily available.

  Any other kind of support is not offered in this file.  Please refer to the
  mIRC help file for instructions on where to go from here.  You may also find
  the following link helpful: http://www.mirc.co.uk/ssl.html



 ============
  MORE LEGAL
 ============

  What follows are the 'OpenSSL License' and the 'Original SSLeay License' as I
  am required to include.  Please study them carefully.



  LICENSE ISSUES
  ==============

  The OpenSSL toolkit stays under a dual license, i.e. both the conditions of
  the OpenSSL License and the original SSLeay license apply to the toolkit.
  See below for the actual license texts. Actually both licenses are BSD-style
  Open Source licenses. In case of any license issues related to OpenSSL
  please contact openssl-core@openssl.org.

  OpenSSL License
  ---------------

/* ====================================================================
 * Copyright (c) 1998-2005 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */

 Original SSLeay License
 -----------------------

/* Copyright (C) 1995-1998 Eric Young (eay@cryptsoft.com)
 * All rights reserved.
 *
 * This package is an SSL implementation written
 * by Eric Young (eay@cryptsoft.com).
 * The implementation was written so as to conform with Netscapes SSL.
 * 
 * This library is free for commercial and non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution, be it the RC4, RSA,
 * lhash, DES, etc., code; not just the SSL code.  The SSL documentation
 * included with this distribution is covered by the same copyright terms
 * except that the holder is Tim Hudson (tjh@cryptsoft.com).
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Eric Young should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes cryptographic software written by
 *     Eric Young (eay@cryptsoft.com)"
 *    The word 'cryptographic' can be left out if the rouines from the library
 *    being used are not cryptographic related :-).
 * 4. If you include any Windows specific code (or a derivative thereof) from 
 *    the apps directory (application code) you must include an acknowledgement:
 *    "This product includes software written by Tim Hudson (tjh@cryptsoft.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */
