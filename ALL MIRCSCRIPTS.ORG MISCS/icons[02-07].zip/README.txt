                     ##########################
                    # HIGH COLOUR MIRC ICONS #
                   ##########################
 ________________________________________________________________________________________

 Since the icons on mirc6.0 are slightly diffrent to the ones on versions previous,
 I thought afew people would like to use the new ones but in high colour like the 
 previous set, so here you are, enjoy ;)

 - ^Liam
 ________________________________________________________________________________________

 Icl Chart:
 ___________________________________________________________________________________
 |      |        Icon:        |                                                    |
 |______|_____________________|____________________________________________________|
 | [01] |  Status Window Icon |   00   12   24   36   48   60   72   84   96   108 |
 | [02] |   /List Window Icon |   01   13   25   37   49   61   73   85   97   109 |
 | [03] | Channel Window Icon |   02   14   26   38   50   62   74   86   98   110 |
 | [04] |   Query Window Icon |   03   15   27   39   51   63   75   87   99   111 |
 | [05] |   Fserv Window Icon |   04   16   28   40   52   64   76   88   100  112 |
 | [06] |     URL Window Icon |   05   17   29   41   53   65   77   89   101  113 |
 | [07] |    Link Window Icon |   06   18   30   42   54   66   78   90   102  114 |
 | [08] |       Not Sure Icon |   07   19   31   43   55   67   79   91   103  115 |
 | [09] |        @Window Icon |   08   20   32   44   56   68   80   92   104  116 |
 | [10] |    Send Window Icon |   09   21   33   45   57   69   81   93   105  117 |
 | [11] |     Get Window Icon |   10   22   34   46   58   70   82   94   106  118 |
 | [12] |    Chat Window Icon |   11   23   35   47   59   71   83   95   107  119 |
 |______|_____________________|____________________________________________________|

 Each numbers in a row represents diffrent colour icons matching the icon name in the .icl.

 All icons are in two formats:

 16x16 16,8M colours (24bit) 
 32x32 16,8M colours (24bit)

 Created using microangelo v5.02.

 Email: Liam > no_idea5@yahoo.co.uk  
 
 Comments and surrgestions (flames?) are welcome, requests will be considered (if not actually done ;).

       