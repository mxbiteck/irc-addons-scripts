
[ mIRC Scripting Library 2.0 by CoolMaster and PTlink Scripters Team, Kakaroto help and a lot of aliases by Spyon ]

Please read all documentation on help dir, it's very important.

JUST COPY THIS DIR TO YOUR MIRC/SCRIPT MAIN DIRECTORY.
When you finished copy you need to do /load -rs scriptinglib\loadme.mrc

I hope you send me feedback on coolmaster@gameover.co.pt or http://coolmaster.org on forum.


If you have some misc aliases please send me to put in my library..

CoolMaster