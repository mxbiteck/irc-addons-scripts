Yuk! Icon Collection
-----------------------

Author: zonIRC
Email: zonirc@email.com

Dimension: 32 x 32
Format: .ico
Total Icons: 24

Tools Used To Make This Icons
------------------------------

Adobe Illustrator 10

Adobe Photoshop 7

IconEdit Pro v7.03

Introduction
-------------

This collection contain 24 icons which being designed for using as a
toolbar icons where all the standard mIRC toolbar icons have been
created except for finger and finger2. All the icon have been created
in 32x32 dimension and therefore it is better if you used it as a large icon.
You still can used it as a small icon but the icons will look blurred than the
original.

All icons had been creating by using Adobe Illustrator 10, then its
being imported into Adobe Photoshop 7 for saving as a bitmap file
(this is because my current Icon Editor had supported bitmap files
only) and for several icons, Photoshop effect have been applied.
Then the bitmap image will be opened in IconEdit Pro v7.03
for the final touch and save as an icon files.

zonIRC
16 April 2007, 02:48:43PM
