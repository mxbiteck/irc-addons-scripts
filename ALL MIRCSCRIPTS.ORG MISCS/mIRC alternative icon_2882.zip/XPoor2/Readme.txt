XPoor2 Icon Collection
-----------------------

Author: zonIRC
Email: zonirc@email.com

Dimension: 16 x 16
Format: .ico
Total Icons: 14

Tools Used To Make This Icons
------------------------------

IconEdit Pro v7.03 - for drawing and creating the icons.
(except for picture.ico where Ive had used Adobe Photoshop
for creating the picture inside the windows)

Introduction
-------------

This collection have been created as a substitute or an alternative
of the mIRC mdi windows or the treeview windows list icons. 

Unlike the previous collection, this time Ive decided to use 16x16 dimension.

I still used blue as a based colour for this collection where this time its get
more dark than before.

Lastly, thank you for downloading and using this collection.

zonIRC
04 April 2007, 07:50:51PM