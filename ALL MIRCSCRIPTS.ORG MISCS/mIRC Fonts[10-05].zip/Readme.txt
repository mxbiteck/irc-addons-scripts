#				#
# /MIRC FONTS FOR WINDOWS/	#
#				#

Author: Mpdreamz 
Contact Info: http://www.mirc.net/user/Mpdreamz
Email: Mpdreamz@gmail.com

# /INSTALL/			#

Unzip this .zip file (if you hadnt already) to a folder, which one doesnt 
matter as long as you remember where you unzipped them to. Browse to 
C:\Windows\Fonts where C:\Windows\ is your windows instalation folder.
In the menubar click on file > instal fonts. Then browse to directory 
where you unzipped the contents of this .zip file and select all 3 fonts.
Hit install and your fonts will be installed. Please note that some programs
might require a restart before usage. If your on windows 98 or earlier you
might have to restart windows (although im not sure, and i cant test for 
myself).

# /PLEASE NOTE/			#

THE TRADEMARK OF THESE FONTS DONT BELONG TO ME THEIR DEFAULT WINDOWS
FONTS AND CANNOT BE REDISTRIBUTED FOR PROFIT, I ONLY ALTERED SOME CHARACTERS.

Enjoy :)


