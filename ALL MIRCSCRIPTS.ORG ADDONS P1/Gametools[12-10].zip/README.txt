;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; G A M E T O O L S
;; scripted by impulZ
;;
;; visit #ircscript for more informations!
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

1. Installation
Just use the /load -rs path\to\gtools\gtools.mrc
to load the snippet. Path\to is the path to the treeview :)

2. Remove
Just type /unload -rs path\to\gtools\gtools.mrc
as explained above!