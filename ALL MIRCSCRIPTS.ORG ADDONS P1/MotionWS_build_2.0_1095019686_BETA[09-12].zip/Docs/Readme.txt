                           ----> Motionws2 <---

For more extensive info on how to use MotionWS2, check out help.html

NOTE! This is a bugfix/compatability release


-- 1. INSTALLATION --:
 * Unzip to a directory within your main mIRC directory
 * Type /load -rs your_directory\motionws2.mrc
 * Type /mws.config to configure your MotionWS2 webserver
 * Type /mws.start to start MotionWS2



-- 2. Commands: --
 Check out commands.txt for a command reference.



-- 3. Maintenance --:
 Every now and then, you should restart MWS2 to ensure that hashtables doesn't
 grow too large. Even though MWS2 is designed to be "self-cleaning", errors
 causing MWS2 to halt execution might leave unwanted data in the hashtables. These
 will be automatically cleared when you restart MWS2.

 Also, temporary ghost files might get stuck in the temp directory if the above
 event occurs. In this case as well, a simple restart will fix it.

 To restart MWS2, use /mws.restart



-- 4. GENERAL INFORMATION --:
 MotionWS2 (hereby referred to as "MWS2") is an example of what mIRC v6.1 and
 later is capable of. By utilizing the newest scripting enhancements (/fopen, 
 unlimited binvars), MWS2 is indeed a blazing fast and stable mIRC webserver.

 MWS2 have most of the features seen in MWS1, this includes: creation and mapping
 of virtual folders, htaccess files, password protected folders, customizable
 directory listing using CSS, customizable error pages, limiting of CPS, IP/host
 banning, and of course, MHTML. MSS is not available in MWS2, as MHTML makes it
 pretty redundant now.

 Compared to MWS1, MWS2 is very different, but still shares some common traits.
 MWS1's most important feature was the wide support of the HTTP 1.1 protocol,
 which is not as supported in the current version of MWS2. More things to come
 though. Currently supported methods are GET, HEAD, POST.



-- 5. USING THE AUTOMATIC UPDATE FATURE - IMPORTANT!! --
 MWS2 has a built-in automatic update feature that lets you update your copy of
 MWS2 at any given time. Automatic updates are ALWAYS stable releases, never
 release candidates or betas. To get the latest release, you must download the full
 install package from MWS2's homepage.

 When MWS2 installs the update package, it will not touch any of your settings.
 Neither will any of your virtual folders be changed or deleted. In addition, the
 original htdocs directory as distributed with the installation package will as
 well be left untouched.

 However, if you have customized your error pages, icons, or stylesheets, you must
 take a backup of these before installing the update.



-- 6. DISCLAIMER --:
 MWS2 is a script, and is not a part of the mIRC program package. The creator of
 mIRC can not be held responsible for any damage caused by this script. Neither
 can the author of this script be held responsible for any damage caused by it,
 either directly or indirectly. USE AT YOUR OWN RISK! The fact that you are using
 MWS2 implies that you have read this disclaimer, thereby freeing the author of
 MWS2 for ANY responsibility related to your usage of this software.

 The author of MWS2 does not condone to distribution of copyrighted material, only
 use MWS2 for distribution of your OWN or FREE material.

-- 7. Legal --:
  MWS2 can not be redistributed in any form unless:
    * The filename is intact (MotionWS_build_<mainver>.<minver>_<build>_<beta>.zip)
    * A reference to MWS2's homepage is included (http://mws.ileet.net)
    * The original author is referred to as Andreas Ravnestad aka oracel
  
  If you are planning to upload MWS2 to a website with a foreign language, contact
  the original author first. Do not upload MWS2 to a foreign (non-english) website
  without permission from the author.

  If you want to create your own variant of MWS2, you need only to include credits to
  the original author, and a reference to MWS2's homepage (http://mws.ileet.net) in
  your distribution.


Kind regards,
	-oracel