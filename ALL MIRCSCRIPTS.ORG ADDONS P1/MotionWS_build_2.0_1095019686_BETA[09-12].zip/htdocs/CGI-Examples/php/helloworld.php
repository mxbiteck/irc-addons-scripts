<?
Print "Hello world!";
?>
