Welcome to iTunes player v4.0 by BrAndo

Installation:

  1. Make sure you extracted the folder 'itunes' to your mIRC directory.
  2. In mIRC, type 
      //load -rs itunes\itunes.mrc
  3. If you get a prompt to allow initilization commands, click yes.

Using the player:
  
  - Opened by typing '/itunes' or right clicking and selecting under iTunes>, iTunes player.
  - So this player is used to control iTunes through mIRC, i know not the most useful thing in the world, but its useful to me.
    I made this to be placed on top of all windows and the info list hidden. Then you could see what song is playing in the titlebar,
    and control the playback. 
  - If iTunes is not open, iTunes will be run when you open the script. I recommend playing music through shuffel mode, so you have
    an endless playlist.
  - If your mIRC crashes, you probably already have DCX commands loaded somewhere else, so just delete the ones included in this
    script. They can be found near the last line, search for ";DCX commands".
  - All of the buttons on the player have tooltips (hover your mouse over the button) to help explain their function.

Settings dialog:

  - Opened by typing '/i.set' or through the menu, or the settings button on the itunes player.
  - The settings dialog allows you to customize almost every feature of the itunes player, which makes this player so unique.
    Customizable features include: Track buttons, icons, progress bar styles, background, font, titlebar text, and much more.
  - The OK button closes and saves changes you made to the settings. The iTunes player will also restart it self.
  - The cancel button just cancels any changes you've made.
  - You will notice the '?' button on the titlebar next to the 'X' close button. You can click this, then click anything on
    the help dialog to get an explanation of what it does. This should help with any confusion of anything in the settings dialog.

Info:
  
  - This is the second version, which is a complete remake of my last version, so there will be bugs. PLEASE report bugs to me at
    BrandoAwAy@gmail.com and i will fix them right away.
  - Some credit must go to the DCX devolopers, what an amazing dll.
  - So any questions, suggestions, criticism, comments are greatly appreciated. I can be reached at BrAndoAwAy@gmail.com 