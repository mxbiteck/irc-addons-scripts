InfoBloot Readme

i./Installing
ii./Background Information
iii./Known Issues (Bugs)
iiii./Changelog
iiiii./Todo
iiiiii./Help
iiiiiii./Bugs
iiiiiiii./Scripting help
iiiiiiiii./Mailing list
iiiiiiiiii./Disclaimer
iiiiiiiiiii./Thanks
iiiiiiiiiiii./Copyright


Installing (exactly the same as in the tutorial):

To Install and get going quickly:
1. Unzip infobloot.mrc into your mIRC directory.
2. Type /load -rs infobloot.mrc 
3. Click InfoBloot on the menu bar and then click Options.
4. Fill out in the options you want (see dialog options after the command reference).
5. Press Ok.
6. Click InfoBloot on the menubar and then click on Connection and then Options then Name.
   You could also just press alt + e and go onto the mIRC connection options manually.
7. Fill out the mIRC name details and then the server details on the Servers dialog
8. Click Infobloot on the menubar then click on Connection and then Connect. You could
   also just type in /server or click the mIRC connect button.
9. Type /join #your-channel if you have not put an auto-join into the mIRC perform.

*InfoBloot connects using mIRC and SHOULD be run in a new copy of mIRC.
The connection options in the menubar are just shortcuts to the mIRC
connection options. To connect to a server, once you have filled out the
necessary details, you may just type in /server or press the mIRC connect
button. InfoBloot will work automatically in any channels it is in, so all 
you have to do once connected is /join InfoBloot into your channel(s).*


Background Information:

InfoBloot was coded freelance by me, IceShaman. When the project was first launched, it was 
designed to allow easy creation of factoids with optional lock and unlock nothing more nothing 
less...How I laugh at how rubbish it first was. As with all things good it was very hard to get the 
basic hardcoded things in then came the easier part of customisation and addons with the 
exception of dialogs. Finally came the nice lovely protection and extra frilly rubbish for the very
n00biest of n00bs to love and admire. Then I woke up...


Known Issues:

-Factoids like_this_are treated as multi-worded factoids. This is because multi-worded factoids
 are stored in the database like_this so there are no spaces. This means that when a factoid is
 called it turns every _ into a space so if ever if you set your factoid like_this it will still
 be treated as a multi-worded factoid when it is called for and will still /not/ be allowed to
 be called if multi-worded factoids are disabled.


ChangeLog:

Version 1.04 (re-release):

-made documentation install instructions easier to grasp
-changed the menubar popup and added it to the channel
-changed documentation to show how to call factoids
-renamed documentation files

Version 1.04 (<RC2>+):

-added support for Infobloot: as well as InfoBloot, for those with crappy nick completers 
-recoded nickometer to be far more advanced and stingy
-recoded encryption routines to use while loops instead of goto (massively decreases time)
-fixed bug where custom factoid prefixs were given even if disabled, if no custom prefix is 
 given Factoid: will be used.
-changed old tell protection so nicknames can be blocked (config file tellblock= )
-made infobloot give a prefix to tell commands using <reply> to stop exploits
-fixed addon unloading bug
-changed factoid creation so that null factoids can't be created if the factoid is locked
 and the person is not author, also admins are warned about blocked factoids and must 
 unblock them before changing them
-removed the useles debugging string ".............." on a certain error message 
-did the same as below for master checker
-made the admin checker accept wildacrded hosts instead of exact hosts
-fixed bug where admins could not forget other peoples factoids even though they had overrule
-fixed problems with addin addons via the new 'code' secure system
-removed where can I find <factoid>, it was outdated and not worth updating
-made Infobloot, factoid++ and -- work for karma updating, and made it so it doesn't say
 "terter" for no apparant reason.
-added protection from using tell to say things to services i.e. chanserv, nicksev, memoserv
 operserv or hostserv. As defined in the config file, settings, services.
-hardcoded a calc length limit of 15 to prevent possible abuse
-fixed a few dialog bugs
-added protection against: Infobloot, hacking is <reply>!op $nick - and suchlike
-fixed a factoid retrieval bug in failsafe
-fixed small help bug
-added failsafe against people requesting an alias of a random | factoid
-added all the new features like | and <alias> to ifbtell

Version 1.04 <RC1>:

-added new variabled for things like multi-worded factoids to backup/autobackup/restore 
-added default settings, basically when you first load up InfoBloot if it cannot detect any
 previous settings it will setup InfoBloot with recommended settings. This is to stop potential
 hack attempts due to hacklog being disabled and so newbies can enjoy InfoBloot straight away
 without wasting 10 minutes setting it up.
-tweaked hack attempt checking to check indentifiers located adjacent to |
-made addon descriptions work - stopped working due to human error in me using ifb and not .ifb 
-added protection against the same addon being in the loaded file multiple times
-added support for multiple replies using | in botask
-made requested stats support multi-worded factoids
-added support for multi-worded aliases
-completed dunno improvements to make InfoBloot message any bots wanting to know the definition
 of a factoid as soon as it becomes available.
-made botask support 1 alias redirection ie if the botask returns an alias it'll ask for the
 definition of the alias and give that as the definition of the original factoid
-fixed flood protection so it works better and so $ifbflood can be used to check if the message
 has triggered flood protection or not, $true is returned if it has, $false if it hasn't.
-made hack attempt checking work with botask and with instances where <reply>$nick or <action>$nick
 and suchlike could be used.
-made botask have the ability to store factoids that don't exist but are known by other bots, so
 the bot does not keep having to ask for the same factoids.

Version 1.04 <beta>:

-finished recoding the factoid creating/editing code so developer "tools" can be created
-made infobloot accept infobot like factoid creation e.g. InfoBloot, test is <reply>testing
 notice there is no space in between <reply> and the factoid, this also applies to <action>
 and <alias>
-recoded some of the factoid creating/editing code
-added md5 encrypt command - obviously there is no decrypt
-fixed a lot of the factoid creation/editing code for optomization
-added new <alias> setting whereby InfoBloot reads the specified factoid ie
 InfoBloot, cool is <alias> IceShaman would set it and when someone asked
 what cool was it would read IceShaman.
-changed some instances of blocked to null - should have been done earlier
-made the hackattempt system allow $who if $nick is enabled and vice versa
-recoded the infobloot protocl (bot linking) section to make it 40% faster and also
 provide protection from linked bots that may tell InfoBloot to say an identifier.
 If anything forbidden is detected in the command (check with $ifbhackattempt) then it
 says the reply has been forbidden.
-made infobloot hide what it messages to users.
-added hackattempt checking to "where can I find <factoid>?"
-made the hackattempt checking return a value so $ifbhackattempt can be used in addons
 please see the addon section of the tutorial.
-fixed the hack attempt checker so it works with multi-worded factoid setting/reading (minor)
 *update* upon lots of proof-of-concept this 'minor' bug can give an attaker total control of
 mIRC, but what they do is public so the whole channel can see it.
-changed karma so it is checked after addons - otherwise k++/k-- can overrule addons
-fixed bug where hi was not answered and an error was given
-added Infobloot, version command
-fixed a few bracket mistakes
-made forbid exception also support wildcards
-changed forbid syntax and removed unforbid
-added a forbid exception support
-made forbid list accept wildcards
-made InfoBloot be able to see its own replies
-renamed most of the aliases to avoid any conflicts
-made error dialog checking to stop errors casued with the error dialog :p
-cleaned up various code
-changed from 'halt' to 'return'
-fixed rejoin bug where the wrong error message was given
-fixed unforbid bug caused by file mismatch
-improved nickometer
-added multi-worded factoid support for other commands such as karmaset
-fixed various karma bugs
-fixed a small bug in Karma locking
-added FULL support for large factoid files
-cleaned up various code
-fixed a minor bug in locking/unlocking multi-worded factoids
-added advanced support like lock <action> e.t.c for multi-worded factoids
-added connection menus
-added basic support for multi-worded factoids via <botname>, IceShaman of CentralChat is cool
-made block admin only and made <reply> $null use null instead
-cleaned up various code from pervious versions that isn't needed like exists
-added default forget reply for if custom replies are disabled
-added /msg botname help even though I swear it /was/ there but apparantly wasn't...
-fixed bug where mIRC would crash after a certain number of factoids
-cleaned up miscellaneous code
-fixed backup factoids major bug reported by Dreadnought
-added calculator support for 'pi'

Version 1.03:

-added describe command
-fixed small hacklog entries bug.
-changed quit access denied message so it actually says quit and not 'quick'
-added announce command for channel and private messages (requires access to channel
 commands).
-made encrypt/decrypt 'leet' code not change 'n' (was causing problems) 
-added join/part commands to private messages so if InfoBloot is on no channels you
 can make it join. 
-changed addon list command so it gives more information like what addons are loaded and available.
-changed calling code to addons so , will work i.e. InfoBloot, dict test would only work before
 but now: InfoBloot, dict, test - will work... 
-added support for masters with forbid privaledges being able to say forbidden words (i.e so
 they can unforbid heh)
-added checking for addons so it never shows the same addon as being loaded twice
 in the loaded addons box.
-changed main code to detect commands (on event) to speed things up slightly
-tweaked documentation a bit
-fixed small bug in help where people could make InfoBloot reply with custom text (minor bug only)
-changed the way addons work (necessary) [note this may cause an incompatibilty with older addons]
-added some more options for budding addon makers - see tutorial

Version 1.02:

-made code more coherent for the status command
-fixed minor addon bug where an error would be given when dialog opens
-**MAJOR BUG FIX* fixed an incredibly deadly bug in hacklog, well actually several. Basically I
 made it check the first letter of a word for $ and % except you could use a bold character 
 first, and it would evaluate. Also you could use $+ and it would evaluate due to a bug in 
 setting variables. Thanks to heinz for 'hacking' InfoBloot =) and hopefully everything should 
 be A Ok
-fixed bug where the bot would reply to hi even if custom replys were disabled
-fixed a few typos, thanks to Wedge the hawk-eyed beta tester :P
-added updatecheck command which returns if a new version is available or not remotely.
-added error messages if trying to retrieve news too quickly
-fixed help function so Infobloot, help <topic> works
-changed help script to not need a .txt file for giving status
-fixed karma bug where by a non-master could set karma beyond 10
-made shift decryption so it works basically
-fixed encryption/decryption scripts so they all actually work (after months of neglect)
-fixed reply bug where if you couldn't change from action to reply or vice versa
-fixed another karma bug (in lock/unlock)
-fixed bug where using Infobloot, <factiod> ++ you could edit the karma regardless of locking
-changed forbid command to work from the config file and not ifbforbid.txt
-fixed blatant security vulnerabilities in the <action> code
-took out error checker, it was more useless than useless itself
-added error checker to make sure strings don't exceed 935 characters
-added help implementation for addons
-fixed small bug where anyone can make InfoBloot speak without setting a factoid



Some time in 2003 (0.04-0.09):
-after god knows how long I think InfoBloot is stable and well coded enough for a none-private release!
-built in remote backing up/restoring backups (restricted to the master admin)
-improved backup/restore code to be compatible with remote ussage
-being the kind guy I am I added an emergency ctcp command to clear the ignore list even if *@* is ignored
-debugged a few commands that didn't quite work.
-changed dns to work with the new VeriSign 'resolve to all' page...
-added support for remotely enabing/disabling user commands
-added more options to factnum like synchronise and set
-added masters admin option (so you can enable/disable user commands)
-added masters option to use addon commands
-added remote installing/uninstalling/listing of addons 
-added dialog function to edit the help script
-added full addon implementation apart from help...
-fixed masters dialog part
-messed up rewriting uninstall script and ended up having to rewrite 4 hours work, wahey!
-tweaked dialog code so it actually showed in Windows XP
-finally made addons script work kind of, but its very strict hehehe...
-made more dialog things work like update checker and news
-tested the backup system, realised it never ever worked and recoded it!
-made the backup system coherent with all the new features
-deleted a load of things, for the first time ever coded in a school term I hit 2000 lines yey
-Fixed a few bugs in masters dialog:
 -Errors spilt out for no apparant reason when deleting a master **fixed**
 -When a master was deleted the first master on the list was NOT shown **fixed**
 -When a master was first added they did NOT appear on the list *fixed**
 -After a master was deleted all other masters when selected showed the same ticked boxes as the deleted one **fixed**
-Fixed bug where any user could render a factoid completely useless 
-Screwed up the entire script, thank god I did my 2-monthly backup the day before
-Deleted exists part of factoid storage, can just use != and name instead 
-**BUG FIX** fixed bug against bot lowering internal factoid list by one if a certain string is passed
-Did a lot of work for new functions for release due in a years time, *sigh SATS*
-Fixed dumb ass bug with commands not working due to alias -l being the same as mIRC commands
-With new layout in place added support for access commands from privmsg
-Ripped all code apart and redid layout from using goto to aliases *thew*
-Added dns feature
-Allowed support for $who (I will make custom identifiers if bugged enough)
-Improved Bug Fix to log attempts to use $ and % and added an admin command to read the log, and clear it
-**MAJOR BUG FIX** Added protection against people setting factoids that read from variables and identifiers
-Cleaned up code a bit and began work on dialogs, then gave up
-Added **FULL** support for the infobot protocol, fully described in the tutorial (full != full heh)
-Fixed a few bugs
-Added basic support for the InfoBot protocol so it can ask other bots
-Jesus omg all this time using $left to count the chars and then I discover $len (script 183 lines smaller now) hehehe
-Added yet more commands

Some time in 2002 (pre 0.04 and early 0.0 beta a-f) :
-Added total factoid support, basically so it works. 
-Added more commands, see command reference for a huge list. (update - I really did make one)
-Added logging of time author and date for a factoid....so it can be TrAcEd!!!
-Improved how data is stored in the ini so more, useless, information can be added.
-Improved code layout to work better, ish...
-Thought about adding masters, but decided to leave that until the bot is finished (HA!).
-Added an admin variable that can overrule locked factoids (power r0x).
-Updated karma to work with custom messages (why did I bother).
-Added karma factoid rating system (nobody will use it heh).
-Made a variable file for some random reason.
-Wrote a bit of crap for a readme, update later. (update - never happened :P)
-changed ini file workings from all the titles in one section to a section for each factoid.
-Added support for lock/unlock.
-Scrapped the idea of variables and decided to use ini files instead.
-Started making a rough bot to accept factoids using variables.

Todo:

-allow users to change multi-worded factoid limit (currently hardcoded at 5)
-allow users to change flood protection check time (currently hardcoded at 5)
-add more commands to stats such as factoids for each user and user with most factoids e.t.c
-allow InfoBloot to quickly tell if a person is online (for messaging e.t.c) - supposed impossible

Help: 

If you require any help with InfoBloot or wish to provide constructive criticism or
praise please feel free to email either ice@icenetwork.co.uk or visit the website:
http://infobloot.icenetwork.co.uk which provides support and details. 

Bugs:

- Unknown Factoid/Command error given when requesting a factoid (see faq)

If you find any bugs please repot them via e-mail to: infobloot.bugs@icenetwork.co.uk


Scripting Help:

There are loads of scripting help and tutorials about, read them before scripting. I am not going to
tell you how to script your own scripts. Do what you want I don't care, really I don't. When I read 
one I had the sudden urge to launch a brick at tabo. Mind you he was right, oh well I don't care.
If you don't like something in InfoBloot or think it breaches basic scripting rules, email me. And
if it somehow is the 1/25 that doesn't redirect to /dev/null I might change my ways, pfft.


Mailing List:

If there is ever one, which I doubt. It will be found at http://infobloot.icenetwork.co.uk 

Disclaimer:

By Running this script in any shape or form you choose by right to agree to the terms and
conditions of this disclaimer. Please read carefully.

1. IceShaman takes no responibility what so ever for your actions. If something goes
   wrong and any damage is caused then you are responsible. There is no purposely put
   dangerous code in the script.

2. You may use this script however you want for any legal purposes as long as you keep
   IceShaman and any other contributors to the code in the code somewhere. This does 
   not have to be visible fom outside the code.

3. Modifying the code and then stating that it is the original is totally forbidden. If you 
   decide to change it then any warranty is automatically voided.

4. If you decide to distribute the code unchanged please keep the full documentation
   with the code and if you wish add a note saying where you got the script from.

5. If you decide to change the code/make addons feel free to contact me and if they are
   any good I will release your code giving you full credit.


Thanks:

At the moment IceShaman is the sole contributor towards 99% of the code but there are 
still a lot of people that need thanking. If you feel you should be added to the list please
e-mail me with an explanation of why. And If I have unknowingly used some of your code
please e-mail me as well...

mircscripts.org  -  Providing a free service and community dedicated to mIRC and scripting,
                    I find it a great help that so many talented scripters allow you to use
                    their scripts and tutorials.

InfoBot Team   - Making (as far as I am aware of) the very first DECENT factoids bot.

BlootBot team  - Making useless addons for InfoBot.

Other People   - See the dialog 


Copyright:

InfoBloot and any sub-programs or code in any way related to InfoBloot for mIRC or the
scripting language are copyright 2004 IceShaman unless otherwise stated. You may use the 
script however you want within the legal bounderies of your country or any other countries it may 
affect, redistributing changed code as original is strictly prohibited. Also redistributing 
without the full original documentation or using code that may cause harm in any way what so 
ever to a user is also strictly prohibited. All rights reserved.