Half-Life Server Browser
by bunkahumpa

-------------------------------
Contact Information
-------------------------------

E-Mail: bh@scriptsurge.org
IRC: irc.GameSurge.net #script

-------------------------------
What is it?
-------------------------------

HLSB is a server browser for all Half-Life servers and their mods (such as Counter-Strike, Day of Defeat, etc.) You add the server addresses (IP or DNS) and you can view the server information and connect to it. It is NOT compatible with the new Counter-Strike Condition Zero because that is another game and does not use Steam.exe.

-------------------------------
How to install:
-------------------------------

Unzip ALL of the files into your mIRC directory and type:

/load -rs hlsb.mrc

Click on YES when it asks you if it is ok that the script runs initialization commands.

-------------------------------

Upon installation the options dialog will popup, specify the path to steam.exe and stuff.

You can now run HLSB to its full potential, right-click in a status window/channel window/query window and select HLSB.

-------------------------------

When HLSB is started it queries a server in the config file if one is there, if not it does nothing. When you type an IP address (or DNS) in the editable drop-down box it will do nothing. 

- If you want to add the server to the saved servers list (it will appear in the drop-down forever until you delete the server) hit the UPDATE button on the side of the box. If you want to delete a server click the GAME OPTIONS button and click the OPEN FILE button. This will launch the HLSB config file. Just edit the servers as you wish and save it. When you close and re-open HLSB the changes should occur.

- If you want to just view the server and not add it to the saved servers list hit the REFRESH button near the bottom.

NOTE: Pings may not be accurate due to how much your computer is working and stuff, that's why it's the approximate ping. If you think it's unusually high, try refreshing once or twice more and see if it changes.

-------------------------------

Clicking on the PLAYERS INFO button will show the players in the specified server with their score and time since they connected to the server. Clicking it again will close the players info. You can also click on the PLAYERS INFO << button at the bottom to close it. Hit the REFRESH button to refresh it.

-------------------------------

To connect to a server hit the big CONNECT! button. If you have specified your path to steam it will attempt to launch steam and connect to the server. If not it will give you an error message. If the server is full it will automatically attempt to auto-retry every 5 seconds. It will refresh the server and display the number of players as well as the ping.

-------------------------------

Finally, if you click the GAME OPTIONS button it will launch the same options dialog that was launched when you loaded HLSB.

-------------------------------
Credits
-------------------------------

MDX.dll by DragonZap
ipresolve2.dll (aka raddip.dll) by Jesper N�hr (spike)
Sleep alias by Online
Unfloat alias by noob

Parasite-FT- for getting me into game server querying and helping me pick out the little bugs in some of my queries :) <3

stx-`Slipknot- and xN|cappiez`e for beta testing