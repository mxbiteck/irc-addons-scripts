
    __            __          _
   / /____  _____/ /_  ____  (_)___ ___  _____
  / __/ _ \/ ___/ __ \/ __ \/ / __ `/ / / / _ \
 / /_/  __/ /__/ / / / / / / / /_/ / /_/ /  __/
 \__/\___/\___/_/ /_/_/ /_/_/\__, /\__,_/\___/
                               /_/

 T E C H N I Q U E

 t� 

 Readme font Lucida Console 8 pt

 ----------------------------------------------------------------------
 
 Logview v.09 mIRC addon for version 6.0+

 Author: Revan (Ryan) linxsrc@berlin.NOSPAM.com
 www.technique.tk 

 ----------------------------------------------------------------------

 INSTALL

 Extract all 5 files somewhere on your computer in the same directory.
 You must have mdx.dll ctl_gen.mdx dialog.mdx and logview.mrc in same 
 path!

 In mIRC type this

 /load -rs path/to/logview.mrc 

 path/to/ would be an actual path like C:\Script stuff\

 Accept the initialization warning!

 ----------------------------------------------------------------------
 
 USAGE

 /logview (Opens new dialog)

 ----------------------------------------------------------------------

 INFO
 

 1. In mIRC Options alt+o Options\IRC\Loggin if "lock log files" is 
  checked and you have problems with addon, uncheck it.
 2. When you start logview it will color your active logs red with a 
  second of delay, only
  if you still have the #4 color in mIRC still set default which is red.
 3. Double click on files listed in listbox to view or select one and 
  right click press view.
 4. Double click titlebar in logview to maximize the viewer, do it 
  again to restore.
 5. When you want to delete you can select more than one file listed 
  then right click press 'Selected' then 'delete'
 6. You can resize any side of the logview by putting your mouse on 
  any one of the 4 borders and  dragging.
 7. You can now select a log and rename it.
 8. Using any of the 3 search functions you can use wildcards like
  *blah *blah* blah* or if you use no * wildcards the search will be
  and exact text search.
 9. Orange color (7) logs and topics represent searched files.
 10. If missing any mdx files or not in same path as logview.mrc, 
  addon will fail to function properly.
 11. Searching all log files will slow down the more files you have
  or if you keep large files. My 1200mhtz 512mb laptop searched 300+
  10mb total log files in 1.2 seconds for me.
 12. Dispose of unwanted log files, when you delete with this addon 
  the files go to the recycle bin so they could be restored.
 13. The main list is an embedded @window so you can see control codes
  like in chat.
 14. This addon will not include popups for mirc, make your own to fit
  your mIRC/script.

 ----------------------------------------------------------------------

 UPDATES

 August 31 2003 v.09

 Added -b switch to filter so now you can get better search results
  for any search with control codes. Logivew search was ignoring them
  before.
 Removed mIRC popups, make your own with Logview:logview
 Removed tabs from dialog popups

 August 22 2003 v.08 (Revan)

 Added new mdx.dll functioned dialog
 Added resize minimize restore dialog functions
 Added @window embedded into dialog.

 Added 3 search functions
  filename searches all log files for mathing names
  single log file text searchs a single log for matching text
  all log file text searches all logs for matching text and delivers
  it sectioned by log and matches. Each search works differently. 
  Wildcards can be used in all 3.

 Added directory options, now can chose instead of default $logdir
  if one isnt chosen uses mIRC's default log dir
 Added progress bar for all log file text search, hides when not in 
  use
 Fixed delete function to warn before executing
 Improved tiny code functions all over
 Added some small additions youll have to discover
 

 July 7 2003 v.07

 Fixed 2 aline bugs
 Added file name and size to main window when opening log.
 The log scrolls to the beginning now when opening.
 * Adding search features for next version should be out soon.

 January 31 2003 v.06

 Added channel|private log sorting.
 Fixed an aline error when active logs were colored in list.
 Modified the window and popups.

 October 6 2002 v.04

 Fixed a bugin the lister

 July 7 2002 v.03

 Fixed titlebar from not showing log directory size.
 Fixed the sort in the listbox for log names.

 June 6 2002 v.02

 1. Fixed text wrapping long lines so you can see em now.


 ----------------------------------------------------------------------

 