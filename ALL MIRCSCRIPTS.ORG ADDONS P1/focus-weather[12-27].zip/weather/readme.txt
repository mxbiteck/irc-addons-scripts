 
 __      __Focus Worldwide__  .__                  
/  \    /  \ ____ _____ _/  |_|  |__   ___________ 
\   \/\/   // __ \\__  \\   __\  |  \_/ __ \_  __ \
 \        /\  ___/ / __ \|  | |   Y  \  ___/|  | \/
  \__/\  /  \___  >____  /__| |___|  /\___  >__|   
       \/       \/     \/          \/     \/ Service

Project Focus Worldwide Weather Service
by IcyLiquid (Tim Gunter) <icyliquid@gmail.com>
Version 4.1

=============================== 

This README file contains the following sections: 

1. Project purpose / description. 
2. Project directory structure
3. Project usage
4. Thanks
5. Notice of GPL / Copyleft 

=============================== 

1. Project description: 
    This script is designed to supply you and your friends with 
    up-to-the-minute weather information from within IRC channels. 
    It can provide the current weather situation in cities throughout
    the world, as well as look up targeted information when called
    with a US or Canadian zip code. FWWS can also retrieve forecast
    data for up to 7 days into the future!
                
=============================== 

2. Project directory structure: 
    All the files related to FWWS should be stored within their own 
    directory. The zipfile is encoded with a parent folder called
    'weather', so you can unzip directly to your mIRC directory.
    If you have a scripts folder, you can also unzip to there.

=============================== 

3. Project usage: 

    To load the addon, type this into mIRC: 
        /load -rs path\to\weather\focus-weather.mrc
        
    Users of your script can request the weather in one of the added
    channels by typing its trigger, followed by either <city, state>,
    <city, country>, <us zip> or <canadian area code>:
    
        !weather montreal, quebec
    	
    In addition, users can prefix the location with the word 'forecast',
    and supply an optional time ('tonight', 'tommorrow [night]', or 
    '<day name> [night]'):
    
        !weather forecast montreal, quebec tommorrow night
        !weather forecast montreal, quebec tonight
        !weather forecast montreal, quebec wednesday night
        !weather forecast montreal, quebec friday
    	
    These triggers are also available to you.
    
=============================== 

4. Thanks:
    I would like to say thankyou to several people who helped me
    through writing this script. I am sure many of you know how
    hard it can be to keep going with something with you've been
    working on it for a while.
    
    nomak          - Thanks dude for always supporting me and giving 
                     honest feedback. Suggestions too :)
                  
    Mpdreamz       - Constant DCX encouragement and challenging me
                     to go the extra mile.
                  
    ClickHeRe      - Dude, DCX is awesome. I couldnt have made this
                     script what it is without your amazing dll.
            
    peeps, stefys` - Your relentless testing was invaluable! Thanks
                     for the beta usage :)
                  
    SanatariuM     - Encouragement here and there helped me keep 
                     goin when things got tiring.
    
    #chatzone      - Lots of bugs were found because of usage in 
                     this busy channel! Thanks for being patient guys.
                  
    #mircscripting - This channel helped me rediscover why I love to
                     write scripts.
                     
    To everyone who helped me, thankyou!

=============================== 

5. Notice of GPL / Copyleft: 

    This program is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public 
    License as published by the Free Software Foundation; 
    either version 2.1 of the License, or (at your option) any 
    later version.  This program is distributed in the hope 
    that it will be useful, but WITHOUT ANY WARRANTY; without 
    even the implied warranty of MERCHANTABILITY or FITNESS FOR 
    A PARTICULAR PURPOSE. See the GNU General Public License for 
    more details.  You should have received a copy of the GNU 
    General Public License along with this program; if not, look 
    on the web at on the web at http://www.gnu.org/copyleft/gpl.html 
    or write to the Free Software Foundation, Inc., 59 Temple Place, 
    Suite 330, Boston, MA 02111-1307, USA.  

    To contact the author of FWWS, send email to Tim Gunter at
    icyliquid@gmail.com.