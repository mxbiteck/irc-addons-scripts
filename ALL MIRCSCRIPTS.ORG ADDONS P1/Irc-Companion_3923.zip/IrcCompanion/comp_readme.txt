;######################################################################
;#Irc-Companion, is designed to assist,protect and aid you whilst you #
;#are on IRC, it can do just about anything whilst providing constant #
;#and silent protection on IRC. From showing you the irc opers and ban#
;#& kick protection, to clone scanning and highlighting users who are #
;#set to away it will assist and aid in almost every decision you make#
;#on IRC. Some features you may never know about, but be assured that #
;#Irc-Companion will become integral to your mIRC experience. ; ; ; ; #
;#Many Thanks to those at mirc.com for their advice and assistance.Thx#  
;#also to the scripter at hawkee.com for the Ajoin Dialog. I hope you #
;#enjoy your IRC-experience with irc-companion, irccompanion@gmail.com# 
;######################################################################

A full highly configurable auto identify addon which is a must for any irc user. It will take care of all your auto identify needs with nickserv chanserv irc operator, it also comes with a full multi network auto join with additional very usefull features like  coloring away users in grey as in xchat, ban protection, auto paste to web, clonescanner and a blacklist to name but a few. It is very user friendly and designed to be unobtrusive. The dialog can be brought up with a simple tap of the F4 key. It has gained surprising popularity on other web sites hence i post it here in the hope users will benefit from it.
;

A simply written addon that provides a wealth of features. 

#######################################################################

Irc-Companion is used by Amateurs and veterans alike and provides a wealth of features.
From Complex Spy modules and kick and ban protection to colouring users that have been 
set to away in grey (as in xchat) to highlighting the Irc-Opers and clone-scanning. You
will also be assured constant silent protection and a detailed un-annoying events log for
those who like to idle and want to know what�s happened in their away time. There are to many
Features to list here but Irc-Companion remains a simple and well written script that does not 
play with mIRC's internal functions through use of Dll's or badly written code. It has been tested
by tens of users who report a happy and bug free experience

#########################################################################


If you have come across this i ask you to please try this beta version out.
To use: Open folder and copy all the files then Start mIRC & type /run . and paste all files in, then type //load -rs "irccompanion/irc-companion.mrc"


If you are having problems with this script i would not know why as it has been tested. Use the Send Bug feature to eport it and it will be addressed.

I thank all those special people in my life who have helped me and made my dreams come true.

G-D bless

signed, Weaver AKA Shy AKA spyder IRChackthissite.org #noobs Gedalya Shalom