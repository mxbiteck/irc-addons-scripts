8/4/05

MAGNETO FOR UNREALIRCD v1.4 by Averell (2005)


INSTALLATION
============

Unzip the zipfile in your regular mirc folder. Then type /load -rs magneto/magnetunreal.mrc

REQUESTED SOFTWARES
===================

A regular mirc
The Irc server UnreaIRCd, that you can download at http://www.unrealircd.org

PURPOSE OF THE ADDON
====================

This addon is a real-time logger: it behaves like a magneto-recorder, which allows to record a sequence, and to reproduce it immediately after recording, as many times you want. Its purpose is to "record" in real-time your irc session, including all of the channels you are on, and also reproduce the private conversations.

The reproduction of the sequence is made through UnrealIRCD: once you want to review your irc session, you connect to unrealIRCd, and the addon initiates a link. The interest is, that you can interact with the elements (the nicknames...), and you can simulate a big traffic on your server in order to test your scripts, without troubling anyone. Being an op, you can indeed kick ban who you want, test your mass kick/mass deop system, or do everything you dreamed of if you were the op of a big channel! Of course you can also test some more intelligent things... 

It is to be noticed, that the nicknames reproduced on you irc server are not clones, since their hosts (as well as their userhosts) are all differents, and are the exact replications of the original ones.

SOME ADVICES
============

This addon does not suit to a child less than 36 months old :)

You can log channels as big as you want, but only the active nicks will be logged (i.e. those who speak, who join in, who kick, and so on). You can force the addon to get all of the nicks in the channel by typing /who #channel once during the recording. Depending of the channel size and on the irc server, /who #channel could yet be not complete.

The addon automatically changes your own nickname (it chooses a random nickname) in order to avoir nick collisions with yourself in the recorded sequence. This is a little bit boring, but less boring than being disconnected each time you want to use the addon...

CONFIGURING UNREALIRCD
======================

If you are not familiar with UnrealIRCD, I suggest you to use the files inside this zipfile: unrealircd.conf, ircd.motd and ircd.motd.fr (in folder magneto/Unreal). Put them in the Unreal folder (inside Program Files): it will allow anyone to link on your port 4400 with the password "openaccess", and allow anyone to be an ircop by typing /oper admin admin. That is the reason why I do not recommend to use this .conf file if your intention is to let unknown people connect to your ircd, since these two characteristics are big safety holes!

CONFIGURING THE ADDON
=====================

By default, the linking port and password are the same as those in the unrealircd.conf file that I propose in the zipfile. The server's ip address is localhost (or 127.0.0.1). You can modify these parameters through a marvelous dialog box by selecting "Magneto for Unreal > Configure" in the command menu.

I recently added a new feature in the configuration box: if the checkbox "/who on join" is checked, a /WHO nick is performed on each new user joining one of your channels: the only purpose is to catch the long name and the ircop flag if any. This may unfortunately cause disconnections for flooding, in case of logging of mass joins, that is the reason why this box is not checked by default. Any new user will have "Magneto user" as a long name.

CONFIGURING YOUR GREAT MOTHER
=============================

lol :))

TO RECORD (LOG...) A SEQUENCE
=============================

Select "Magneto for Unreal > Record a sequence". Then the addon will ask you for a sequence file name, which will be stored in a folder named "magneto" in your mirc folder. After the file name is defined, the recording begins. You can stop the recording when you wish.

TO READ A SEQUENCE
==================
Launch UnrealIRCD correctly configured.

In your regular mirc, type /server localhost: that will connect you to the ircd. Then select "Magneto for Unreal > Read a sequence" (in command menu). Choose the file you want to be read in the file choosing box. A link is then initiated, and you'll join some channel and see them progressively be filled in by nicknames.

What is interesting is, that you can interact with them. You can of course /whois them, but if you have ops, you can kick/ban and perform any operation you want. To become an op, the best way is to become an ircop by typing /oper admin admin. You will get the op privileges from the server without being forced to get an arrobas before your nickname!

When you want to stop it, select "Magneto for Unreal > End of session" in the command menu, then all of the nicks will disappear in a big netsplit.

A WORD ON THE "RESET" MAGIC COMMAND
===================================

This was quite complex to script, so I wanted to tell you a word about that. If you kick some members of a channel, or deop/devoice some of them, or op/voice some of them, it is possible to retrieve the previous characteristics of the channel. Right click on this, then Magneto for Unreal > Reset #... . It could take a while, according to the size of the sequence file, then the kicked members will join again, and the correct modes (@, +) will be given away by the server. This could be interesting in case where your script performs a lot of changes (like a mass kick/deop, as an example)

CONTROLLING THE NICKNAMES
=========================
Maybe it would be interesting for you to control the nicknames, in order to test your script or to make a joke. There are some basic instructions to do so.

As an example, you have replicated the channel #teuf, your nickname is Averell and RoToTo is a nickname replicated in this channel. He is an op, and you are not.

On the channel entering box, type in:

/d rototo I am a stupid boy

You can be helped by the "tab" key to complete the nick name.

Result: 

<RoToTo> I am a stupid boy

Type: /mm rototo is a stupid boy
Result: * RoToTo is a stupid boy

Type: /m rototo averell +v
Result: RoToTo sets mode: +v Averell

Type /kk rototo averell you suck!
Result: *** You were kicked from #teuf by RoToTo (you suck!)

Type: /no rototo This is a notice
Result: -RoToTo:#teuf- This is a notice

Type: /m rototo averell +o
Result: RoToTo sets mode: +o Averell

This is a convenient way to get ops in a replicated channel without trying to become an ircop, provided there is at least one op.

Type: /pp rototo
Result: *** RoToto has part #teuf

Type: /jj rototo
Result: *** RoToTo has joined #teuf


HISTORY
=======

I created this marvelous addon in year 2002; maybe it is new for you, but for me and my friends, it's still an old story... At this moment it was written in french, suffered from some bugs and limitations, and it only worked on an ircd that I wrote under mirc, called mirc script server (MSS). This became so much popular, that I decided to include it natively in the zipfile of MSS. Now I have decided to give it (freely!) away and over the world, that is the reason why I translated this addon in english.

Please feel free to contact me in case of troubleshooting.

Hope you'll enjoy this addon,

Averell ( Averell@mircscriptsfrfm.com )
