Download previously UnrealIRCd on http://www.unrealircd.org

If you are not familiar with UnrealIRCD, I suggest you to use the files inside this zipfile: unrealircd.conf, ircd.motd and ircd.motd.fr (in folder magneto/Unreal). Put them in the Unreal folder (inside Program Files): it will allow anyone to link on your port 4400 with the password "openaccess", and allow anyone to be an ircop by typing /oper admin admin. That is the reason why I do not recommend to use this .conf file if your intention is to let unknown people connect to your ircd, since these two characteristics are big safety holes!

That's all folks!