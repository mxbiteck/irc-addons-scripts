______________________________
Common Servers v1.2 by Andy
______________________________

Basic Description: 
This addon allows you to manage a custom list of your common servers and channels to connect and auto join on starting mIRC. The addon works with mIRC v6.15 or newer.

Updates:
28/05/07 - v1.2

* Cleaned up loads of code.
* Servers now have a unique auto join value instead of the one global value.
* Added a context menu using a picwin instead of the old buttons.
* Tiding up overall look of the dialog.
* /csconnect and /csmanage aliases have been changed to /csc and /csm respectively, for ease of use.

25/03/07 - v1.1

* Added /csconnect alias.
* Added option to toggle confirmation prompt on/off.

Contents:
This .zip file should include:
comserv.mrc - 7KB
mdx.dll - 41.5KB
views.mdx - 53KB
readme.txt - 3KB

Installation:
1. Extract the files anywhere you like on your system
2. In mIRC, type /load -rs X:\path\to\comserv\comserv.mrc


Usage:
To manage your common servers list, simply type /csm - or you can get to the management dialog via Menubar/Status Window popups.

When you've opened the dialog you can start adding servers straight away by pressing the 'Add' button which will ask you for a network description, server address and auto join channels.

If you need to edit any of the details you enter you can simply right click on that entry and click Edit Server. You can also remove any server by right clicking the entry again and clicking Remove Server.

Start Prompt - Toggles whether or not common servers should prompt to connect when mIRC starts
Prompt? - Toggles whether or not common servers should prompt you for confirmation before connecting
AutoJoin - This box will be checked if auto join is enabled for the selected server

Connecting:
When you have customized the addon to your liking you can connect to the servers via Menubar/Status Window popups or by simply typing /csc

A few people have been asking about channel key support. Keys DO work with the addon, you just need to add them after the channel like you would when using /join normally e.g: #chan mypass,#chan2 mypass2

Credits:
Dragonzap - mdx.dll and views.mdx
Khaled - mIRC

Bugs/Comments/Suggestions:
If you find any bugs or wish to comment or suggest something on the addon please feel free to e-mail me at palmer.andy@gmail.com


Thanks, Andy