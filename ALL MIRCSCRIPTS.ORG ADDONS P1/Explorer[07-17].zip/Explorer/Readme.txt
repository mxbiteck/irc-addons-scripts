mIRC WINDOWS EXPLORER v.1.0, �2005 Astro
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Welcome to the first version of mIRC Windows Explorer.

CHANGES:
	- Fixed a few bugs should now load properly
	- Added Icons to the popup menus
	- Changed some DLL directories to $shortfn to solve a few other 	  problems

I devised this script because;
	a) I didn't like the current available addons for exploring 		   windows
	b) I like doing things inside mIRC rather than switching 	   	   applications

FEATURES:
	- Toolbar for commonly accessed commands like copy, paste, 		  delete and rename, etc.
	- Allows you to cut, copy, delete and rename files and 	  		  directories
	- Create new folders and shortcuts (except to URL's or          	  folders at this stage)
	- Caching of recently visited folders to increase seek time 		  (can end up reporting false information like files that no 		  longer exist in that directory until refreshed)
	- History can be stored and shown in the "address bar" to save 		  clicking on folders of recently visited folders as well as 	  	  saving typing
	- Back and forward buttons (works with history turned on)
	- End User configurable style and folder settings
	- Selectable colour schemes (can even create new ones or edit 	  	  current ones)

CREDITS:
	- FiberOPtics -- mirc.fiberoptics@gmail.com for his shortcuts 	  	  and foldersize snippets (www.mircscripts.org)
	- Yochai Timmer for his Did-Tree snippet
	- da^hype for his recycle.dll, waiting for him to add a restore 	  and file/folder list option
	- dragonzap for mdx.dll
	- Misanthrop for his listfiles.dll which is a very fast 		  alternative to $findfile

INSTALLATION:
To install, simply extract all the files in to your mirc folder and type //load -rs explorer\explorer.mrc

a popup box will come up saying "thank you for downloading...", simply click "Ok"

USAGE:
type /explorer or navigate the menubar or status window menus to run mIRC Windows Explorer. Once done, a dialog much like what the real windows explorer looks like, will appear showing you on the left hand pane all drive connections plus my documents, etc. and on the right hand pane the list of files within the "My Documents" folder.

HOW TO..(How it works) Section:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	In this section I will describe how to use mIRC Windows Explorer in more detail. Lets assume the dialog is already loaded and showing the contents of the My Documents folder.

Starting with the "File" menu;

	Open: opens a selected folder or file in the right hand pane
	New Folder: creates a new folder within the current open folder in the right hand pane
	Delete: deletes the currently selected file or multiple files in the right hand pane
	Rename: renames the currently selected file in the right hand pane
	Properties: shows various properties relating to the currently selected file/folder in the right hand pane
	Close: closes the explorer dialog and any other dialogs associated with it

The "Edit" menu;

	Cut: cut the selected files to the copy cache (note: nothing happens to the original files until told to paste)
	Copy: copy the selected files to the copy cache
	Paste: paste contents of copy cache to current folder
	Select ALL: select all files
	Invert Selection: inverse the current selected files so the unselected ones are now selected and the previous selected are unselected
	Clear History: clear the recent visisted folders history
	Clear Cache: clear the recent visited folders cache

The "View" menu;

	Toolbar: show/hide toolbar
	Address Bar: show/hide address bar
	Status Bar: show/hide statusbar
	Large Icons: view right hand pane in large icons
	Small Icons: view right hand pane in small icons
	List: view right hand pane in list view
	Details...: view right hand pane in detail view
	Up A Level: sends explorer back one sub-directory
	Explorer Settings: opens the explorer settings/options dialog

The "Help" menu;
	About: displays the about dialog
	Contents: displays this file

TOOLBAR:
~~~~~~~
	Now to explain the function of the toolbar buttons from left to right

	Back: go back one step
	Forward: go forward one step
	Up A Level: send explorer back one sub-directory
	Refresh: refresh the disk and file panes (which clears the cache as well)
	Copy: copy selected files/folders to copy cache
	Paste: paste files/folders from copy cache
	Delete: delete selected files from folder
	Rename: rename currently selected file/folder
	Properties: displays the properties for currently selected file/folder
	Views: switch the right hand pane view from large, small, list and details modes
	Help: shows this file
	About: pops up the about dialog
	Settings: opens the explorer settings/options dialog

NOTE: If you right click the right hand pane or a selected file inside the right hand pane menus also popup displaying similar functions previous explained.

THE SETTINGS/OPTIONS DIALOG:
~~~~~~~~~~~~~~~~~~~~~~~~~~~
	On this dialog you have 3 main tabs; Caching, Display and Windows.

CACHING:
	This means explorer will store previously retreived folder contents in a temporary "cache" file so when the same directory is accessed again, it loads it from the cache file rather than get the directory contents again. This speeds things up, especially if you're accessing the WINNT directory! Con; it can lead to falsely reporting the correct current files in a folder until the next refresh and/or caching is cleared.

The first part is history settings. Clicking always store history will record the names and folder paths of access folders. This works in conjuntion with the "back" and "forward" functions. You can limit the number of folders in the history file by entering a number in the box next to the option; say, 30. The clear history button is there to clear the current history now. You can also clear the history each time the explorer window closes.

The second, directory caching allows you to previously mentioned store temporary folder information for faster access. It also allows you to either clear the cache now or on exit, when the explorer window close.

DISPLAY:
	This allows you to change the way the explorer window looks. You can change any colour by clicking on the relative icon such as for the left hand "drive" pane background or text colours and the right hand "file list" pane background or text colours.

	You can also select stored schemes by clicking the drop down arrow next to the "stored schemes" field and then clicking apply.

	If you want to add a new scheme, under "scheme name" type a new name then click "add scheme". The current scheme settings are now applied to the new scheme. Then, simply change the colours to what you want them to be and they are automaticly saved. Click "Apply" to apply them to the explorer window or choose another scheme and click "Apply".

	All stored schemes, except "Default" can be deleted by selecting it in the dropdown and then clicking "Delete".

WINDOWS:
	This allows you to remember the explorer windows position, what startup folder it should start in and what special folders to display in the drive list.

	You can set it to remember what size the explorer window is and its position as well as set the minimum window size so if the window sizes go below it, it restores it to those settings specified in X-Pos, Y-Pos, X-Size, Y-Size the next time the window is opened. You can also make explorer appear on the startbar (desktop) and ontop of all other windows when open.

	Start-up folder is the folder explorer should open each time it loads. You can set it to either use the last folder accessed or specify a custom one like "My Documents" for example, or "E:\MP3", etc.

	The Special Folders allows you to show either the My Documents, Start Menu, Favorites, Desktop, Internet or Recycle Bin folders in the drive list.

Thats about pretty much all there is to using mIRC Windows Explorer v.1.0. Please send any suggestions or bug reports to: 

	astro321@iprimus.com.au

Astro.