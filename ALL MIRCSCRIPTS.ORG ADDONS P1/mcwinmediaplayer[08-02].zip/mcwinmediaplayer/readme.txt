======================Readme======================
Name: mcWin Media Player v1.4
Author: mc_twistah
E-mail: mctwistah@engineer.com
Website: http://www.manowarscript.tk
==================================================

==================================================
   Versions
================================================== 
mcWin Media Player v1.0 - First public release

mcWin Media Player v1.1 - Converted icons into an icon library
                        - Fixed Playlist dialog
                        - Fixed adding directories when playlist is close
                        - Added Play, Add and Del Popups in the playlist using popups.dll
                        - Added transparency for the playlist using tdialog.dll
                        - Localized aliases to avoid conflicts with other scripts
                        - cleaned unneeded codes
                        - Changed main alias name into /mwplayer and other aliases
                        - Improved visual screen (changed list into text to make it flat in first open)
                        - Now it remembers the directory that you last added or browsed        

mcWin Media Player v1.2 - This version is all about addition of enhancements since there were no complaints by the users or reports of any kind of bugs 
                        - Added Playlist to HTML conversion
                        - Added DCC send HTML Playlist
                        - Added DCC send media files in the popup in the playlist dialog
                        - Added scrolling of text in the main player which is currently played
                        - Added size information in the playlist dialog
                        - Added spamming of media files playing in the main player
                        - Added usage documentation in the help file (help.htm)    

mcWin Media Player v1.3 - Fixed adding of dir(s)/file(s),deleting files, set dir, opening files etc...(now remembers the dir that you last broswed or added and starts on that dir when you want to add a dir/file again)
                        - Fixed the main player screen to prevent resizing itself when a file is played (used different method of embedding a media file in a html)
                        - Fixed the playlist (now it highlights the files that you are currently playing)
	   - Fixed the time in the HTML Playlist that is $time(hh:mm:ss tt) which is wrong
                        - Added Adjust Volume option
                        - Added previous, play, and next buttons in the playlist
                        - Changed the play, add, del icons in the playlist on right click (changed it into my own buttons)
	   - Made the playlist to be always on top so now, you can make it as your controller since it has control buttons

mcWin Media Player v1.4 - Fixed stopping of media file
                                                   - Fixed transparency method
                                                   
==================================================
   Installation
==================================================      
    *Unzip mcwinmediaplayer.zip  by using Winzip ( http://winzip.com )
or other zip aplications in your mIRC directory.

    *dir: C:\mIRC\mcwinmediaplayer\

    *Loading the addon: method #1
    In loading an addon just type this command ( /load -rs directory/addon.mrc )
in your editbox or where you type your messages.

    * /load -rs mcwinmediaplayer/mcMP.mrc or /load -rs C:\mIRC\mcwinmediaplayer\mcMP.mrc
    * This is what you have to type for this addon to be loaded.

    *Loading the addon: method #2
    You can load addons by pressing alt+r and the remote script editor will open
and then click on the menus: 

For mIRC 6.1 up:

First go to Remote Tab and click File, Load and then browse for the addon that 
you want to load and double click on that file (mcMP.mrc).

If the addon was successfully loaded, a confirmation in an active window will appear when the steps was correctly done.
    
==================================================  
   Technical Support
==================================================        
    You may contact the author if there are 
problems(Firstly, please check the help.htm included in this addon).
  
Website: http://www.manowarscript.tk
E-mail: mctwistah@engineer.com
Cel#: +639192530381 and look for macky
