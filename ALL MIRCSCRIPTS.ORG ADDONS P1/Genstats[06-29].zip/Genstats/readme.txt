[:: mIRC General Stats addon by Q[--_--]D ::] -=- README

To load, simply type /load -rs genstats/stats.mrc

That's about it.
If you need to tell me about any bugs or somethin you can find me in #V-MaX on undernet.

Enjoy,
Q[--_--]D.