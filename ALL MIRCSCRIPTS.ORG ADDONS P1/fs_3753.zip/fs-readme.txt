::::::::::::::::::::::::::::: Filesend :::::::::::::::::::::::::::::
::
::                      ** made by Vliedel **
:: 
::                       ** version 1.100 **
::
:: Please report bugs and suggestions to:
::
:: #Vliedel @ Quakenet
:: #Filesend @ Quakenet
::
:: Written and tested on mirc 6.2
::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



::::::::::::::::::::::::::::: INDEX :::::::::::::::::::::::::::::

- What is filesend
- Install
- Update
- How to use filesend
  - dialog
  - core commands and signals




::::::::::::::::::::::::::::: WHAT IS FS :::::::::::::::::::::::::::::

Filesend allows you to privately share files with somebody else, using a direct connection.
One of the users starts a server, other users can connect to it if they have the correct password.
When a connection is set up, users will see shared files of eachother and users can download those.



::::::::::::::::::::::::::::: HOW TO INSTALL :::::::::::::::::::::::::::::

- extract all files and place them in your mirc folder (default C:\Program Files\mIRC\)
- load filesend.mrc		/load -rs filesend.mrc
- load filesend.dialog.mrc	/load -rs filesend.dialog.mrc
- If asked, Yes run the intialization commands



::::::::::::::::::::::::::::: HOW TO UPDATE :::::::::::::::::::::::::::::

- close filesend
- extract all files, EXCEPT filesend.ini and place them in the folder you have the old files
- reload filesend.mrc		/reload -rs filesend.mrc
- reload filesend.dialog.mrc	/reload -rs filesend.dialog.mrc



::::::::::::::::::::::::::::: HOW TO USE FS :::::::::::::::::::::::::::::

Filesend comes in two parts, the dialog and the core commands.
The dialog script is all in the filesend.dialog.mrc file, the core script is filesend.mrc.


----------------------------- dialog -----------------------------

In case you don't want the files and/or filesend folder in the same dir as the script, you can edit the filesend.dialog.mrc first three aliases.
  fs.folder		return the path of the default filesend folder
  fs.settings.file	return the filename of the ini-file that stores the filesend settings
  fs.icon.file		return the filename of the icon-file

To open the dialog you can:
  - click the filesend icon on the toolbar (if its there)
  - use /filesend
  - invite someone (only works when enabled: rightclick on a nick --> filesend --> invite)

Connections
  - To set up a server, make sure you have the correct settings and click the "start server" button.
    Note that the used port has to be forwarded to your pc.
  - To connect to a server, click the "connect" button.
  - Connections will be shown in the left list, the connections list.
    Double clicking on a connection enables you to change the name.
  - To disconnect, select the connection you want to disconnect and click "disconnect"


The dialog has several tabs:
  - downloadable	A list of files you can download of someone (different for each connection)
  - shared files	A list of files you currently share 
  - queue		The current queue of data to be transferred (different for each connection)
  - downloaded		A list of files you downloaded of someone (different for each connection)
  - shared dirs		A list of directories you share
  - settings		All settings, remember to click apply when you changed settings
  - log			The current log, wich will be written to a logfile later (different for each connection)

  Downloadable tab:
    To download files, select the file(s) you want to download and press "download", or double click on the file you want to download.
    To sort files, click on the corresponding button above the lists.
    To search files, enter a (wildcard) text in the editbox and press "search". Matching files will be placed on top and are selected.

  Shared files tab:
    To add files, click the add file button.
    To remove files, select the files you want to remove and click the remove file button.
    Double clicking on a file in the list will open the file (if /run is enabled).
    To sort files, click on the corresponding button above the lists.
    To search files, enter a (wildcard) text in the editbox and press "search". Matching files will be placed on top and are selected.

  Downloaded tab:
    To open a file, select the file and press "open file", or double click on the file you want to open.
    When you press "open dir" the download folder will be opened. (both only work if /run is enabled)
    To search files, enter a (wildcard) text in the editbox and press "search". Matching files will be placed on top and are selected.

  Shared dirs tab:
    Dirs listed in this tab will be scanned when you start filesend, and the files in the dir will be added to the shared files.
    To add a dir to the list, press "add dir". To remove a dir, select the dir(s) and press "remove dir".
    Double clickin on a dir in the list will open the dir (if /run is enabled).  

  Settings tab:

    Client box
      Enter address, port and password of the server you want to connect to.
      You can save settings for different server, by using the save button.
      The load and delete button will load/delete settings.

    Server box
      Enter your ip, port and password.
      Listen time is the time you will accept new connections, connections already made won't have a time limit.

    General box
      Tab height is the height of the tabs, so you can change the size of the dialog.
      Check "integrate menus" if you want filesend on the toolbar and in the nicklist popup.

    Don't forget to press "apply" when you changed settings.


Warnings will be shown in the info box. To view all warnings, press "error log" in the log tab.


----------------------------- core -----------------------------

The core has several global aliases:
 1.  filesend.client <ip> <port> <pass> <nr of times to reconnect> <nr of times to retry file> [dir]
 2.  filesend.server <port> <pass> <nr of times to retry port> <seconds listen time> <nr of times to reconnect> <nr of times to retry file> [dir]
 3.  filesend.listen.restart [port] [pass] [nr of times to retry port] [seconds listen time]
 4.  filesend.request <sockname> list
 5.  filesend.request <sockname> <fileid> [fileid] [fileid] ...
 6.  filesend.adddir <dir> 
 7.  filesend.addfile.user
 8.  filesend.addfile.bot <filename>
 9.  filesend.remdir <dir>
 10. filesend.remfile <fileid> [fileid] [fileid] ...
 11. filesend.flist.send
 12. filesend.checkpws
 13. filesend.server.stop
 14. filesend.client.stop
 15. filesend.sockclose.msg <sockname>
 16. filesend.sockclose <sockname>

 Explanations:
 1.  Starts a client connection. It connects to the given ip and port, and uses the given settings.
 2.  Starts a server on the given port with given settings.
     Listen time is the time you will accept new connections, connections already made won't have a time limit.
 3.  If you have a server running but it stopped listening, you can start listening again with this command.
 4.  Requests the shared files list of the given connection (you can combine this with command 5).
 5.  Requests files of the given connection. Files are unique by fileid as given in the sent filelist (given in the getlist signal). 
 6.  Adds all files in the given dir to the shared files list, this will not include files in subdirs.
     If the shared filelist is empty then this command will be a lot faster, so it is adviced to add the dir with the most files first.
     $filesend.adddir(dir) can also be used, in this case the number of added files will be returned.
     When you use this identifier the new filelist won't be send, you'll have to use command 11 for that.
 7.  Add (a) file(s) to the shared files list, using a select file dialog.
     $filesend.addfile.user can also be used, in this case the number of added files will be returned.
     When you use this identifier the new filelist won't be send, you'll have to use command 11 for that. 
 8.  Add a file to the shared files list.
     $filesend.addfile.bot can also be used, in this case the number of added files will be returned.
     When you use this identifier the new filelist won't be send, you'll have to use command 11 for that.
 9.  Removes all files in the given dir from the shared files list.
     Note that when you removed a file in the dir from your hdd, it will not be removed from the shared files list by this command. 
 10. Removes files from the shared list. Shared files are unique by fileid as given by the addfile signal.
 11. Send the shared filelist to all connections.
 12. Server disconnects all connections which aren't verified yet and stops listening for new connections.
     This alias can be used in case you want to stop listening before listentime is over.
 13. Stops all server connections, and if listening stops that too.
 14. Stops the client connection.
 15. Sends the other connection a notification that the connection will be closed.
 16. Closes a connection. (it's not adviced to use this command for the filesend.listen socket)


Signals:
 filesend socklisten.open	Your server started listening for connections.			$2 = port
 filesend socklisten.reopen	Your server started listening for connections again.		$2 = port
 filesend pw.denied		Your client password was denied by server.			$2 = sockname
 filesend version.accept	The connection accepted the version of connected.		$2 = sockname
 filesend version.denied	Version did not match connections version.			$2 = sockname   $3- = connections version
 filesend client.close		Your client connection was closed.				$2 = sockname
 filesend disconnected		A connection was closed.					$2 = sockname
 filesend socklisten.close	Your server stopped listening for new connections.		
 filesend server.close		Your server was stopped.					
 filesend quiting		A connection is going to close.					$2 = sockname

 filesend getlist		A new filelist of a connection is going to be received.		$2 = sockname   $3 = 0   $4 = nr of files
 filesend getlist		A file of the filelist is received, file doesn't exist.		$2 = sockname   $3 = fileID   $4 = -1   $5- = filename
 filesend getlist		A file of the filelist is received.				$2 = sockname   $3 = fileID   $4 = size   $5- = filename
 filesend addfile		A file is added to the shared files.				$2 = fileID   $3- = dir\filename
 filesend remfile		A file is removed from the shared files.			$2 = fileID
 filesend getfile.start		A file is going to be being received.				$2 = sockname   $3 = fileID   $4 = size   $5- = filename (in case filerenaming was needed, filename will be renamed filename)
 filesend getfile.missing	A requested file does not exist anymore.			$2 = sockname   $3 = fileID   $4 = size   $5- = filename (in case filerenaming was needed, filename will be renamed filename)
 filesend getfile.done		A file is received.						$2 = sockname   $3 = fileID   $4- = filename (in case filerenaming was needed, filename will be renamed filename)
 filesend getfile.err		A corrupted file is received.					$2 = sockname   $3 = fileID   $4 = retry nr   $5 = max retries   $6- = filename (in case filerenaming was needed, filename will be renamed filename)
 filesend sendfile.start	A file is going to be send.					$2 = sockname   $3 = fileID
 filesend sendfile.missing	A requested file doesn't exists anymore				$2 = sockname   $3 = fileID
 filesend sendfile.done		A file was sent.						$2 = sockname   $3- = dir\filename
 filesend queue			The queue was changed.						$2 = sockname   $3 = status (idle/requesting/listing/sending)   $4- = queue
 filesend requestedfile		A file is requested from a connection.				$2 = sockname   $3 = fileID
 filesend requestedlist		The filelist is requested from a connection.			$2 = sockname
 filesend sendlist		The shared filelist is going to be send.			$2 = sockname

 filesend error sock.notfree	Connection was unable to start, sockname was not free.		$3 = sockname
 filesend error dl.path		Invalid download path is used.					$3 = sockname   $4- = dl path
 filesend error port.notfree	Port used in command 2 or 3 is not free.			$3 = sockname   $4 = port  $5 = retry nr  $6 = max retries 
 filesend error sockopen	Your client was unable to connect.				$3 = sockname   $4- = sock error message
 filesend error reconnect	Connection is reconnecting.					$3 = sockname   $4 = reconnect nr  $5 = max reconnects
 filesend error addfile		You tried to add a file that doesn't exist/has double spaces.	$3- = dir\filename
 filesend error change.flist	You tried to change the shared files list while listing
				the file list to a connection.
 filesend error			Other errors.							$2 = sockname

 filesend.getfile		A piece of a file you're downloading is received. 		$1 = sockname   $2 = fileID   $3 = bytes left   $4 = bytes received
 filesend.sendfile		A piece of a file you're sending is sent.			$1 = sockname   $2 = total bytes read   $3 = bytes sent


Queue:
 The queue has items seperated by commas (chr 44). The following items are possible:
 rl		Will request the filelist of the connection.
 sl		Will send the shared filelist to the connection.
 rf <fileid>	Will request a file from the connection.
 sf <fileid>	Will send a file to the connection.
 q		will send the quit message.
