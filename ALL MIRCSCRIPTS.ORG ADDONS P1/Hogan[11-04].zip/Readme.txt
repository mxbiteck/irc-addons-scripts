7:43 PM 11/4/05

Requires mirc version 6.0 or higher.

Unzip Hogan.zip in your main mirc folder.

load it bye typing.

/load -rs hogan.ini

Right click in the channel and click Hogan's alley to  "on".

To play , click on the bad guys only. Men with guns.

Do not click on good guys, woman and cop.

Points is collect for every Bad guy.

Points is subtracted for ever miss, or good guy hit.

After 4 rounds, 36 sucessfull of failure clicks the game will auto end.

Email any comments or suggest to coevuncannon@hotmail.com

