;==========================================================
; Project    : Complete Protection System (CPS)
;==========================================================
; Author     : amit (uber @ dalnet #mumbai)
; Email      : amit9815@yahoo.com
; Version    : 7.0
; Copyright (C) 2006 Amit (amit9815@yahoo.com)
;==========================================================


	CPS is one the most powerful channel and personal protection
 add-on that exists for the *mIRC* a popular IRC client. It comes
 with a built in help file. CPS includes the latest in IRC
 protection and protects you from 43 of the most common IRC
 offences. CPS also has the quickest reaction time so it is also
 one of the most effective ways to protect yourself. 


CPS version 7.0

;===================================
	Introduction to CPS 
;===================================


	This is version 7.0 of CPS. If you have a suggestion/bug/request
 please contact me and I will try to help you out. Please check my
 contact info. CPS features are listed in features section please
 read on.
_______________________________________________________________________________________

	CPS has gone through various changes. The original CPS was based
 on ini files and was quite slow. When I decided to release it one of my
 friend gave me the idea to use a dll and hash table to make it quicker.
 Thus I used aircdll.dll by tabo mixed with Signal events and hash
 tables I made it one of the quickest script. I would like to thank
 tabo(undernet) for making such a great dll file.

	CPS is very configurable through dialogs and easy to use for all
 kinds of users, it is well organized and simple to use yet very advanced
 in its features. It does not contain any offensive features.

	Although CPS is an add-on I highly suggest you don't mix CPS with
 full mIRC scripts that already have some sort of protections in them.
 There is a slight possibility that CPS will not coexist with other full
 scripts that already have some sort of protection scripts in them - so
 be warned!

	If you want to use CPS for personal use you are free to use it.
 For those who want to use CPS in there scripts which are to be released
 for public please mail me and ask for permission.

Thanks for downloading CPS and for your support.




;===================================
	Features of CPS 
;===================================



1)  Protects you from 43 of the most common IRC offences. These are.. 

	Channel swear				Text repeating. 
	Text flooding. 				Long text. 
	Excessive punctuations. 		Excessive capital letters. 
	Excessive control codes (colors). 	Non English text. 
	Mass URL advertisement. 		Mass channel advertisement. 
	Non letters flood. 			Sound play. 
	Trout slaps. 				Exploiting users. 
	Channel notices. 			Bad nicks. 
	Bad idents. 				Bad scripts. 
	Being in bad or rival channels. 	Clones. 
	Drone bots. 				Mass join flood. 
	Quit flood. 				Guest nicks. 
	Revolving doors part flood. 		On join ctcp. 
	On join notice. 			On join message. 
	Black listed nicks joining. 		Away scripts. 
	CTCP Channel Flood. 			Klined quit. 
	Rejoin / Ban evasion kick. 		Excess flood quit. 
	Spam quit. 				Private spam protection.*
	Idle Nick Kick				Query Flood+
	Private Text Flood+			Private Action Flood+
	Private Invite Flood+			Private CTCP Flood+
	Private Notice Flood+


2)  CPS uses Signal events to make the processing of kicks quick
    and you don't lag at all.

3)  CPS merges with aircdll.dll(tabo) to do most of its processing
    so it becomes very quick as khaled himself has described in his
    help files that mIRC process much quicker with dll's as
    compared to ordinary scripts.

4)  CPS uses hash tables to store data which allows you to add
    unlimited amounts of channels in protected list and all with
    different configurations.

5)  Yes you read it right CPS is channel specific i.e. you can
    make different settings for different channels.

6)  You can configure which kicks you want to set on and which
    kicks you don't want to set on for a particular channel. 

7)  You can configure kick messages, ban time, ban types; choose
    between kicking a nick or kick + banning a nick out of a channel. 

8)  You can choose to kick a person strait away or set an F-key
    trigger which when you hit will kick that person; else it will
    echo you that nick has broken a rule and hit f-key to kick ban
    the user. More about that later.

9)  Out of these 43 kicks 17 carry the option of warning the user
    before kicking. Note:- if you have switched on the warning for
    a kick that applies to all the channels since warning system
    is completely independent of channel settings.
   + You can edit these 17 warning messages by using the warning editor.

10) You can configure to see warning echo's according to your own ease.
   + You can configure them to be in active window 
   + You can configure them to be shown in status window only.
   + You can configure echo's to be time stamped or vice versa.
   + You may choose echo's to be accompanied by a sound file so
     that if your mirc is inactive you may know that there is a rule
     breakage in your channel.

11) CPS has a channel limiter which will automatically set +l mode
    in channels that you are opped in according to the minimum user
    limit you want.
    + You can configure the minimum user limit you want.
    + You can configure the time after that mode is re-setted in
      the channel.

12) CPS supports all 10 ban types of mirc.

13) CPS comes with the option of setting a particular channel options
    as default options since it is quite painful to add same setting
    to all channels. All you have to do is add a channel configure it
    to your needs and then make its settings default settings. And then
    when ever you add another channel it will have the same configuration
    as your previous channel.

14) CPS has setting dialogs for every kick. which means more options
    and more comfort. 

15) CPS allows you to add "channel specific protected nick list" these
    nicks are exempted from all kicks in that vary channel. This will
    come in handy if you want to add the ops of a channel in protected
    list. It will protect that nick even if he is deoped.

16) Each Channel can be specifically configured to kick ops or voiced.

17) CPS has socket spam checkerbot with which will join your protected
    channel(you can setup channels) and will cycle after a certain period
    of time(you can also set this up) and upon being spammed in private
    it will auto message ur script to kick the nick. NOTE: it auto
    signals the script not you so the kick is far more quickly done.

18) CPS has a dialog to manage clones in your channel with options like
    kick, kick-ban, ban, warn(notice), set warning msg, set kick msg so
    that you can manage clones in your channel. It support all 10 type
    of clone ip scan.
19) CPS has an ip/domain scanner. Just enter an ip in the input box and
    cps will display all the nicks that match that in the channel. 

;===================================
	!! Some extra features !!
;===================================


1)  Swear kick offers you too add as many words in swear list with the use
    of wild cards. Wildcards? Well let me explain with an example: Say you
    want to kick when someone says the word "asshole" in a channel main
    screen you can add the word "*assh*" (with the stars) in the swear word
    list and the user will be automatically checked. Also CPS introduces a
    new feature in Swear kick checking i.e. changing ASCII characters to
    their valid form. People on IRC are way to smart since they know that
    we have protection against swear the abuse in sort of a coded language.
    i.e. "@$$h0|e" the human brain knows that this is an abuse but our mirc
    doesn't well CPS has the solution to that it replaces the ASCII and number
    characters commonly used in such swears to alphabets or English language
    letters and then compares them with the words in swear list; so if a
    person did abused by using such cheap tricks he will still be kicked. 

2)  Repeat kick offers a new feature kick too; generally in repeat kicks if
    there is a warning option then it will warn after first offence and then
    kick on second attempt. This is a little complicated since if you have
    setted up your kick to kick after 3 or more repeats then it will warning
    after 3 repeats and kick after 3 more repeats making it actually kick
    after 6 repeats. CPS has overcome this annoying error and now if a
    person repeats even once after being warned he will be kicked. Similar
    feature if there for sound play flood, text flood, channel notice kick. 

3)  Url ads and channel mass advertisement kick also offer a new feature
    i.e. you can add exceptional items (urls, channels) through the settings
    dialog and if some says urls in channel the script will first check if
    there is any of the exceptional urls's or channel names in the line; if
    there is even a single good channel name or url name in the list the
    script will not kick or warn the nick, similarly if there are no
    exceptional channels or urls found in the line it will do the required
    action. 

4)  The exploiting users kick checks the lines said by a nick for common
    exploits in order to protect newbie's. 

5)  The Drone bot kick is completely new. It kicks 90% drones correctly but
    this kick can never be perfect so I have added a small feature. Whenever
    a nick gets kicked for being a possible drone he/she is sent a notice
    with a Key and told to type a command with that key. If they are not
    drones they can type that command and they will be automatically un
    banned from channel and added to an exception list. Note:- exception
    list carries 15 of the latest nicks un banned by this procedure; and this
    list stays even if you exit mirc. But if there are more than 15 nicks it
    deletes the name of first nick from that list. This is because of the
    limitation in mIRC upon the size of a variable. 

6)  CPS can be made to set Fkey (F9 or Shift + F9) to kick a user i.e. You
    can setup CPS in a way that on any rule breakage CPS will only echo you
    that the nick has broken the rule and it will entirely depend on your
    if you want to kick him or her out. To help you kick quickly and that
    you don't have to type long and huge commands to kick CPS will
    automatically set an F-Key as the trigger, you can hit that F-key and
    the nick will be kicked out of the channel with fitting kick reason
    (More help on this topic is given ahead). 

7)  CPS has a built in Kick counter. 

8)  CPS can be configured to add your channels urls in your kick message.
    This is useful if you are in some help channel and you want the offender
    to read channel rules from your channel website. Or you can add the name
    of your help channel directing the kicked user to join that help channel
    to get matters sorted out. NOTE:- this feature is also channel specific. 

9)  3 offences of above mentioned 37 don't kick a nick but only ban since
    kicking that nick is not possible. These are Spam quit, Excess flood
    quit, Klined. 

10) There is a ban detector in the script that will echo in status window
    all the nicks banned when an op bans a certain ip in the channel. Very
    use full if you want to filter out nicks from banned ips off the channel. 

11) SocketBot can be used in various ways just check the faq section of
    socketbot in faq.txt file.

12) From v6.0 cps will set +m for 60 seconds in case of a repeat flood


;===================================
Installing CPS 
;===================================

	Index.


	NOTE:- It is assumed that YOU have basic knowledge of mIRC commands
 and know how to use basic windows dialogs. If your are below that level it
 is highly recommended that you don't continue with installing this software
 on your computer. Since i will not be any case responsible for damage caused
 by wrong installation of this software.

		I) Requirements 
		II) Un zipping (Choosing correct install path) 
		III) Loading Files 

-------------------------------------------------------------------------------

I) Requirements

	Before attempting to install this software make sure you have
	fulfilled following requirements. 

	1) You are on Window (98 or above). 
	2) You have mIRC version 6.03 or above. 
	3) You already have installed mIRC 6.03 or above in some
	   folder. *Without space in its path.*
	4) You don't have alias (F9 and Shift + F9) defined in
	   your script. 
	5) You have a decompressing software to unzip/unrar the
	   file you downloaded. 
	6) You have read the License agreement and completely
	   agree to it. 

	If you have performed all the above actions correctly
	you may read on and install this add-on. 

-------------------------------------------------------------------------------

II) Un zipping (Choosing correct install path) 


	NOTE:- CPS requires to be in its specific directory; please follow the
 below steps exactly the way they are mentioned to avoid any problems regarding
 wrong path of the software. 

	First of all it is requested that you install this add-on in a script
 that has no protection system in it because it will no co-exist with such
 scripts. Be warned!


		Ok now let us go on to installing the software. 


	First how to choose the path. You need to find the path of your
 mirc.exe i.e. find out where it is installed. You can do that by typing the
 following command in any mirc window.


				//echo -a $mircdir


 When you type that command it will echo the path of your mirc directory. Now
 open your explorer and browse to that path. Say the above command gave you
 this path -->


				C:\mirc\


 So open "C:\mirc\" and unzip/unrar the downloaded file in such a way that it
 creates a sub-directory in the above path called "CPS".


				C:\mirc\cps\


 To verify if your installation path is correct check the path of
 file called "Firststep.mrc" it should be:


			C:\mirc\cps\firststep.mrc


 If you did all these correctly you may move to the next step!! 


-----------------------------------------------------------------------------------------

III) Loading Files

Alright we now move to the next step!!

Open you mirc.exe now (If not already opened). and type the below command.


	/Load -rs cps\firststep.mrc

	It will generally open a dialog that will say
	
	 "one or more script has been loaded....."


	NOTE:- If that dialog opened don't hit enter!! Click on "Yes" button
 with your mouse pointer. Else installation will fail. If you already hit
 enter then again type the above command and this time click on "Yes" button.


	If that dialog didn't popped up then you will see the About Dialog
 popping up. If it does your installation is successful. If you don't see
 the About dialog opening up it will mean there was some possible error.
 Although there will be a message why installation failed like may be you
 already had some aliases defined which need to be free or you downloaded
 a corrupt setup with some files missing if the messages doesn�t help you
 solve your problem. Please mail me with copy of files you downloaded
 (original setup) and copy paste the messages you got in mirc status
 window while installing the software. I will try to help you. Check my
 contact info.


;===================================
;	Using CPS 
;===================================

	NOTE:- You might find CPS a little difficult to understand if you
 are using it the first time since it is quite complex, I will try to help
 you in the best way I know, still you are expected to explore CPS since
 its impossible to explain each and everything about CPS in this help file.
 If you have any queries even after reading this file or you don't understand
 some thing you may contact me and I will love to help you out. Thanks..

---------------
Basic Structure
---------------

 Before we start using CPS let me explain how CPS works and its basic structure
 so that you can configure it better to its fullest advantage.

 Basically CPS has 5 levels of processing i.e. once it detects a rule breakage
 it loops throw all 5 levels and finds out  which one has been configured by
 you; and then does the action. These 5 levels are...

1) Do absolutely nothing
2) Warn the user on first offence and kick the user Automatically on 2nd offence.
3) Don't warn the user and kick automatically.
4) Warn the user on first offence and on second offence set an F-key as a manual
   trigger to kick the user.
5) Directly set the f-key without warning the user.

 The first 3 levels are self explanatory its the f-key thingy that sounds a bit
 complicated. Well what CPS does is that it sets a few variables which store
 the kick message, nick to be kicked, channel in which to kick etc; and then
 it echo's to you that CPS has detected a possible rule breakage in a channel
 that is in your protected list and if you want to kick that user out you may
 hit the F-key! This helps a great deal since its quite painful writing huge
 commands to first ban the user then kicking the user with adequate message.

 Further CPS allows you to set Custom kick messages, ban types, ban time or you
 may opt to only kick the user without any ban! (remember to switch off rejoin
 kick off/ or keep it manual since it might take a quick rejoin after kick by you
 as ban evasion).

	NOTE:- A warning is only sent if the kick is on. If you have switched off
 a kick for a channel warning for the same cause won't be sent too!


---------------
Adding Channels
---------------

 So we finally made it to adding channels. Well all you have to do is right click
 on the status window it will have a popup named "Complete protection system" go
 to its sub menu and click on "Setup". It will open the main setup dialog with the
 channel "#Amit" added as default. At first all buttons and check boxes will be
 disabled. No need to worry click on #Amit and you will see every thing enabling
 as simple as that.

 Now to add a channel just type the channel name in the edit box above the combo
 box where you saw the channel #amit in list. Then click on "Add" button. It will
 minimize the setup dialog and open another input request. Add the url of your
 channel or the name of your help channel there or some goofy message heh (that
 input is totally optional you may click cancel if you want to add nothing).
 Whatever you entered in that box will be added to the kick message; the kick
 messages of that particular channel only. As soon as you click ok or cancel the
 setup dialog pops up again and this time all the buttons are enabled. That's it
 you have successfully added a channel in your protected channels list. see
 there's nothing to it :-).


----------------
Editing Channels
----------------

 Editing channel means editing the channel settings for that particular channel.
 Once you added a channel you will see its name appearing in the combo box. This
 will stay there now forever (well until you remove it, which i will tell you
 later) . Once added channel stays in protected list forever until it is manually
 removed you. So just click on the channel name and you will see the buttons and
 checkboxes enabling . A checkbox checked means that particular kick for that
 channel is ON or processed. To do the settings for that kick just click on the
 "Settings!" button next to the checkbox and it opens a small dialog with the
 options available for that kick. These dialogs are self explanatory. Once you
 do the settings on the small dialog Click On "Save & exit" button and proceed
 further to set next kick.

 Once you are done setting all kicks according to your needs you may proceed
 further and add another channel and do its settings in similar way. IF you want
 to have same settings for all channels just add one channel and do its
 configuration then. Now click on "Make current settings default" button in setup
 dialog the current settings now are the default settings for all channels which
 will be added afterwards. This setting is not reversible. You have to do a
 complete reinstall to get back the original settings. After your done just click
 on "Save & exit" and you are done.


-----------------
Removing Channels
-----------------

 Removing channels from protected list is very simple. Just open the setup dialog
 and click the channel name you want to remove then click on "Remove" and that's
 all to it. Once you delete a channel you will lose all its configurations and if
 you re-add the channel it will have the default configurations; not the once that
 you have setted up.


-----------------------------------------------------------------------------------------

Contact Info

I can be reached in many ways here are a few

* Mail me at -=[ reapers_wicked_twin@hotmail.com // amit16262@yahoo.com ]]=-

* On iRC DALnet -=[ My nick is amit^ or amit on DALnet ]=- 

=========================================================================================

;===================================
	Credits
;===================================

Check the about dialog

========================================================================================= 
CPS By Amit (reapers_wicked_twin@hotmail.com)
This addon has been released under the GNU/GPL, read 'copying.txt' for more info.
=========================================================================================
