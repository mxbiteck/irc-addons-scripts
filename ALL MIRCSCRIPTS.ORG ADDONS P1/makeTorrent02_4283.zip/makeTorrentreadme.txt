makeTorrent v0.2 Torrent Creator
By Scab (scab@scab.se) No Rights Reserved
Dedicated to #spectrial


DEPENDENCIES
 mIRC v6.34. Consider yourself lucky if it works with any other version.


INSTALLATION
 1. Extract the ZIP wherever you want.
 2. Open mIRC.
 3. Type in Status: /load -rs x:\path\to\makeTorrent.mrc
 4. If asked, click Yes to allow initialization commands.


USAGE
 Launch the script from the menubar popup menu or with the /maketorrent
 command, whichever you prefer. Assuming I didn't mess up my UI badly,
 the dialog should be self-explanatory.


UNINSTALLATION
 Use the menubar popup menu and choose Uninstall.
 

FAQ
 Q. Why will my BitTorrent client not accept the .torrent files that
    makeTorrent generates?
 A. It should. Email or DCC me the .torrent file in question along
    with the name of the client you're using and I'll try to find out
    what's going wrong.

 Q. Can I modify makeTorrent as I see fit and make my own version
    available for others to download and use?
 A. I reserve no rights for this script; it is in the public domain.
    If you want to change it, build on it, release your own version
    of it or whatever, by all means go right ahead. In fact, if you
    think you've made good improvements on it, I'd be interested in
    seeing what you did myself. I only ask that you not call your
    script "makeTorrent" as to avoid confusion.
 

CONTACT / BUG REPORTING / SUGGESTIONS
 IRC: Scab on Rizon/QuakeNet
 Email: scab@scab.se
 I'm not on any IM networks.
 

2009-03-14