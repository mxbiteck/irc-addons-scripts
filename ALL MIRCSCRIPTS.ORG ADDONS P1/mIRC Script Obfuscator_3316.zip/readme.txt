;##########################;
;# mIRC Script Obfuscator #;
;# Version 1.1            #;
;# By IceShaman           #;
;##########################;

1. About
2. Limitations
3. Changelog
4. Usage
5. Contact

About
-----

mIRC Script Obfuscator is a script designed to obfuscate other mIRC scripts. That is to
say, scramble them to stop people easily viewing/modifying them. It does this in
numerous ways, such as changing variable and alias names in the script.

It is a proof of concept script designed to show how obfuscation can be done. It currently
works using regular expressions to find and replace. This is a slow and inaccurate method
prone to bugs with non-standard scripting. As this is a proof of concept, it should not
be used for any serious scripts (why would it anyway?) and it could break at ANY time.
It is not designed for large or complex scripts and it DOES take awhile to obfuscate
such. Support is provided on a scale that redefines minimalistic, if it makes a mess of
obfuscating, tough luck, unless you can provide good insight or a changed regex that fixes
the problem, you're on your own, change the offending lines so they're more standard
or something.

Also note the script is currently in very early stages and probably won't be updated much,
if at all. It was made for the purpose of showing what could be done, not actually going
out there and doing it all. If you want to improve it, go ahead, but don't bother me
with issues surrounding it.

Oh and finally, if you want to use this in any sort of "War" script or suchlike, you're
completely missing the point of it and don't ever try to contact me. This has a very
limited scope of legitimate uses such as: for parts of a script that works as an online
game and you don't want to make it too easy for cheaters to ruin it, or to learn about
basic search and replace parsing, or regular expressions. 


Limitations
-----------

- Doesn't do global variables or aliases.

- May fail to obfuscate without warning (regular expressions are used to check lines, as
  such, without a proper tokenizing parser mistakes cannot be noticed).

- Will fail with non-standard/exotic scripting.

- Will fail on very large lines (use $& to break up the lines if this affects you).

- Works slowly as relying on lots of regular expressions

- Hash settings are global only (can't be done on a per file basis)
  This would be quite easily to implement, but I don't want to change the dialog and 
  I just don't care enough.

- If the Hash charset is too small and there's more variables than potential charset names,
  the script will infinite loop and die. Be warned.

- Only searches for .mrc files when adding a directory (there's a variable called %extension
  you can find and edit yourself if your script uses something daft eg nns).



Changelog
---------


Version 1.1:

- Added a small check to make sure hashes generated don't match the name of any of the
  current items (aliases, variables etc) found in the code. This means you _should_ be
  able to obfuscate a file more than once.

Version 1.0:

 - Initial release


Usage
-----

To load the script unzip it to your mIRC directory and in mIRC type in
/load -rs obfuscate.mrc 
(No messages are given to indicate the load)

Once loaded you can launch the dialog by typing in /mso in mIRC.

In the dialog you can use the 'Add' and 'Directory' buttons on the 'Files' tab to add the 
scripts you want to be obfuscated. If 'Add' is used you may only select files in the same 
directory and they will be written to $scriptdir. 
'Directory' allows you to add all files in a directory INCLUDING all the files in the 
directory tree (subdirectories). 'Add' and 'Directory' CAN be used in conjunction with each
other. The 'Del' button will remove the selected file and it will not be packed. The 'Clear' 
button will remove all files from the pack list.

For every file to be obfuscated you can select it and set various options. These are
explained fully below as they are also used in the "Settings" tab for default/global
options. You can set per file options using these checkboxes below the listbox.

The settings tab provides obfuscation settings for all files, though you can overrule
them by setting individual file options:

 - Obfuscate variables: obfuscate all variable names in the file (affects local
   variables only - global variables are ignored).

 - Obfuscate binvars: obfuscate all binary variables in the file.

 - Obfuscate custom aliases + identifiers: obfuscates all local aliases and any identifier
   reference to them (redirects put in for inbuilt functions).

 - Strip comments: Strips out all ; comments and /* comment blocks.

To obfuscate the files simply press the 'Obfuscate' button on the 'Files' tab. Files are
written to a subdirectory (Defaults to 'Obfuscate' if left undefined). The status tab
shows the current status of the obfuscation (with lots of large files it may take
awhile to complete). To break off early simple hit the 'Halt' button in the 'Files'
tab which is available only while obfuscation is in process.

To make life easier you can save your settings. This will save all the files and their 
individual options as well as the global options to a file (which can be reloaded at any 
time). You can access save/load from the 'File' menu. The 'File' menu also contains an 
unload option. This will clear all the files to obfuscate and your options.


Contact
-------

You can contact me using the email: iceshaman@gmail.com