$findmdx() by teh |
------------------

ABOUT:
----------------------------------------------
An addon whose purpose is to minimize the size of addons which use MDX -- by allowing the author to use already present MDX files 
in $mircdir or download at runtime, if none are present.


FILES INCLUDED 
------------------------------
Your findmdx.zip file should contain the following:

findmdx.mrc--------4864B---The mIRC script file
mUnzip.DLL---------86016B--Unzipping DLL by Kamek
findmdx-readme.txt-1122B---This File

INSTALLATION
------------

Extract all files anywhere in your mirc directory, and load the script by typing //load -rs $findfile($shortfn($mircdir),findmdx.mrc,1)


USING
-----

Usage: /findmdx <-as> [file1] [file2] [fileN]
Comments: -s searches for file(s) in your mIRC directory and moves it, if not found it downloads it. -a downloads all files.


CREDITS
-------

/sleep alias by Online
mUnzip.dll by Kamek


FEEDBACK and CONTACT INFO
-------------------------

Email: teh@mircscripts.org
irc.gamesurge.net - #script


TODO:

@Picwin Status [mdx d/l]
