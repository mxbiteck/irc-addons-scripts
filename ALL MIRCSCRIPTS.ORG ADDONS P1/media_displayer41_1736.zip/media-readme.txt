Media Displayer 4.1
 by Krofinzki - http://krof.net
-------------------
This addon will allow you to display:

 1. What you're listening to in Winamp (Only 2.x & 5.x) - http://www.winamp.com
 2. What you're viewing in Mplayer6.4 - mplayer2.exe (comes with Windows 95/98/ME/2K/XP)
 3. What you're viewing in Media Player Classic - http://sourceforge.net/projects/guliverkli/
 4. What you're viewing in VLC Media Player - http://www.videolan.org
 5. What you're viewing in BSPlayer - http://www.bsplayer.org
 6. What you're viewing in ZoomPlayer - http://www.inmatrix.com/zplayer/
 7. What you're viewing in PowerDVD - http://www.gocyberlink.com
 8. What you're viewing in CDisplay - http://www.geocities.com/davidayton/CDisplay.html
 9. What you're encoding in VirtualDub (Works with clones also) - http://www.virtualdub.org
10. What you're downloading/sending in Mirc (DCC)
11. Where you're surfing the web using Internet Explorer/Firefox
12. Your DC++ statistics (should work with all DC++ clones) - http://dcplusplus.sourceforge.net
13. Your FlashFXP statistics - http://www.flashfxp.com
14. Your FTPRush statistics - http://www.ftprush.com
15. Your Clocks (multiplier, FSB & such), temperatures, voltages, fan speeds through Everest (Ultimate) 4.0 - http://www.lavalys.com
16. Your OS
17. Your Uptime
18. Your Motherboard
19. Your CPU
20. Your RAM Usage
21. Your Harddrive(s) stats
22. Your Graphics card
23. Your Screen stats
24. Your Sound card
25. Your Network card


Installation:

1. Make sure you have version 6.16 (or above) of Mirc. You can check this by typing
   //echo -a $version

2. Unzip media.mrc, gos.dll, mpcinfo.dll, gtsmirc.dll and colors.bmp
   into your mIRC folder, or any other folder of your choice.
   (and you should probably put media-readme.txt there also)

3. Type: /load -rs media.mrc

   Remember to replace all files when updating

4. To see a menu right click in the channel/query window or go to "Commands" in the menubar.
   You can also display stuff by using these commands:
   /winamp /mplayer /mplayerc /vlc /bsp /zoomplay /pdvd /areader /cdisplay /url /vdub
   /stat /os /uptime /dcpp /flashfxp /everest
   /mobo /mem /cpu /hdd /gfx /screen /sound /net <- All of these also works as identifiers ($)


Frequently Asked Questions:

Q: How do you get Everest working?
A: 1. Make sure you're running Everest v4.0
   2. Go to File -> Preferences -> Hardware Monitoring -> External Applications
   3. Check "Enable writing sensor values to Registry".
   4. Press "Select all", then "OK".
   5. Type /everest in mirc

Q: I get a lot of "?" where values should be when using /everest
A: There's two possible explanations:
   1. You didn't do step 4 in the previous question. Read the above QnA again.
   2. Your computer doesn't have these hardware-sensors and thus cannot display this information.
      Usually this is because the computer being used is very old.

Q: It doesn't work! What should I do?
A: The most usual reasons are;
   1. You got another script loaded which gets in the way of this one.
      How do I know? Well, if it uses the same alias, then that's it =)
   2. Something is blocking the loading of default variables, this ruins everything
      and here's a possible fix: type /media.resetvars
   3. You are using the wrong app or version of the app. Winamp 3.x will NOT work
      Neither will wmp7-9. I'm sorry, but I can't add it :/

Q: When I try to display * I get: "* No such Com 'cominfo2' open (line 250, media.mrc)"
A: You're using a version of mirc that doesn't support COM, upgrade to version 6.16 or above

Q: When I type /hdd It just displays: hdd[]
A: This is directly related to variables issue, possible fix: type /media.resetvars
   You can also try checking "multi drive hdd display".

Q: The Winamp information messes up sometimes.
A: The displaying of Winamp information doesn't always work correctly if
   "Scroll song title in the windows taskbar" is enabled. 
   and VBR won't display as VBR it'll show as the current bitrate.

Q: I tried using BSPlayer and ZoomPlayer at the same time and it didn't work!
A: You can't have BSPlayer and ZoomPlayer open at the same time and
   display stats for both of 'em.

Q: Why doesn't the "Alternative Mplayerc file-information retrieval" option work for me?
A: Probably because you have "Store settings to .ini file" enabled in Mplayerc and/or
   "Keep history of open files" is disabled. Change these back to default and it should work.

Q: How do I uninstall the script?
A: Type /media.un

Q: I didn't read the faq but I still think this error uniqely only affects me and
   I'll ask you instead, where are you located?
A: READ IT DAMMIT

Q: Can you add <insert app here>?
A: Maybe, but probably not. Contact me about it and I'll see what I can do.

Q: Why are you so mean?
A: I'm not, it's just that everyone asks me the same stuff...

Q: Why don't you update your script anymore? :(
A: I just did! :) Now you're gonna have to wait another 2 years :p


-------------------
Version History:

4.1
 - Added: Option to disable bold in media stats
 - Fixed: Minor Mplayerc bug

4.0
 - Added: VLC Media Player support - /vlc
 - Added: Everest 4.0 support - /everest (read the FAQ please)
 - Added: DC++ support - /dcpp
 - Added: FlashFXP support - /flashfxp
 - Added: FTPRush support - /ftprush
 - Added: WMI support through COM - Provides lots more information, a little bit slower though and requires Mirc 6.16+
 - Added: Improved (more detailed) /gfx support
 - Added: Improved (more detailed) /cpu support
 - Added: Improved (more detailed) /screen support (removed Hz since most people use LCD monitors nowadays anyway)
 - Added: Motherboard info - /mobo 
 - Added: Sound card info - /sound
 - Removed: moo.dll - No need for it anymore when using mircs COM, also it was detected as virus by some (very lame) antivirus apps.
 - Removed: Dialup connection support - Relied on moo.dll and was basically pointless
 - Removed: mbm5 support - Relied on moo.dll and never heard of anyone using it... Use /everest instead
 - Fixed: Loads of small stuff of course, I don't remember what it was though :D
 - Fixed: Unloading/uninstalling proceedure has been improved greatly & fixed minor bugs

3.2
 - Fixed: MplayerC support improved for newer versions
 - Fixed: CDisplay 1.8 support (no support for older versions)
          Thanks to Hso for pointing this out!
 - Fixed: Random crashes
 - Removed: Getright support

3.1
 - Added: Uptime Record, requested by fiveOne5
 - Added: Alternate MplayerC File retrieving method
 - Added: Since easter is comming up.. guess :D
 - Fixed: Getright downloading information
 - Fixed: Nvida driver versions should work better now.

3.0
 - Added: VirtualDub support 
 - Added: Getright support
 - Added: BSPlayer support
 - Added: ZoomPlayer support
 - Added: Driverversion to /gfx (Only nvidia so far, Haven't been able to test anything else)
 - Fixed: Now supports all browsers

2.5
 - Added: An option to convert filenames to Large Case
          (Since some people seem to have problems with all letters in CAPS)
 - Added: DCC Get/Sends stats
 - Fixed: Lots of bugs, as usual.

2.4
 - Fixed: Mplayerc displays size again.

2.3
 - Added: CDisplay support - A great comic reader wich YOU should use. =)

2.2
 - Fixed: Tiny bugs
 - Fixed: MPC displaying can now show realmedia/quicktime/flash movies.

2.1
 - Fixed: You can now have much longer "listens to/watches" lines
 - Fixed: The extra space between the songtitle and the time has been removed

2.0
 - Added: More options for configlovers
 - Added: Indivudal stats for everything try /os /cpu /mem and so on...
 - Added: PC stats locally only displaying (also known as /echo :p)
 - Fixed: You can display the PC stats / media stats in any window now
 - Fixed: I am sure it was something else, I took a long time to do this...

1.9
 - Added: Media Player Classic support - Huge thanks goes to Gabest !
 - Fixed: Bad looking dialogs

1.8
 - Fixed: stuff wich you won't notice
 - Script cleaned up

1.73
 - Fixed: Hdd display crashes... It feels right this time.. ;)
 - Fixed: Better structure

1.72
 - Fixed: Dialup displaying bug
 - Fixed: Gfx displaying bug

1.71
 - Fixed: The hdd-display crashings, I hope... :-)

1.7
 - Fixed: mbm5 stats
 - Fixed: Rebuilt a lot of the script
 - Added: GFX card stats
 - Added: Multi HDD support
 - Added: Now uses moo.dll 4.0.4.1
 - Added: Better Unloading < got to be a unique feature ;)

1.6
 - Fixed: Not showing any error msg when not having mbm5 support
 - Fixed: Not being able to have the script in a different dir than the mirc dir
 - Added: Harddrive stats

1.5
 - Fixed: ugly dialogs
 - Removed: Old RAM/Uptime scripts
 - Now uses moo.dll by Mark, lots of new stats thingies.. =)

1.22
 - Fixed: Bug bug bug
 - Added: Uptime

1.21
 - Fixed: Scriptdir problem

1.2
 - Added: Options dialog
 - Fixed: Few Bugs

1.1
 - Fixed: Power DVD bug with showing path

1.0
 - Added: 'Show RAM'
 - Added: Power DVD support

0.4
 - Added: Mplayer support
 - Switched to gos.dll

-------------------
/Krofinzki
