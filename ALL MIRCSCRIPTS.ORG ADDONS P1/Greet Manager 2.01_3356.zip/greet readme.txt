Greet Manager 2.01

Date:		August 23, 2006
Description:	Greet Manager is a simple and easy-to-use addon for greeting friends when they join in your common channels.
Features:	

By:		Relinsquish
IRC:		irc.scrollrack.com @ #scripting
E-mail:		Relinsquish@gmail.com

::Requirements::

mIRC 6.17 or higher
DCX DLL 1.3.1 or higher

::Attached Files::

dcx.dll (dll, 1.3.5)
greet readme.txt (readme)
greet.hsh (preset greets)
greet.mrc (script file)
greetchan.hsh (channel exclusions file)

::Install::

1) Type //load -rs $sfile($mircdir) in mIRC and open greet.mrc
   or
   Press Alt+R, then Ctrl+L in mIRC and open greet.mrc
2) If an error message is shown in the active window once you load the script, follow the shown instructions, then reload the script.
3) In your mIRC, type /greet to open the Greet Manager.

::Syntax::

/greet [-afhlpr] <on|off|nick|format> [message]

The -a switch adds the nickname and message to the greet list.
The -f swtich sets the greet message format.
The -h switch opens the greet readme file.
The -l switch displays the list of greet messages.
The -p switch opens the preview window.
The -r switch indicates that the nickname is to be removed.

No switches open the dialog.

You can clear the greet list by specifying -r with no nickname.

$greet returns $true if greets are enabled, and $false if they aren't.

$greet(nick) returns the greet message of the specified nick.

$greet(message).greet returns the number of greets in the list with the specified message.
$greet(message,N).greet returns the Nth nickname with the specified greet message.

$greet(N).nick returns the Nth nickname in the greet list.
$greet(N).msg returns the Nth greet message in the greet list.

/greetchan [-acklrs] <chan>

The -a switch adds a channel to the channel exclusion list.
The c switch with -a means greets cannot be used in the channel.
The k switch with -a means control codes are stripped from the message in the channel.

The -l switch displays the list of channels and their settings in the channel exclusion list.
The -r switch indicates that the channel is to be removed.

You can clear the channel exclusion list by specifying -r with no channel.

The following switches (when used alone or in combination with each other) affect the global channel exclusion settings:

The -c[0|1|2] switch sets the greet channel settings to allow all, allowed only, or no disallowed.
The -k[0|1|2] switch sets the control code channel settings to allow all, allowed only, or no disallowed.
The -s[0|1] switch sets the "strip when +c is set" setting to either keep or strip control codes.

$greetchan(chan) returns $true or $false depending on whether or not the channel exists in the channel exclusion list.
$greetchan(chan).c returns 0 or 1 depending on if greets are or aren't allowed in the channel.
$greetchan(chan).k returns 0 or 1 depending on if control codes are or aren't allowed in the channel.

$greetchan(N).chan returns the Nth channel in the channel exclusion list

$greetchan().c returns the global greet channel settings, 0 for allow all, 1 for allowed only, 2 for no disallowed.
$greetchan().k returns the global control code channel settings, 0 for allow all, 1 for allowed only, 2 for no disallowed.
$greetchan().s returns the "strip when +c is set" setting, 0 to keep control codes, 1 to strip control codes.

$greetmsg returns the person's greet message in message format during the join event.

Prefixing the /greet and /greetchan commands with . will silence their info messages.

::Note::

The message format determines how the greet message looks like.
It evaluates the message so all identifiers and variables will be evaluated.
Any identifier or variable that will work in an on JOIN event will work here.
I added a $greetmsg identifier to return the person's greet message so you may add it in the format.
If there is no format set, the default is $greetmsg

Example format:

$+([,$nick,]) $greetmsg

would be changed to

[Relinsquish] Hello squishy man!

-

Also, the preview window will display the message with use of the format.
Normally, the evaluation of the message format will result in most identifiers returning $null.
However, I have implemented a quick fix of this with $replace before the evaluation.
The more common remote $identifiers in the message format will be replaced by an example value.
Of course, it won't be accurate. E.g. ABC$chanDEF will return ABC#chanDEF but this is the best solution I could find.

::Version History::

Version 2.01

- Fixed minor bug where greet messages in the preview window were not shown when the message format was not set (thanks to hixxy)
- Fixed bug where error messages were still shown for "invalid parameters" if a . silencer was prefixed for both /greet and /greetchan

Version 2.0

- Renamed to Greet Manager, removed the "Auto-"
- Completely recoded the whole script; more efficient, cleaner code
- Switched from MDX to DCX
- Removed "prefix", changed to "format", and allows identifier and variables to be used instead of <tags>
- Added channel exclusion feature to strip control codes and/or restrict greet messages in all/only-allowed/non-disallowed/+c channels
- Added preview greet feature to allow users to see how the greet messages would look like (helpful especially if it contains control codes or if there is a custom made message format)
- Added /greet, $greet, /greetchan, $greetchan and $greetmsg aliases
- Added popups in channels, menubar, nicklists, queries and status windows

Version 1.0

- First release of Auto-Greet Manager

::Credits::

mIRC - Khaled Mardem-Bey
DCX (Dialog Control Xtension) - ClickHeRe
Popups idea - LemonButt
Preview window using message format idea - [Poke]

Beta Testers:

- [Poke]
- Setever

::Scripter's Note::

If you would like to modify my script in any way, please feel free to do so. If it is possible, I would like credit for my work although it is not necessary.