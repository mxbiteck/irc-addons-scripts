Thank you for downloading MazeGenerator v1.0.
This script generates 'RANDOM' maze puzzles..

This is my first script so please excuse the codes if it looks unorganized lol

INSTRUCTION:

1.  unzip the whole mazegen folder to your mirc folder.
the folder should contain five (5) .wav file, one (1) .mrc file (the script), and this readme.txt

2.  on your status window, type /load -rs mazegen\mazegen.mrc

3. to run the game, right click on your status window and look for MazeGenerator.
you can also find MazeGenerator on you menubar.

4.  enjoy playing :)

IMPORTANT NOTE: This game is coded to run on 1024x768 screen resolution.
choosing lower resolution messes up the screen.

__________________________
About the game:

-To all maze lovers out there.. this game is for you.
-The game support 1 player and 2 player mode.
-Can customize the color of the pipe and background
-You can customize the color of the pipes and background
 as well as the thickness and density of the pipes.

__________________________
Color coding

red -finish
orange -player 1
brown -player 2
blue -keys

__________________________
Controlling the players

up,down,left,right (cursor keys) -player 1
w,a,s,d -player 2

__________________________
For best puzzle click on default button then choose 'expert' on level.

Have fun playing :)


Xander Ramos
tinorknitz@yahoo.com