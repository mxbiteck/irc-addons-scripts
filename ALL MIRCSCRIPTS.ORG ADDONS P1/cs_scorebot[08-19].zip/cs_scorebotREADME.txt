mIRC Counter-Strike Scorebot
by bunkahumpa
bh@scriptsurge.org
--------------------------------


Installation:

- Unzip all of the files into your mIRC directory
- Go into mIRC and type:
  /load -rs scorebot.mrc

Once loaded you can type /scorebot or right-click in a status/channel/query window and select mIRC CS Scorebot.


Setup:

Setting up the scorebot should be fairly straightforward, as it only requires you to input a few things. 

- The first one is the server IP address, this must be a valid IP address (if no port is specified it uses 27015 as default). 
- The second required input is the RCON password, this is very necessary for the scorebot to work - no RCON password, no scorebot. 
- Next select if you want to send the in-game chat to the channel (usually illegal in league matches) or not.
- Lastly select the network and channel you want to broadcast it in and hit the start button.

You can view the server log in the server log tab (once you hit the start button it will show you it automatically). If the RCON password is wrong it will tell you there and it will stop the script automatically so you can start over.


NOTE:

This addon uses port 7131 to receive logs from a specified server, if you have a router or firewall be sure to open port 7131 UDP on it for this script to work.

--------------------------------

Changelog:

August 19th, 2004:

- Made it ignore adminmod, metamod, and statsme log messages.
- Made it not relay any logaddress_add/del information at the beginning.
- It now strips color codes from the messages if mode +c is on the channel.
- Cleaned up some more of the code.


August 12th, 2004:

- Fixed the output when you are not in the scorebot channel and the scorebot is still running.
- Made it ignore a "No addresses added yet" message when attempting to delete your address that is not on the server.
- Fixed a couple "/hdel: no such table 'cs_scorebot'" errors (when players get kicked from console).
- Stopped changing mp_logdetail to 0 on the server, now instead of telling the server not to log attacks it just ignores the ones containing them (some leagues require mp_logdetail set to a certain value).
- Cleaned up the code a tiny bit.


August 5th, 2004:

- Added automatic horizontal scroll to the IP address and RCON password editboxes so longer input can be provided.
- Made it so you can see in-game chat in the server log tab even when sending in-game chat to the channel is disabled.
- Made the loading/starting map messages prettier (rather than showing the CRC check).
- Fixed a bug where sometimes it wouldn't get all of the information sent. Note that some information still may not be received due to the UDP protocol, but most of the time it should now.
- Fixed a bug where information would be sent twice.
- Fixed a bug where if there was more than one | (char 124) in a player's name it would show "$chr(124)". Now names should be 100% correct when this happens.
- Added a way to clear the server log window in the server log tab. Just right-click on it and select "Clear Log window."


August 3rd, 2004:

- Initial release