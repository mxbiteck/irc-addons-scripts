; ==============================================================================
; # .:[ dJabba's SFV Tool v.1.43 ]:. #
; ==============================================================================

1. Information:
���������������
  This tool provides you with the ability to check or create sfv files.

  Sfv files are files that store the checksum of a list of files for further
  comparison. These are offen provided with downloads from the internet to
  make the user able to check if he recieved the file correctly.


2. Copyrights:
--------------
   dJabba's SFV Tool (dJsfvt) is copyrighted 2003-2004 by dJabba, all rights
   are reserved.

   This script is provided "as-is", and i am not responsible for any harm it
   might add to software, hardware, brain(s) or what-so-ever.

   You are allowed to redistribute and modify this file in any way, but if
   you do so, remember to credit me and mention that YOU have modified in it.


3. Requirements:
----------------
   dJ's Recent used filesystem is optional. Copy is inclueded.



4. Commands:
------------
   /sfvtool
	Opens the graphic version of the SFV checker

   /sfvcheck [filename]
	Runs a input field test of the filename specified.



5. Loading and Unloading:
-------------------------
    To load this script place all files in a directory inside your mIRC directory.
    Then you type:
	//load -rs $+(",$findfile($mircdir,dJ_SFVtool.mrc,1),")

    Note: You have to press YES to the question about running commands on loading.
          Without it won't be able to work correctly with the GUI.


    To unload you have to type:
	//unload -rs $+(",$findfile($mircdir,dJ_SFVtool.mrc,1),")



6. Credits:
----------
   Author      dJabba (dJabba@OSiRC.tk)
   Thanks to   CEDSoft for the idea.
               Khaled Mardem-Bey for mIRC.

; ==============================================================================
; # .:[ End Of File ]:. #
; ==============================================================================
