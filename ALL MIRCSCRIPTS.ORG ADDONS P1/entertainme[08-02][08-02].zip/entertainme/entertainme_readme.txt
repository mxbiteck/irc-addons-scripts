Name: Winamp! Entertain Me
Version: 1.0
Author: quickman
For: Winamp and its users

Description:

Sick and tired of having to spend too much time making your own Winamp playlists? Have a playlist type in mind, but don't want to go through the time-consuming process of making one? Want a tool that generates playlists based on a setting you choose? Well this addon is it. Entertain Me generates playlists on all kinds of options. Just fire up winamp and play your tracks, and Entertain Me adds that track to its database. Then, just whip out the Entertain Me dialog for an easy process of making a playlist. Entertain Me takes the data from the database and processes it to generate your playlist, custom made and ready! It makes the playlist in .m3u format, compatible with Winamp.  

You need:

-Winamp 2.x
-This addon and all its components

Installation:

-Extract to any directory.
-Open mIRC
-Type /load -rs path\to\entertainme.mrc

Usage:

-Type /e_m to open the dialog or use the channel/menubar popup menus.
-Select your setting in the drop combo box
-Fill in all fields(or else it won't make the playlist and give you an error)
*NOTE: Output is the filename of the playlist. Example: C:\mirc\test.m3u 
*You don't have to put .m3u at the end or put the file path. You can just put "test" or "test.m3u" if you want.
-Click Generate Playlist, and if all goes well it will generate then give you a summary.
-Load the playlist using Winamp 

--------

List of the settings you can choose to generate your playlists:

Entertain Me - Creates a random playlist of x tracks for x minutes/hours

Top Tracks - Creates a playlist of your top x most played tracks

Lying Low - Creates a playlist of your top x least played tracks

Same Old - Creates a random playlist of x tracks in the genre you specify

Songs Of.. - Creates a random playlist of x tracks in the year you specify

Decades Past - Creates a random playlist of x tracks in the decade you specify

Debuts - Creates a random playlist of x tracks newer than the year you specify

Memories - Creates a random playlist of x tracks older than the year you specify

Recollection - Creates a random playlist of x tracks with songs you haven't played in x hours, days, or weeks.

Reruns - Creates a random playlist of x tracks with songs you have played in the last x hours, days, or weeks. 

Rookies - Creates a random playlist of x tracks that are newer than x hours, days, or weeks.

Veterans - Creates a random playlist of x tracks that are newer than x hours, days, or weeks.

----

Here are some things you need to know:

-Makes the playlist using .m3u format
-The Winamp DLL I use here only works with Winamp 2.x
-If you have the track on repeat, Entertain Me will NOT add a times played to it for each time it is repeated. It only adds a times played when it is a track following a different track. 
-Other files than mp3 will still work, but may mess up the lengths in the playlist and the statusbar summary. Also on the other files, it sets the artist/album to Unknown and the year to 2004.
-Make sure all your mp3 ID3 tags are in tact if you want this to work how you want.
-Yes, when the Lying Low option is selected, the progress bar goes backwards. It is supposed to do that because it is differnet from the rest when being processed.

----

Any bugs? Errors? Have a playlist option idea? Tell them to quickman:
@ us.undernet.org #mircscripts.org
@ irc.isyourgod.com #extremeteam
@ irc.creativeirc.net #wwtbac

==EOF==