Image Converter
Written by [AFX]
nScreenshot.dll by nacitar

INSTALLATION

1) Extract to your mIRC directory or somewhere
2) In mIRC, type /load -rs path\to\Converter\Convert.mrc
3) Enjoy!


USAGE

1) Open the addon (/convert)
2) Select a file to convert
3) Select a save directory to save the file in
4) Click the Convert button, and it shall be done!

You can also preview the image thanks to [Tr|pLe]'s alias.

Not much to explain, it converts pretty much anything to the 4 filetypes
allowed in the addon. Open the addon up by typing /convert, and take a look.
The script file explains a little more about the addon, enjoy!