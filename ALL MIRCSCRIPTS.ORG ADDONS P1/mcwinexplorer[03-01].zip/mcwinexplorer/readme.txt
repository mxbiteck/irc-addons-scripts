======================Readme======================
Name: mcWin Explorer v1.2.1
Author: mc_twistah
E-mail: mctwistah@engineer.com
Website: http://www.manowarscript.tk
==================================================

==================================================
   Versions
================================================== 
mcWin Explorer v1.0 - First public release

mcWin Explorer v1.1 - Added Home Address option
                    - Added Log Addresses/Histories option
                    - Fixed version Compatibility

mcWin Explorer v1.2 - Added titlebar show address
                    - Added popup commands in menu bar
                    - Changed some of the icons to original windows explorer icons
                    - Changed mcwinexplorer into $scriptdir 
                    - Fixed Logging of addresses in browsing for directories
                    - Fixed Back and Forward button (erasing the histories in combo)

mcWin Explorer v1.2.1 - A quick update for minor bugs
                      - Fixed Logging of addresses in browsing dirs. (still logging even if the logging of addresses is off) and now also logs the Home Address.
                      - Fixed writing of addresses in Addresses.txt. (now it writes in the first line of the txt file. Used /write -il1 for more convinient displaying of Histories in the combo)
                      - Added commands like /go help, /go <www.thewebsite.com>, /back, /forward, /stop, /refresh and /home

==================================================
   Installation
==================================================      
    *Unzip mcwinexplorer.zip  by using Winzip ( http://winzip.com )
or other zip aplications in your mIRC directory.

    *dir: C:\mIRC\mcwinexplorer\

    *Loading the addon: method #1
    In loading an addon just type this command ( /load -rs directory/addon.mrc )
in your editbox or where you type your messages.

    * /load -rs mcwinexplorer/explorer.mrc or /load -rs C:\mIRC\mcwinexplorer\explorer.mrc
    * This what you have to type for this 
addon to be loaded.

    *Loading the addon: method #2
    You can load addons by pressing alt+r and the remote script editor will open
and then click on the menus: 

For mIRC 6.03:

File, Load, Script and then browse for the addon that 
you want to load and double click on that file (explorer.mrc).

For mIRC 6.1 up:

First go to Remote Tab and click File, Load and then browse for the addon that 
you want to load and double click on that file (explorer.mrc).

If the addon was successfully loaded, a confirmation in an active window will appear when the steps was correctly done.
    
==================================================  
   Technical Support
==================================================        
    You may contact the author if there are 
problems(Firstly, please check the help.htm included in this addon).
  
Website: http://www.manowarscript.tk
E-mail: mctwistah@engineer.com
Cel#: +639192530381 and look for macky
