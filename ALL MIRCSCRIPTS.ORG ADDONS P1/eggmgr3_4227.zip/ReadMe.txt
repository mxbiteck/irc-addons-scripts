# Eggdrop Manager by FrostByte (v3.0)
# Email: frost@xddl.eu
# Webpage: http://eggdrop.usites.net
# IRC: irc://irc.dal.net/egghelp (#EggHelp @ DALnet)

### This addon has been tested using mIRC v6.35 only. It ~should~ work on previous versions
### but this is not guaranteed.

This addon is an address book for the people who own or maintain more than one eggdrop.
Using this addon, you can store each eggdrop's nickname and hostname and use the dialog
to connect to one or all of your saved eggdrops.

When connecting, you are given the choice of using a DCC connection or a Telnet connection.
My preferred telnet client is Puttytel so i have built in support for this program. However,
the program is not included with the addon. You can use the menu in the dialog to download
the latest version of puttytel.exe.

DOWNLOAD THE LATEST VERSION OF PUTTYTEL.EXE HERE:
http://www.chiark.greenend.org.uk/~sgtatham/putty/download.html

####### Usage #######

### The Basics ###

Load the addon in the usual manner: /load -rs eggmgr.mrc

Allow mIRC to run initialisation commands. You will be presented with a confirmation message.
*** Eggdrop Manager: LOADED (Type /eggmgr to open)

Needless to say, you may now type "/eggmgr" to open the dialog. Else you can use the menubar or
right-click in any channel and select "Eggdrop Manager" to open the dialog.

When the dialog is open, you may add your eggdrop to the list by first typing it's nickname in
the appropriate text box. Next, you can manually type the eggdrop's hostname or IP in the following
text box or press the "Get Host/IP" button to automatically fill the information in.
NOTE: The eggdrop must be connected to the IRC network for this button to work correctly.
Insert the port number into the remaining text box and press the "+" button to save the entry.

To connect to your eggdrop, select the desired eggdrop from the list, choose a connection method
from the options at the bottom and click "Connect". Alternatively press "Connect All" if you want
to connect to ALL of your eggdrops simultaneously (This may cause your computer to run slow depending
on how many eggdrops you have in your list).

### 