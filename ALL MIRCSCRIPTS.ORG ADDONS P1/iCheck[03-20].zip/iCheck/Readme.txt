iCheck v.1.0 by JamesHetfield
-----------------------------

Thanks for downloading iCheck v.1.0 for mIRC! Please follow the simple instructions below to get iCheck
working. Readme best viewed in 'Courier New : 10pt'

1. Extract all files & folders into your mirc directory. Including the folder 'icheck' is optional but recommended.

2. Open mIRC (Tested on 6.03 & 6.12)

3. In any window type //load -rs icheck\icheck.mrc

4. Follow on screen instructions and enjoy!

*********************************************************

Please make sure your remotes/aliai do not contain the following alias names.

� load.book

� $password

� $userexist

� _mdx.load