HLCS is my second HL query script. It is intended for use with Counter-Strike and Counter-Strike:Source. It will work with MOST other HL/HL2 mods.

;;;Installation;;;
Extract all the files in the zip anywhere (mIRC directory is easiest (If you do not know what your mIRC directory is, in mIRC type: "//echo -a $mircdir" without the quotes, then press enter))
Type /load -rs HLCS\HLCS.mrc

Make sure you locate your steam.exe when prompted

Right click on the background of any channel and hit "HLCS Main" (Or the other dialogs) to start

;;;USAGE;;;
In the main dialog all you have to do is enter the IP of the server you wish to query and hit "Search"
In the menu:

Player Finder = A player search, the results may return players in games in which HLCS will not query

Server Finder = A server searcher, servers also may be returned that cannot be queried in HLCS

View Favorites = This will bring up a favorites dialog in which you can save/edit/delete your favorites

Add Favorite (NEW) = This will add the current server that you have queried to your favorites

Clear IP cache = The IP's that you search for are stored in a drop down menu in the dialog, to clear all of the ips out of the list use this.

Text commands (NEW) =

On text commands have been added. People that DON'T have this script, may now also use the functions of HL:CS through text commands
NOTE: THESE COMMANDS MUST BE TRIGGERED BY SOMEONE ELSE, YOU CAN NOT TRIGGER THESE BY TYPING THEM ON YOUR CLIENT.
NOTE: YOU MUST ENABLE THESE COMMANDS BY CLICKING ON THE BACKGROUND OF A CHANNEL YOU ARE IN AND NAVIGATING TO: Text Commands->On AND: Text Commands->Off TO TURN IT OFF.

[hlcs]server [server name]
	Will serach for a server containing [server name] and give the top 5 results to the nick that triggered it, through a notice (that is not visible to your mIRC client)
[hlcs]player [player name]
	Will search for a player containing [player name] and give the top 5 results to the nick that triggered it, through a notice (that is not visible to your mIRC client)
[hlcs]info [IP]
	Will query the IP for information, and display the results in the channel

;;;BUGS;;; 
Report any bugs to kraftey@gmail.com
Or msg me on IRC (irc.gamesurge.net), you can always find me in #script. I'm the one with "noname" somewhere in the name.

______________________________________________________________________________________

;;;FUTURE ADDONS;;;
I think, to reduce the size of this ZIP, I will have HLCS query a server (As soon as I can get some hosting. Hint hint) and download the screenshot for the map. That will reduce the "Screenshot N/A" error on some common maps.