======================Readme======================
Name: mcToolbar Selector v1.1
Author: mc_twistah
E-mail: mctwistah@engineer.com
Website: http://www.manowarscript.tk
==================================================
  
==================================================
   Versions
================================================== 
mcToolbar Selector v1.0 - First public release

mcToolbar Selector v1.1 - Changed toolbar list
                        - Localized aliases to avoid conflicts with other scripts
                        - Changed main alias name into /mtoolbar
                        - Added Apply, Preview, Add and Del popups in the toolbar list using popups.dll
                        - Added configurable transparency to the toolbar preview
                        - Fixed setting/adding dirs/files (now remembers the last added/browsed directory)
                        - Removed preview on select, apply button, preview button and preview on select menu on/off

==================================================
   Installation
==================================================      
    *Unzip mctoolbar.zip  by using Winzip ( http://winzip.com )
in your mIRC directory.

    *dir: C:\mIRC\mctoolbar\

    *Loading the addon: method #1
    In loading an addon just type this command ( /load -rs directory/addon.mrc )
in your editbox or where you type your messages.

    * /load -rs mctoolbar/mctbs.mrc or /load -rs C:\mIRC\mctoolbar/mctbs.mrc
    * This is what you have to type for this 
addon to be loaded.

    *Loading the addon: method #2
    You can load addons by pressing alt+r and the remote script editor will open
and then click on the menus: 

For mIRC 6.03:

File, Load, Script and then browse for the addon that 
you want to load and double click on that file (mctbs.mrc).

For mIRC 6.1 up:

First go to Remote Tab and click File, Load and then browse for the addon that 
you want to load and double click on that file (mctbs.mrc).

If the addon was successfully loaded, a confirmation in an active window will appear when the steps was correctly done.

==================================================  
   Credits
==================================================  
   Toolbars are copyrighted by the individual authors included in this addon.
   All these toolbars can be found in www.mircscripts.org in Misc. section.
   For more info about the authors please visit the site mentioned above.

*Names of the authors of the toolbars are not mentioned since you can add as many toolbars
for your mIRC. Toolbars that are included in this addon are simply for you to test if this
really works with the toolbar buttons in mIRC.
    
==================================================  
   Technical Support
==================================================        
    You may contact the author if there are 
problems(Firstly, please check the help.htm included in this addon).
  
Website: http://www.manowarscript.tk
E-mail: mctwistah@engineer.com
Cel#: +639192530381 and look for macky
