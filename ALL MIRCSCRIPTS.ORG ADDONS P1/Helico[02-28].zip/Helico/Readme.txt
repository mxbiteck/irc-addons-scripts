English version:

Objectives:
----------

The goals are simples. You need to avoid the flying objects and fly as long as you can.

Instructions:
-------------

Once the game is lunched, you'll need to left click on the window to start the game. When you keep the left mouse button, the helicopter will go up, otherwise it will go down. You can access to the options while pressing the right button of your mouse. Then, you'll be able to swith the level difficulty, active/unactive the sounds, show a background or chose a brick mode. If you're computer is too fast for the game, there's a small option the correct this problem. Of course, it's the Iterations part.

Installation:
-------------

You'll need to unzip all the files in the main folder of mIRC ($mircdir). Once it's done, you need to right this line:

//load -rs Helico\Helico.mrc

Then you'll be able to access the game while writing /helico or via the popups in the menubar.

Thanks to:
-------------

A special thanks to visionz who help me a lot with the FPS.
A second thanks to the website who gives me this idea =)

__________________________________________________________________________________