----------------------------------------------------------------
Add-ons Manager
This Add-On use to Load others (for mIRC > 6.15)
-----------------------------------------------------------------
This version should only use for mIRC 6.16 or  higher (because I have used latest $identifier and some new methods
in mIRC 6.16 - like $dllcall ... ) so you should upgrade your mIRC first and I think that's a necessary . mIRC 6.16 has greater compatible ,stable and also many bugs have been fixed.

-To Install :
1)unzip all files  to a Folder ( default MAddons ) It will contains :
      +MAddons.mrc: main script files
      +DLL Files
      +and this readme file

2) Open your mIRC and type: /load -rs <The path of file MAddons.mrc> 
  example  /load -rs MAddons\MAddons.mrc 
 (if you install it on mIRC Dir otherwise please specify  full MAddons.mrc's path )

3) After that you could see mIRC ask to run  Load event (initialization commands )
, push yes , for finish , now you are ready,hope you like it

-To uninstall :simply chose unload in menubar (temporary unload ) , or you can delete 
folder that you install Add on (:( )


-----Contact and Support----------

-if you have  any questions/bugs/comments please send it to
               dvd21us@yahoo.com
(or pmsg me at www.mircscripts.org + www.mircscript.org + www.scriptsdb.org
Nick Niceboy)
-My web site : http://risedvd.tripod.com 


-------Credits---------------------------
- Dragonzap : for his DLLs 
- Thanks who support this Add-on (Big thanks to Mircscripts and Mirc.net website)

--Version---
Version 1.1 (June 8 2005)
- Fixed bug: coudn't update loaded scripts (Thanks foobar and Ecronika for detected it)
- Changed Temporary Add-on Removed method and Added new function to keep Add-ons which has been temporary loaded ( this option occurs only when you have temporary loaded more than one Add-on)

Version 1.0
April/14/2005 

Niceboy-DvD