*** LuxSoft KillTheBird v1.0 (BETA)
*** mIRC v6.21 Game
*** By luxtrike (Marcelo Passalacqua)
*** All rights reserved.

How to install?
---------------
1- Unzip all files from 'killthebird.zip' in a folder.
2- Copy and paste the line below to the 'status window' and locate the file 'killthebird.mrc'

//var %f = $sfile(C:\KillTheBird.mrc,Select game file,Install) | if (%f) { load -rs %f }

3- press 'yes' when a window from mirc apears and that�s it!
4- right click in 'status window' to open the game
5- have fun!