\___\_/___|___\_/___|___\_/___|___\_/___|___\_/___|___\_/___|___\_/___|___\_/___/
/���/ \���|���/ \���|���/ \���|���/ \���|���/ \���|���/ \���|���/ \���|���/ \���\

; Deathlist v1.07
; by ch1zra
; ch1zra@gmail.com
; http://uptheirons.co.sr/
; #Scripters @ irc.krstarica.com
; Copyright � Up The Irons ! inc. Scripting Team

	==> Files
	
	If this archive does not contains files listed below, someone probably
	messed with it. Here's the filelist :
	
		- deathlist_help.chm
		- deathlist.ico
		- deathlist.ini
		- db.jpg
		- deathlist.mrg
		- uti.nfo
		- ReadMe.txt

	==> Instalation

	Step 1. Unzip .zip file into your mIRC directory (all files).
	Step 2. Type //load -rs " $+ $findfile($mircdir,deathlist.mrc,1) $+ "
	Step 3. Answer "Yes" if a popup box comes up.
	Step 4. You are ready to use Deathlist

	After instalation, check your popups.

	==> Description
	
	Classic, hell-themed blacklist. Features included :
		- $mask choosing
		- wildcard support
		- timed scanner
		- punish (kick.ban.ignore)
		- commandline support
		- dynamic popups
		- dialog shortcuts
		- and much much more...
		
	==> Usage
	
	Dialog/popups. Quite self explanatory.
			
	==> Credits

	- Khaled Mardam-Bey for making mIRC.
	- BiskKutMeri for making IRC Simulator thus easing my beta testing.
	- Iron Maiden/Megadeth/Judas Priest/Bruce Dickinson for clearing my thoughts 
	  during scripting.
	- Fast, the sweet nicotine :D
	- All the others...

	==> Changelog
		First public reelase	: 1.0		
       	 	Current release 	: 1.07
		Changes in 1.07 :
			- added $me check, so you won't be punished if $soulmask
			   matches your $mask.
			- added burn-reason for souls.
			- improved nicklist popups.
			- fixed a dialog error.
			- fixed some soulscan timer bugs.
			- updated help file.
			   
	==> Disclaimer

	I will under no circumstances be held responsible for any 
	damage resulting from the use of this addon, whether emotional, 
	physical, loss of data, health, wealth, religious beliefs, or 
	whatever other type of damage. By using this script and reading 
	this document you agree not to hold Deathlist or the author of 
	this addon responsible for (including but not limited to) above 
	mentioned damages. If you do not agree with the above 
	disclaimer, you should remove this script from your computer 
	immediately.

	Thank you for using this addon, I've worked hard to 
	make this as useful, practical and safe as I could!


	==> Contact

	Mail :	ch1zra@gmail.com
	IRC :	#Sobica_Zr #Scripters @ irc.krstarica.com
	www: 	http://uptheirons.co.sr/
	bye, $me
						� 2007 Up The Irons ! inc.