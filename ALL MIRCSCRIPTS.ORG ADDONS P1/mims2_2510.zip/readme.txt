
*> Hash+INI Manager 
*> Author: orkin    
*> Version: 2.0    
*> Contact: orkinator@gmail.com or orkin in #mircscripts.org

This is a pretty self-explanatory addon.  It allows a scripter to easily and quickly manage stored information in a script without once typing $hget or $readini.

[Install] 
Extract the contents of mims2.zip anywhere, but be sure to keep the DLL's in the same directory as mims2.mrc. type /load -rs filepath\mims2.mrc.

[Use]
type /mims2 to bring up the dialog then navigate the treeview as needed.


[Managing] 
All management functions are in the popup.  so just right click the item you wish to manage and the available options will popup.  Additionally, typing something in the editbox and applying it will create a new subitem to whatever item you have selected. For example, if you have a hash table selected and would like to creat an item within the hash table, just type the name of the item in the editbox and hit "Apply". This method works for every itewm besides the root INI and Hash Table.  Thats about all, please e-mail me any comments/suggestions/bugs.


[Credits] 
twigboy for DCX.dll and DragonZap for POPUPS.dll



Versions->-----------------------------------------------------------------------<-

[V1.0] 
First official release July 25th, 2004

[v1.1]
Released August 8th, 2004
-Added a progressbar so if there is alot of information to list people don't think their system has frozen
-Added the hasbuttons parameter to the treeview making it easier to expand/collapse items 
-Made the .mrc file more uniform

[v2.0]
Released April 18th, 2007
-Completely switched to DCX.dll.
-Added the richedit text preview toggle.
-The list population feature now selects the most previous branch you were on after you add or delete an item so you don't have to search for where you left off.
-Added the ability mentioned above to add a subitem to any item by just entering the subitem name into the editbox.

-