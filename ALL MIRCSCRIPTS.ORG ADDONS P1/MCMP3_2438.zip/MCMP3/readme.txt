======================Readme======================
Name: mcMp3 Player v2.2
Author: mc_twistah
E-mail: mctwistah@engineer.com or mjtulagan@hotmail.com
Website: http://www.manowarscript.tk
==================================================

==================================================
   Versions
================================================== 
mcMp3 Player v1.0 Beta - First public beta release (unfortunately it was only accepted in http://www.scriptsdb.org)

mcMp3 Player v1.1 - *

mcMp3 Player v1.2 - *

mcMp3 Player v1.3 - *

mcMp3 Player v1.4 - *

mcMp3 Player v1.4.1 - *

mcMp3 Player v1.5 - *

mcMp3 Player v1.6 - *

mcMp3 Player v1.7 final - *


*updates info may be requested to the author

mcMp3 Player v2.0 - Found an inspiration so this is another update hahaha silly me =)
                  - Added Tooltip info in the scrolling title in the docked player
                  - Added options in the docked player (Full view, Dock on top, Dock on bottom, & Generate html) using popups.dll
                  - Changed RebaR.dll into hOS.dll for docking
                  - Fixed the opening of full player when opened using the option in the docked player
                    *now it opens in desktop or in mIRC (if configured in the menu bar commands)
                  - Added instructions in using this addon in the help.htm file			
                  - Removed the ID3v1 Tag Editor access in the docked player because it won't edit the tag of a playing mp3

mcMp3 Player v2.1 - Added listfiles.dll 1.00 <beta> by Misanthrop for setting the directory of the playlist and searching for audio files
                  - Cleaned-up some codes

mcMp3 Player v2.2 - Fixed docking sequence.
		    *now it halts when clicking dock mp3 on top/bottom when the dialog is already docked on that position
                  - Added Tooltip info in the main player when hovered in the scrolling title
		  - Added more instructions in the help.htm file on how to use this addon 
==================================================
   Installation
==================================================      
    *Unzip mcmp3.zip  by using Winzip ( http://winzip.com )
or other zip aplications in your mIRC directory.

    IMPORTANT:

    For this addon to work properly that was intended to, please install your mIRC in Drive C: and then load this addon in your mIRC. Please follow the directory format below.

    *dir: C:\mIRC\mcmp3\

    *Loading the addon: method #1
    In loading an addon just type this command ( /load -rs directory/addon.mrc )
in your editbox or where you type your messages.

    * /load -rs mcmp3/mcmp3.mrc or /load -rs C:\mIRC\mcmp3\mcmp3.mrc
    * This what you have to type for this 
addon to be loaded.

    *Loading the addon: method #2
    You can load addons by pressing alt+r and the remote script editor will open
and then click on the menus: 

For mIRC 6.03:

File, Load, Script and then browse for the addon that 
you want to load and double click on that file (mcmp3.mrc).

For mIRC 6.1 up:

First go to Remote Tab and click File, Load and then browse for the addon that 
you want to load and double click on that file (mcmp3.mrc).

If the addon was successfully loaded, a confirmation in an active window will appear when the steps was correctly done.
    
==================================================  
   Technical Support
==================================================        
    You may contact the author if there are 
problems(Firstly, please check the help.htm included in this addon).
  
Website: http://www.manowarscript.tk
E-mail: mctwistah@engineer.com or mjtulagan@hotmail.com
Cel#: +639202285891 and look for macky
