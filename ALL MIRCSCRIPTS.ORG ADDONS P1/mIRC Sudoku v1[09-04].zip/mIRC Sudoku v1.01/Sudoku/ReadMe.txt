------------------------------------------------------------------------------------

Project Title:	mIRC Sudoku
Version:		1.01
Created by:		Jynx (sanj b)

Email: 		sanj.s.b@gmail.com
IRC:	 		irc.elite-scriptaz.net
Message:		Jynx on www.elite-scriptaz.net
			Jynx^ on www.mircscripts.org
			sanj on www.mirc.net

------------------------------------------------------------------------------------

Credits:

1.	Bamaboy -	WhileFix.dll
2.	Jagfire - 	Sockets Tutorial
3.	zBrute  -	Assisting with some timer issues.

------------------------------------------------------------------------------------

Installation:

1.	Unzip folder.
2.	Copy Sudoku folder to your mIRC directory.
3.	Then either go to remotes and load the Sudoku.ini file from the Sudoku folder.
	or
	Type: /load -rs suduko\sudoku.ini
4.	Click yes on the command box thats opens, to initiate load commands.

Installation complete...

------------------------------------------------------------------------------------

Game Play:

The script file contains popups for the game, which are accessible on the menubar,
status window and channel window.  Alternatively the game window can be opened by 
typing the command /sudoku.

1.	Press new game.
2.	Select a difficulty level.
	or
	Download a game from www.websudoku.com
3.	Click on start.
4.	Click on grid locations and type a number.
	Numbers can only be input in locations where the grid shows a red square.
	You can choose to use pencil function when unsure about a number.
	REMEMBER THAT IN ORDER TO COMPLETE AND CHECK THE GAME, ALL VALUES MUST BE 
	ENTERED WITH PEN TOOL.
5.	Click on check, to start the checking process.

Enjoy the game...

------------------------------------------------------------------------------------

Known Bugs:

1.	In the checking process, a while loop kills when a number is not located.
	Already working on a fix for this, it shouldn't make much difference to game 
	play, or your IRC experience, as WhileFix.dl has been implemented.

	Until this is fixed, if the checking process stops type ctrl + break.

2.	The game downloading time may vary, or give socket/aline errors.  I'm still 
	trying to improve the html parsing process, its giving me problems as the 
	values needed are stored as READONLY VALUE="*" attributes in <INPUT> tags.

------------------------------------------------------------------------------------

Future Additions:

1.	A facility to store game winning times, and create a personal records window.

------------------------------------------------------------------------------------

eof - Best viewed with; Courier New - 10