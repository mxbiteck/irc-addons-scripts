===================
DCX Studio for mIRC
===================
A quick script to help get the DCX community started.

I know this is buggy! Please report bugs to me so I know what to fix up.
IF YOU ARE TESTING DCX STUDIO, feel free to create complex projects and save it.
Send me the file so I can analyse your project.

Either that, or give me detailed steps on how to reproduce these bugs.

If anyone out there wants to continue working on this project, please contact me.
I've been spending more of my time working on DCX itself, rather than this studio but
it would be nice to see this continue rather than just go stale.



======================
Installation & Running
======================
1. Extract the contents of the zip file into your mIRC folder.
2. Type "/load -rs dcxstudio.mrc"
3. Once it has been loaded...
3a. Right click the status or channel window and then click on "DCX Studio"
    OR...
3b. Type /dcxstudio to start it.
4. Once started, select a control from the toolbox on the left, and
click a location where you wish to add it upon the "DCX Test Dialog"
5. Some properties of the control or dialog can be changed on the "Properties Panel"
on the right side.
6. To delete a control, select the appropriate one from the dropdown listbox and
click "Delete" beside it.



====================
Tips and Quick Notes
====================
- If creating a dialog with normal mIRC controls, it may be easier to use Dialog Studio
first, then converting it into DCX.
- Hold SHIFT or CONTROL buttons while adding controls to keep adding.
- Double click on the status @dcxStudio window to open project files.
- Some controls are not draggable. This is an implementation constraint because I made this
using mIRC scripts rather than another language (ie. comboEx)
- Its strongly advised that you set the UpDown styles BEFORE assigning a buddy



=========
Problems?
=========
Feel free to PM (private message) me on the following websites
- http://dcx.scriptsdb.org/forum (DCX forum - twig)
- http://www.mircscripts.org (twigboy)
- http://www.mirc.net (twigboy)

or on IRC at irc://irc.americhat.net/genscripts

If you find any bugs, manage to fix anything wrong, or have any suggestions, just leave a message and
i'll try to get back to u ASAP.