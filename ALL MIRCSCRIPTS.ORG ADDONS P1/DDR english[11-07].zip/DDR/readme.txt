Dance Dance With mIRC
******by Attila

Tested and codec under 6.16

The goal of the play is to press on the keys of the keyboard at the same time as the arrows which move pass on those fixed in top. 


To play a music, click on "play" then choose a music on the list of right-hand side (see low for the compatible files) 
(if you do not choose music, you will have one of them randomly). In the center, you will see the whole file names. 
Then click on play to launch the file. 
During the play, you can press on "P" to pause the play. 

To create a partition (arrows) click on create then, it's the same principle that to play a music. 
Clickez on creating to open the window. Then, it is asked to you whether you want to use the random method which will make arrows by chance, 
according to the speed which you will have specified. Or you will use the manual method, 
where it will be necessary to press on the arrows at the time or you want that they appear. 

To add a music you just had to copy/paste in the /music directory 
Or to create a partition manually, made .txt files of the same name that music 
example for "my music.mp3" name it "my music.mp3.txt"
For the syntax of the contents, 
initially, the position of the music in milliseconds 
then a double point 
and in the second place, a number from 1 to 4 representative respectively the arrows left, low, high, right
by example:
10000:2
at the end of 10 seconds, the "bottom"`arrow will appear 


PS: If you want to read a format of file other than those by default, just add the plugin winamp (in_*.dll) in system\DLL 
default plugin:
in_mp3.dll : to read MP3;MP2;MP1;AAC;APL;VLB
in_sk00l.dll : : to read MP3 modules (chiptunes) (.mod etc)
in_vorbis.dll : : to read MP3 ogg
in_wm.dll : : to read MP3 .wma

Note: if your PC is too slow and that the arrows are jerked, you can desactivate the effects while by pressing +/- on the menu. 







FRENCH README:
Dance Dance With mIRC
******Par Attila

Cod� et test� sous mirc 6.16

Le but du jeu est d'appuyer sur les touches du clavier en meme temps que les fl�ches qui bougent passent sur celles fixes en haut.


Pour jouer une musique, clickez sur jouer puis choisissez une musique sur la liste de droite (voir plus bas pour les fichiers compatibles)
(si vous ne choisissez pas de musique, vous aurez une al�atoirement) .Au centre, vous verrez les noms de fichiers entiers.
Puis clickez sur jouer pour lancer le jeu.
Pendant le jeu, vous pouvez appuyer sur "P" pour pauser le jeu.

Pour cr�er une partition (les fl�ches) clickez sur cr�er puis meme principe que pour jouer une musique.
Clickez sur cr�er pour ouvrir la fenetre. Ensuite, on vous demande si vous voulez utiliser la m�thode al�atoire qui fera des fl�ches al�atoirement, 
suivant la vitesse que vous aurez sp�cifi�. Ou bien vous utiliserez la m�thode manuelle, 
ou il faudras appuyer sur les fl�ches au moment ou vous voulez qu'elles apparaissent.

Pour ajouter une musique il suffit de la copier coller dans le dossier /music
Ou bien pour cr�er une partition manuellement, faites des fichiers .txt du meme nom que la musique
exemple pour "ma musique.mp3" nommez le "ma musique.mp3.txt"
Pour la syntaxe du contenu,
en premier lieu, la position de la musique en millisecondes
puis un double point
et en second lieu, un num�ro de 1 � 4 repr�sentant respectivement les fl�ches gauche,bas,haut,droite
par exemple:
10000:2
au bout de 10 secondes, la fl�che "bas" va apparaitre


Ps:Si vous voulez lire un format de fichier autre que ceux par d�faut, rajouter le plugin winamp (in_*.dll) dans system\dll
plugins de d�faut:
in_mp3.dll : pour lire MP3;MP2;MP1;AAC;APL;VLB
in_sk00l.dll : pour lire des modules (chiptunes) (.mod etc)
in_vorbis.dll : pour lire les ogg
in_wm.dll : pour lire les .wma

Note: si votre pc est trop lent et que les fl�ches sont saccad�es, vous pouvez d�sactiver les effets en appuyant sur + ou - sur le menu.





