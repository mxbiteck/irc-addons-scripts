Half-Life Demo Launcher
by bunkahumpa
-- E-Mail: bh@scriptsurge.org
-- Web Site: http://bunkahumpa.lookitsbobby.com
-- IRC: irc.GameSurge.net - #script
--------------------------------------------------------

:::::::::::::::::::::::::::::::::
:: What is HLDL?
:::::::::::::::::::::::::::::::::

HLDL is Half-Life Demo Launcher. It is an addon for mIRC (www.mirc.com) that allows you to launch a demo that was recorded in a Half-Life mod. For more information on Half-Life visit http://www.planethalflife.com


:::::::::::::::::::::::::::::::::
:: Installation
:::::::::::::::::::::::::::::::::

1. Unzip the HLDL folder into your mIRC directory.
2. Go into mIRC and type one of the following:

If you unzipped the HLDL folder directly into your mIRC folder:

   /load -rs HLDL\HLDL.mrc
   
If you unzipped it in your mIRC directory, but not sure where:

   //load -rs $findfile($mircdir,HLDL.mrc,1).shortfn

If you know where you unzipped it, type this:

  /load -rs path\to\HLDL.mrc
    (replacing \path\to with the actual path)


:::::::::::::::::::::::::::::::::
:: Startup
:::::::::::::::::::::::::::::::::

Right-click on a channel,query,status window, etc and navigate to "Half-Life Demo Launcher." This will open the dialog for you.


:::::::::::::::::::::::::::::::::
:: Loading a demo
:::::::::::::::::::::::::::::::::

Click on the "Load Demo..." button and naviage to the demo you want to play.

***IMPORTANT***

The demofile MUST be in the specific mod's directory, e.g.:
-> mycsdemo.dem must be in my cstrike directory
-> mydoddemo.dem must be in my dod directory
-> mytfcdemo.dem must be in my tfc directory

***IMPORTANT***

Once you load the demo it will show the mod of the demo, what map it was on, and if it is an HLTV demo or not. If the picture of the map is in the directory of the script it will also display a picture, there are several pictures included.

If you want to include your own picture for a specific map create an image with the following properties: 

WIDTH: 160 HEIGHT: 120 FORMAT: .BMP

Save the file in the same directory where the rest of the images are.


:::::::::::::::::::::::::::::::::
:: Selecting a play type
:::::::::::::::::::::::::::::::::

In the dropdown list there are 2 options, playdemo and viewdemo. These are 2 different ways to view the demo in Half-Life. Playdemo plays it from the start to the end with no options, viewdemo plays it from the start to the end, but allows you to navigate through the demo, fast forward, rewind, change speeds, etc.


:::::::::::::::::::::::::::::::::
:: Choosing a Resolution
:::::::::::::::::::::::::::::::::

Some people prefer to watch demos in a different resolution, mainly because they are making a movie in that certain resolution. HLDL offers them the ability to choose which resolution to watch the demo in. If none is specified it goes with the previously saved resolution, if one was never specified then it goes with the last resolution you used in that specific mod.

You can change the resolution by clicking on the "Resolution" button near the "close" button. Select your resolution and hit save.


:::::::::::::::::::::::::::::::::
:: Playing the demo
:::::::::::::::::::::::::::::::::

Once you have loaded the demo and selected the play type, click on the "Play Specified Demo" button. It should freeze your mIRC for a few seconds, that is perfectly normal. It does this because it copies the demo to be played. After the short freeze it should load the demo's Half-Life mod and play the demo.