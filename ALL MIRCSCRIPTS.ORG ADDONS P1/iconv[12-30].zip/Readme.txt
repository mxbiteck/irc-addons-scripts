*/ Installation
===============
Extract the files to your mIRC directory and type the following command in your mIRC
//load -rs $findfile($mircdir,icon.mrc,1)

This addon requires mIRC 6.16 in order to function (at all.)

*/ Updates
==========
=== v1.2 ==
- Recoded like the whole addon.
- Compressed the code (takes alot less space)
- Changed my nick, this addon is from 2002, i've a new nick now ;p
- Updated readme, Required version for this addon is now mIRC 6.16!

=== v1.1 ===
- Bugfix: /iconv <file> would open the dialog and return "/did invalid paramenters blah blah blah", now fixed!
- Index Number are now added Under the icon (easier)
- Some small small fixes, add and removes :-)

=== v1.0 ===
- First Version :)