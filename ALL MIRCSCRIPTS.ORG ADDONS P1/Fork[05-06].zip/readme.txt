Information from http://www.exploratorium.edu/ronh/weight/
----------------------------------------------------------

To load, extract all files to the same directory from zip file. 
Open mIRC and type /load -rs path\to\fork.mrc

Then type in /fork


Where the 'fork' came from:

<Alan> I'm bored
<Mercutio`> Make a script that calculates the weight of a plastic fork on another planet.
<Alan> ok
