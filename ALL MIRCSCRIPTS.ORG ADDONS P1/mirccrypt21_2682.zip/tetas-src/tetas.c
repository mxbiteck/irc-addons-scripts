/*
 *	tetas/tetas.c
 *
 *  Copyright (C) 2002  Gustavo Picon
 */

#include "tetas.h"
#include "blowfish\bf.h"
#include "md5\md5.h"

BOOL WINAPI _DllMainCRTStartup(HANDLE h, DWORD w, LPVOID v)
{
	tabolib_onload();
	return TRUE;
}

/**
 * blowfish encrypt <key> <string>
 * blowfish decrypt <key> <encryptedstring>
 * blowfish encpass <password>
 */
MircFunc blowfish (FUNCPARMS)
{
	char *tmp = data, *func, *key, *p, s[16];

	func = getword(&tmp);

	if (!lstrcmp(func, "encrypt") || !lstrcmp(func, "decrypt")) {
		key = getword(&tmp);
		if (!*key) {
			r_err("KEY", "Invalid Key");
		}
		if (!tmp || !*tmp) {
			r_err("STRING", "Invalid String");
		}
		if (*func == 'e' || *func == 'E') {
			p = blowfish_encrypt_string(key, tmp);
		} else {
			p = blowfish_decrypt_string(key, tmp);
		}
		wsprintf(data, "+OK %s", p);
		mfree(p);
		return 3;
	} else if (!lstrcmp(func, "encpass")) {
		if (!tmp || !*tmp) {
			r_err("STRING", "Invalid String");
		}
		blowfish_encrypt_pass(tmp, s);
		r_ok(s);
	} else {
		r_err("FUNC", "Unknown subfunction");
	}
}



/**
 * md5 <string>
 */
MircFunc md5 (FUNCPARMS)
{
	MD5_CTX ctx;
	char md5str[33], *r;
	unsigned char digest[16];
	int i;

	if (!*data) {
		r_err("-STRING", "Enter a string to encrypt");
	}

	md5str[0] = 0;
	MD5_Init(&ctx);
	MD5_Update(&ctx, (unsigned char*)data, lstrlen(data));
	MD5_Final(digest, &ctx);

	for (i = 0, r = md5str; i < 16; i++, r += 2) {
		wsprintf(r, "%02x", digest[i]);
	}

	*r = 0;

	r_ok(md5str);
}

void __stdcall LoadDll(LOADINFO* l)
{
}

int __stdcall UnloadDll(int m)
{
	return 1;
}
/*
 * dllinfo
 */
MircFunc dllinfo(FUNCPARMS)
{
	r_ok(DLLINFO);
}
