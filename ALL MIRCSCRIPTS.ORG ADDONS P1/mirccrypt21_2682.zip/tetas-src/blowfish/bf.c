/*
 *	tetas/blowfish/bf.c
 *
 *  Copyright (C) 2002  Gustavo Picon
 */

/*
 *
 *	The following code is adapted from the eggdrop bot source:
 *	by Robey Pointer
 *
 */

#include "..\tetas.h"
#include "blowfish.h"
#include "bf.h"


#define SALT1  0xdeadd061
#define SALT2  0x23f6b095

/* Convert 64-bit encrypted password to text for userfile */
char *base64 = "./0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

int base64dec(char c)
{
	int i;
	for (i = 0; i < 64; i++)
		if (base64[i] == c)
			return i;
	return 0;
}

void blowfish_encrypt_pass(char *text, char *str)
{
	DWORD left,right;
	int n;
	char *p;
	BLOWFISH_CTX ctx;

	Blowfish_Init (&ctx, (unsigned char*)text, lstrlen(text));

	left  = SALT1;
	right = SALT2;

	Blowfish_Encrypt(&ctx, &left, &right);

	p = str;
	*p++ = '+';			/* + means encrypted pass */
	n = 32;
	while (n > 0) {
		*p++ = base64[right & 0x3f];
		right = (right >> 6);
		n -= 6;
	}
	n = 32;
	while (n > 0) {
		*p++ = base64[left & 0x3f];
		left = (left >> 6);
		n -= 6;
	}
	*p = 0;
}
/* Returned string must be freed when done with it! */
char *blowfish_encrypt_string(char *key, char *str)
{
	DWORD left, right;
	unsigned char *p;
	char *s, *dest, *d;
	int i;
	BLOWFISH_CTX ctx;

	/* Pad fake string with 8 bytes to make sure there's enough */
	s = cmalloc(lstrlen(str) + 9);
	lstrcpy(s, str);
	if (!key || !key[0])
		return s;
	p = (unsigned char*)s;
	dest = cmalloc((lstrlen(str) + 9) * 2);
	while (*p)
		p++;
	for (i = 0; i < 8; i++)
		*p++ = 0;

	Blowfish_Init (&ctx, (unsigned char*)key, lstrlen(key));

	p = (unsigned char*)s;
	d = dest;
	while (*p) {
		left = ((*p++) << 24);
		left += ((*p++) << 16);
		left += ((*p++) << 8);
		left += (*p++);
		right = ((*p++) << 24);
		right += ((*p++) << 16);
		right += ((*p++) << 8);
		right += (*p++);

		Blowfish_Encrypt(&ctx, &left, &right);

		for (i = 0; i < 6; i++) {
			*d++ = base64[right & 0x3f];
			right = (right >> 6);
		}
		for (i = 0; i < 6; i++) {
			*d++ = base64[left & 0x3f];
			left = (left >> 6);
		}
	}
	*d = 0;
	mfree(s);
	return dest;
}
/* Returned string must be freed when done with it! */
char *blowfish_decrypt_string(char *key, char *str)
{
	DWORD left, right;
	char *p, *s, *dest, *d;
	int i;
	BLOWFISH_CTX ctx;

	/* Pad encoded string with 0 bits in case it's bogus */
	s = cmalloc(lstrlen(str) + 12);
	lstrcpy(s, str);
	if (!key || !key[0])
		return s;
	p = s;
	dest = cmalloc(lstrlen(str) + 12);
	while (*p)
		p++;
	for (i = 0; i < 12; i++)
		*p++ = 0;

	Blowfish_Init (&ctx, (unsigned char*)key, lstrlen(key));

	p = s;
	d = dest;
	while (*p) {
		right = 0L;
		left = 0L;
		for (i = 0; i < 6; i++)
			right |= (base64dec(*p++)) << (i * 6);
		for (i = 0; i < 6; i++)
			left |= (base64dec(*p++)) << (i * 6);

		Blowfish_Decrypt(&ctx, &left, &right);

		for (i = 0; i < 4; i++)
			*d++ = (left & (0xff << ((3 - i) * 8))) >> ((3 - i) * 8);
		for (i = 0; i < 4; i++)
			*d++ = (right & (0xff << ((3 - i) * 8))) >> ((3 - i) * 8);
	}
	*d = 0;
	mfree(s);
	return dest;
}
