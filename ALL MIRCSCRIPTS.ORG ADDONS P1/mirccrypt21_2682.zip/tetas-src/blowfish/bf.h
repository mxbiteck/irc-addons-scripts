/*
 *	tetas/blowfish/bf.h
 *
 *  Copyright (C) 2002  Gustavo Picon
 */

#ifndef _BF_H
#define _BF_H

void blowfish_encrypt_pass(char *text, char *str);
char *blowfish_encrypt_string(char *key, char *str);
char *blowfish_decrypt_string(char *key, char *str);

#endif
