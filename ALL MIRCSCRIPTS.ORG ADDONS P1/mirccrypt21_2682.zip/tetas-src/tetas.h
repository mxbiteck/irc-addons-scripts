/*
 *	tetas/tetas.h
 *
 *  Copyright (C) 2002  Gustavo Picon
 */

#ifndef _TETAS_H
#define _TETAS_H

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "tabolib.h"

#define MAXSTRINGLEN 900
#define FUNCPARMS    HWND mWnd, HWND aWnd, char* data, char* parms, BOOL show, BOOL nopause
#define DLLNAME      "tetas.dll"
#define VERSION      "20720"
#define DLLINFO      DLLNAME " " VERSION " (C) Gustavo Picon (http://www.airc.ws)"
#define VERSIONL     DLLNAME " " VERSION
#define MircFunc     int __stdcall

#define r_ok(parms)        { wsprintf(data, "+OK %s", (parms)); return 3; }
#define r_err(code, parms) { wsprintf(data, "-%s %s", (code), (parms)); return 3; }

typedef struct {
	DWORD mVersion;
	HWND mHwnd;
	BOOL mKeep;
} LOADINFO;


#endif
