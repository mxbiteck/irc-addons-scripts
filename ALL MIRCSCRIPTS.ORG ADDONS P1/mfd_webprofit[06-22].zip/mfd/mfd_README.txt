__________________________________________________________

                                        bbbbbbbb
                                        b::::::b
                                        b::::::b
                                        bb:::::b 
wwwwww          wwwwww   eeeeeeeeeee     b::::b
w:::::w        w:::::w  ee:::::::::::e   b::::b
w:::::w        w:::::w e:::::eeee:::::e  b::::b
w::::ww        ww::::w e::::e    e::::e  b::::bbbbbbbb
w::::w          w::::w e::::e    e::::e  b:::::::::::::bb 
w::::w   wwww   w::::w e:::::eeee:::::e  b::::bbbbbb:::::b
w::::w  w::::w  w::::w e::::::::::::ee   b::::b     b::::b
w::::w w::::::w w::::w e::::eeeeeeee     b::::b     b::::b  
w:::::w:::ww:::w:::::w e:::e           bb:::::b     b::::b
w:::::::w    w:::::::w e::::eeeeeeeee  b::::::bbbbbb::::b
 w:::::w      w:::::w   e:::::::::::e  b::::::::::xs:::b
 wwwwww        wwwwww    eeeeeeeeeeee  bbbbbbbbbbbbbbbb
__________________________________________________________
webprofits designs and software - http://webproficio.com
             Contact Info: mfd@webproficio.com

Multi-File Downloader v1.3

    aka RAMUDO (RApid MUlti DOwnloader)
_________________________________________________________
Welcome
����������������������������������������������������������
          Thank you for downloading "Multi File Downloader"
          version 1.3, by webprofit, for mIRC. Multi File 
          Downloader, or MFD, as you might be able to tell,
          downloads multiple files from the internet. The 
          [Main Dialog]^ manages all these downloads into one
          simple listview. I created this extensive readme
          so i would not get lame e-mails asking how to work
          this script, so PLEASE read it (especially Usage).


__________________________________________________________
Install
����������������������������������������������������������
          Make sure everything is unzipped to C:\yourdir\mfd\
          where 'C:\yourDIR\' is your mirc directory. Next 
          Start mIRC and type '/load -rs mfd/mfd.mrc'
          Type /mfd to start or Select 'File DL' from the 
          menubar or status.        


__________________________________________________________
Features
����������������������������������������������������������
          - Unlimited Downloads
          - Detailed MDX Listview
          - Listview editor
          - Informative Download Dialog with Progress bar
          - MDX Toolbar
          - Queueing / Max Download
          - Download Options
          - Pause/Resume 

__________________________________________________________
Usage
����������������������������������������������������������
          The MFD is very simple to use. Simply type /mfd
          to launch the script after it has been loaded. 

          During downloads, the manager list (under the 
          toolbar) stores all downloads. The Manager is
          completly configurable and can show upto 9
          different types of info. See below for help
          on configuring the views.
          
          The manager list can be refreshed 2 ways. The 
          first way is by pressing the 'Refresh' Button 
          (see toolbar reference) in the toolbar.
          The next and more simpler way is to Check the 
          "Refresh every X secs" option in the options 
          menu.
          
          To Add a URL to download, simple click the 
          'Add Icon' in the toolbar (see toolbar -
          reference) or select 'New' from the File menu.
          Type in the URL of the file you wish to download
          and the path/name of the file. To simply use the 
	  same filename as the URL uses click the 'Grab'
	  button. 
		If you wish to proceed with the download 
 	  press 'Get It' or press 'Cancel' to cancel the 
	  operation. If you have the "On Add, Start Download" 
	  option on, then the download will start immediatly. 
          Otherwise it will sit in the Manager with the 
          status of 'Awaiting.' The download will stay 
          this way until it is Cancelled or Started. To 
          start an 'Awaiting' download press the 'Get' 
          button. (see toolbar reference)

          To Cancel a download in progress press the
          'Cancel' Button (see toolbar reference). If you 
          have the "On cancel, Clear" option turned on 
          then the download will automatically be cleared
          from the manager after the download has been 
          cancelled.

          You can view a more detailed download dialog by
          double clicking on a download or by selecting a
          download and then clicking the "Details" button.
          The details dialog shows everything there is to
          know about your download and even includes a 
          progress bar.

          MFD supports max downloads and queueing. What 
          this does is when you add another download and
          you are at your max, MFD queues that download. 
          Once a download finishes or gets cancelled the 
          next queued download starts. To turn this option
          on, simple Check the "Max Downloads" option.

          -----Views--------------------------------------
          As you read above, the Manager is completly con-
          figurable and can show upto 9 different types of 
          info. These types are explained below:
           -> Save As:  The name of the file that you are 
                        saving.
           -> From:     Name of the Server from which the 
                        file is being downloaded from
           -> Status:   Current Status of Download
           -> Pct:      Percent Done
           -> Speed:    The speed at which you are receiving 
                        the file.
           -> Eta:      Estimated Time Remaining.
           -> Received: Total amount of file received.
           -> File:     Name of the file from the server.
                        NOT the same as "Save As"
           -> Path:     Where the file is being downloaded. 

          Use the [<-] and [->] buttons to swap the types 
          back and forth. The types on the left side are 
          the types in use and the types on the right are 
          the left-over unused types.

          Use the [Up] and [Dn] to move the types... what
          do you know... up and down. The farther up a 
          type the more left it will be in the manager.

          Double Click the types in the left list to 
          change the width of the headers. NOTE: Changes 
          take affect after the Main Dialog has been 
          closed and reopened.
          -----Views--------------------------------------
          

	  -----Commands-----------------------------------
	  /mfd <-h,o,a,v,d>  
			     : Open MFD Manager		
		-o           : Open OPtions
		-a           : Open Add Dialog
		-v           : Listview Options
		-d <id>      : view this detailed dialog

	  /fdl <-a,o,q> <url> <filename>
     			     : Open Add Download Dialog
		-a 	     : add download
		-o           : Auto-Overwrite file
		-q           : Queue the Download
		
		****SOON to have full remove,pause,
                     cancel etc capabilities.*****

	  -----Commands-----------------------------------

           
          Questions/Comments/Suggestions etc.. should me 
          mailed to: me@webproficio.com

__________________________________________________________
Thanks
����������������������������������������������������������
          -Thanks to Dragonzap and his DLL's: MDX and popup
          -Thanks to ^BeAsT^ helping me understand the 
           resume process.
          -Thanks to the person who wrote $parseurl
	  -Thanks to brezelman, linx05, links for your
	   suggestions
	  -Thanks to copland icons for the systray icon
	  -Thanks to Narusegawa-Naru for systray.dll

          Everyone who posted at my screenshots and gave me
          constructive critism/comments etc..
          
__________________________________________________________
History
����������������������������������������������������������
          Version 1.3 - Jun/22/04
	    -> Fixed minor glitches
	    -> Added Systray capability
	    -> Added popups to systray
            -> Added 'Grab' button  


          Version 1.2 - Dec/30/03
	    -> Fixed Some major components (let me know if errors)
            -> Fixed Details dialog bug  
            -> Added Default directory (linx05)
            -> Added Open On Desktop
            -> Now Supports Dir's with spaces
            -> Supports some Command Lines
			 /mfd & /fdl


          Version 1.01 - June/30/03
            -> Initial Release  
            -> Fixed Resume

          Version 1.00 - June/25/02
            -> Private         

