Notes: This implementation does not follow any particular ADT for linked lists
       It uses functions mentioned in http://en.wikipedia.org/wiki/Linked_list
       for singular linked lists + extra hashtable style functions to keep it similar
       to hash tables. It's a rather crude implementation, and only written as
       proof of concept and because i was bored. But it does show MSL is capable
       of implementing raw data types. It's not recommended you use this
       in your scripts. And btw, i realise linked lists should not contain item names
       but i figured i would make it like hash tables, since storing items can be useful.

Q & A: Q: Why there all this 'xxxxxxAfter' crap?
       A: Removing/changing a node requires you to know the previous node, since
          the previous node holds a reference to the node your changing. If you
          don't update the previous node too, you will break the linked list chain.
          Since the node your editing will always be after the previous, its easier
          to supply the previous to allow editing of both. Without sending the previous
          the script would have to traverse through the linked-list to find the previous
          node. This is inefficient, especially if you already have a loop running.
          An example of this can be seen in linkedlist_remove. I dont recommend you use
          this alias unless you are just deleting the single element. Everytime its
          called, it traverses through the linked list again.

       Q: Whys everything a reference?
       A: A reference is the only way of keeping each node unique, simple as.

       Q: Right but what if i want to get to data for a particular item/data but don't know
          its reference?!
       A: Use $linkedlist_find

       Q: What kind of sort is used?
       A: It's a rather hacked up selection sort implementation. It was the only suitable
          and easy sort to implement.. and it works well on linked lists. See
          http://en.wikipedia.org/wiki/Selection_sort for more info. I realise it doesn't
          have the best time complexity, but i'm not implementing quick sort :/

       Q: Can i numerically iterate over the linked list?
       A: Not recommended. The references may appear to be numerically ordered to begin with
          but for example, after sorting, the top numerical reference may be 25 or something.
          So, you can still loop through the linked list from 0 -> n (while theres a next), 
          but a) it will provide the data to you in the original order of addition
          and b) if elements have been removed, it may break your loop
          I recommend you use the methods used in the example file to loop through the linked
          lists!

       Q: Whats the maximum nodes this can handle?
       A: Dont use more than ~ 1000, it'll probably struggle after that. Inserting 1000
          elements takes me about 30s. Inefficient.. yes.

       Q: Is it possible to iterate through the list backwards?
       A: Not easily. You best way to do it would be to make a new linked list and
          loop through your original, inserting each element at the beginning of your
          new list. This will give you your original list in reverse (although any node
          references for the original will be lost on the new linked list) You can then
          iterate through the reversed linked list.

       Q: Are there bugs?
       A: Quite possibly, i haven't had time to fully test it. I wrote this in under a
          day so its quite possible i made mistakes. Let me know if you find any.

       Q: What happen?
       A: Somebody set up us the bomb.

Usage:

--------

/linkedlist_make -s <name>

 Creates a new linked list
 The -s switch makes the command display the result.

--------

/linkedlist_free -sw <name>

 Frees an existing linked list
 The -w switch indicates that name is a wildcard, all matching lists are freed.

--------

/linkedlist_insert -ms <name> <item> [data]

 Adds an item to an existing linked list
 Item's are not unique within this linked list implementation and thus can be added multiple times
 The -m switch makes /linkedlist_insert create the linked list if it doesn't already exist.

--------

/linkedlist_insertAfter -ms <name> <node reference> <item> [data]

 Adds an item after a particular node in a linked list
 All nodes are accessed and edited via references due to the linked list being non-unique

--------

/linkedlist_insertBeginning -ms <name> <item> [data]

 Adds an item after a particular node in a linked list
 All nodes are accessed and edited via references due to the linked list being non-unique

--------

/linkedlist_inc -s <name> <node reference> [num]

 Increments the data of the node

--------

/linkedlist_dec -s <name> <node reference> [num]

 Decrements the data of the node

--------

/linkedlist_remove -s <name> <node reference>

 Removes a node from the linked list
 This alias traverses the list to find the previous node,
 thus it is not recommended unless necessary.

--------

/linkedlist_removeAfter -s <name> <node reference>

 Removes the node that follows the given one

--------

/linkedlist_removeBeginning -s <name>

 Removes the beginning element of the linked list

--------

/linkedlist_set -s <name> <node> <item/data/next> [value]

 Sets the item, data or next in a node to the value

--------

/linkedlist_sort -s <name> [item/data] [asc/desc]

 Sorts the linked list, by item or data, in the direction specified

--------

/linkedlist_swapAfter -s <name> <node reference1> <node reference2>

 Swaps the elements AFTER the given node references, with each other
 e.g:    NODES: 1 2 3 4 5 6 7 8 9
      ELEMENTS: A B C D E F G H I

 linkedlist_swapAfter name 2 6

 results in:
         NODES: 1 2 7 4 5 6 3 8 9
      ELEMENTS: A B G D E F C H I
 

--------

$linkedlist(name/N)

Returns name of a linked list if it exists, or returns the name of the Nth linked list.

Properties: tail, head

.tail returns a reference to the last node of the linked list
.head returns a reference to the first node of the linked list

--------

$linkedlist_node(name/N, node reference)

Properties: item, data, next

.item returns the item name for the node contained at reference '1' (assuming it exists)
.data returns the data for the node contained at reference '1' (assuming it exists)
.next returns the node reference for the next node (assuming it exists) If the current node is the tail, then next will be $null

--------

$linkedlist_find(name/N, text, N, M)

Searches linked list for the Nth item name which matches text. Returns node reference.

Properties: data

.data property results in it searching for a matching data value.

M is optional, and can be:

  n	normal text comparison (default if M isn't specified)
  w	text is wildcard text
  r	text is regular expression